
<?php /* Template Name: Contact Page Template */ ?>
<?php get_header(); ?>
<?php
$pagename = get_query_var('pagename');
if (!$pagename && $id > 0) {
    // If a static page is set as the front page, $pagename will not be set. Retrieve it from the queried object  
    $post = $wp_query->get_queried_object();
    $pagename = $post->post_name;
}
?>
<?php
if (function_exists('ot_get_option')) {
    $addresses = ot_get_option('add_address');
    $num_of_addresses = count($addresses);
  //  print_r($num_of_addresses);
    //print_r($addresses);
}
?>
<main role="main">
    <div class="container">
        <div class="page_content <?php echo $pagename ?>">
            <div class="row">
                <div class="col-lg-5 col-md-5">
                    <div class="contact_content">
                        <?php if (have_posts()): while (have_posts()) : the_post(); ?>

                                <!-- article -->

                                <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

                                    <?php the_content(); ?>



                                    <?php edit_post_link(); ?>

                                </div>
                                <!-- /article -->

                            <?php endwhile; ?>

                        <?php else: ?>

                            <!-- article -->
                            <div class="no_page_found">

                                <h2><?php _e('Sorry, nothing to display.', 'html5blank'); ?></h2>

                            </div>
                            <!-- /article -->

                        <?php endif; ?>
                    </div>
                    <div class="map">
                        <div class="map_image">
                            <?php 
                            for ($address=0; $address < $num_of_addresses; $address++){?>
                                <a href="javascript:void(0);" class="popover-link popover-link-<?php echo $address?>" data-placement="left"  rel="popover" 
                               data-content="<div class='media'>
                               <div class='media-left'>
                               <img src='<?php echo $addresses[$address]['image']?>'/>
                               </div>
                               <div class='media-body'>
                               <h4><?php echo $addresses[$address]['title']?></h4>
                               <?php echo $addresses[$address]['description']?>
                               </div>
                               </div>" 
                               data-html="true" class="inline-block m-left medium text-blue text-underline"> <img src="<?php echo get_template_directory_uri() ?>/images/circle.svg"/></a>
                            <?php }
                            ?>
                            <img src="<?php echo get_template_directory_uri() ?>/images/map.svg"/>

                        </div>
                    </div>
                </div>
                <div class="col-lg-7 col-md-7">
                    <div class="contact_form">
                        <?php echo do_shortcode('[contact-form-7 id="127" title="Contact Form"]') ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

</main>





<?php get_footer(); ?>
