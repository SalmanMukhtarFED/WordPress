<!-- footer -->
<footer class="footer" role="contentinfo">

    <?php
    /* getting values for top header functionality */

    // header enabled or not
    if (function_exists('ot_get_option')) {
        $top_switch = ot_get_option('enable_top_header');
        $top_header_text = ot_get_option('top_header_text');
        $top_header_cta = ot_get_option('top_header_button_text');
        $top_header_bg = ot_get_option('top_header_background');
        $top_header_cta_link = ot_get_option('header_cta_link');
        $footer_text = ot_get_option('footer_text');
    }
    ?>
    <?php if ($top_switch == "on") { ?>
        <div class="top_header" style="background: <?php echo $top_header_bg ?>">
            <div class="container">
                <div class="row">
                    <div class="col-md-9 col-sm-8">
                        <?php echo $top_header_text; ?>
                    </div>
                    <div class="col-md-3 col-sm-4">
                        <a href="<?php echo esc_url(get_permalink($top_header_cta_link)); ?>" class="top_header_cta"><?php echo $top_header_cta ?></a>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-md-2 col-sm-3">
                    <?php dynamic_sidebar('menu-1'); ?>
                </div>
                <div class="col-md-3 col-sm-3">
                    <?php dynamic_sidebar('menu-2'); ?>
                </div>

                <div class="col-md-3 col-sm-3">
                    <?php dynamic_sidebar('menu-3'); ?>
                </div>
                <div class="col-md-3 col-sm-3">
                    <?php dynamic_sidebar('menu-4'); ?>
                </div>
            </div>
            <div class="m-top footer-text row">
                <div class="col-md-8 col-sm-8">
                    <?php echo $footer_text; ?>
                </div>
                <div class="col-md-4 col-sm-4 text-right f-logo">
                    <img style="width:250px; margin-right: -80px;" src="<?php echo get_template_directory_uri(); ?>/images/white.svg"/>
                </div>
            </div>
        </div>
    </div>

    <div class="f-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-8">
                    <?php
                    if (function_exists('ot_get_option')) {

                        /* get the slider array */
                        $logos = ot_get_option('footer_logos');
                        $num_of_logos = count($logos);
                        //var_dump($num_of_keyfacts);
                    }
                    ?>
                    <div class="logos text-right">
                        <?php
                        for ($i = 0; $i < $num_of_logos; $i++) {
                            ?>
                            <div class="logo">
                                <img src="<?php echo $logos[$i]['add_logo'] ?>" alt="<?php echo $logos[$i]['title'] ?>"/>
                            </div>
                        <?php }
                        ?>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4">
                    <div class="social_share">
                        <?php dynamic_sidebar('social-share'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- /footer -->



<?php wp_footer(); ?>

<!-- analytics -->
<script>
    (function (f, i, r, e, s, h, l) {
        i['GoogleAnalyticsObject'] = s;
        f[s] = f[s] || function () {
            (f[s].q = f[s].q || []).push(arguments)
        }, f[s].l = 1 * new Date();
        h = i.createElement(r),
                l = i.getElementsByTagName(r)[0];
        h.async = 1;
        h.src = e;
        l.parentNode.insertBefore(h, l)
    })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');
    ga('create', 'UA-XXXXXXXX-XX', 'yourdomain.com');
    ga('send', 'pageview');
</script>

</body>
</html>
