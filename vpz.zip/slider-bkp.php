<div class="owl-carousel owl-theme" id="main_slider">
            <?php
            for ($i = 0; $i < $num_of_slides; $i++) {
                ?>
                <div class="item">
                    <div class="image">
                        <img src="<?php echo $slider[$i]['image'] ?>" alt="<?php echo $slider[$i]['title'] ?>"/>
                        <ul class="slider_links">
                            <?php
                            for ($slide = 0; $slide < $total_links; $slide++) {
                                ?>
                                <li class="link<?php echo $slide; ?>"><a href="<?php echo get_page_link($slider_links[$slide]['slider_link']) ?>"><?php echo $slider_links[$slide]['title'] ?></a></li>
                            <?php }
                            ?>
                        </ul>
                    </div>
                    <div class="description">
                        <?php echo $slider[$i]['description'] ?>
                    </div>
                </div>
            <?php }
            ?>
        </div>