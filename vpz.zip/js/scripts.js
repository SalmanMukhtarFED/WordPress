(function ($, root, undefined) {
    $(function () {
        'use strict';
        $(document).ready(function () {
            var score = {
                colors: []
            };
            var navListItems = $('div.setup-panel div a'),
                    allWells = $('.setup-content'),
                    allNextBtn = $('.nextBtn');
            allWells.hide();
            navListItems.click(function (e) {
                e.preventDefault();
                var $target = $($(this).attr('href')),
                        $item = $(this);
                if (!$item.hasClass('disabled')) {
                    navListItems.removeClass('btn-primary').addClass('btn-default');
                    $item.addClass('btn-primary');
                    allWells.hide();
                    $target.show();
                    $target.find('input:eq(0)').focus();
                }
            });
            allNextBtn.click(function () {
                var curStep = $(this).closest(".setup-content"),
                        curStepBtn = curStep.attr("id"),
                        nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
                        curInputs = curStep.find("input[type='text'],input[type='url']"),
                        isValid = true;
                $(".form-group").removeClass("has-error");
                for (var i = 0; i < curInputs.length; i++) {
                    if (!curInputs[i].validity.valid) {
                        isValid = false;
                        $(curInputs[i]).closest(".form-group").addClass("has-error");
                    }
                }
                if (isValid)
                    nextStepWizard.removeAttr('disabled').trigger('click');
                /////dognurt chart logic
                if ($(this).parent("div").attr("data-id") == "slides")
                {
                    var all_answers = new Array();
                    $(this).parent("div").find("option:selected").each(function () {
                        // console.log($(this).val());
                        all_answers.push($(this).val());
                    });
                    ////////list item add dot according to the tab result
                    var parent_attr_id = $(this).parent("div").attr("id");
                    $("a[href='" + parent_attr_id + "']").addClass('selected');
                    ////count the occurance of options
                    var counts = {};
                    for (var i = 0; i < all_answers.length; i++) {
                        var num = all_answers[i];
                        counts[num] = counts[num] ? counts[num] + 1 : 1;
                    }
                    /////condtion according to giev document

                    if (counts['Ja'] == 4)
                    {
                        score.colors.push('#527424');
                    }
                    else if (counts['Ja'] == 3)
                    {
                        score.colors.push('#d9212b');
                    }
                    else if (counts['Ja'] == 2)
                    {
                        score.colors.push('#d9212b');
                    }
                    else if (counts['Ja'] == 1)
                    {
                        score.colors.push('#bf0711');
                    } else {
                        score.colors.push('#bf0711');
                    }
                    
                    //$(".stepwizard-step a").each(function () {
                        // console.log($(this).val());
                        for (var i = 0; i < score.colors.length; i++) {
                                var num = score.colors[i];
                                var pid = $(this).parent("div").attr("id");
                               $(".stepwizard-step").find("a[href=#"+pid+"]").addClass("completed");
                               if(num == '#527424')
                               {
                                   $(".stepwizard-step").find("a[href=#"+pid+"]").removeClass("lightred");
                                    $(".stepwizard-step").find("a[href=#"+pid+"]").removeClass("red");
                                   $(".stepwizard-step").find("a[href=#"+pid+"]").addClass("green");
                               }
                               
                                if(num == '#d9212b')
                                {
                                    $(".stepwizard-step").find("a[href=#"+pid+"]").removeClass("green");
                                    $(".stepwizard-step").find("a[href=#"+pid+"]").removeClass("red");
                                    $(".stepwizard-step").find("a[href=#"+pid+"]").addClass("lightred");
                                }
                                    
                                if(num == '#bf0711')
                                {
                                    $(".stepwizard-step").find("a[href=#"+pid+"]").removeClass("green");
                                    $(".stepwizard-step").find("a[href=#"+pid+"]").removeClass("lightred");
                                    $(".stepwizard-step").find("a[href=#"+pid+"]").addClass("red");
                                }
                                
                                
                                //counts[num] = counts[num] ? counts[num] + 1 : 1;
                            }
                        
                    //});

                    var ctx = document.getElementById("myChart");
                    var data = {
                        datasets: [{
                                data: [20, 20, 20, 20, 20, 20, 20, 20],
                                backgroundColor: score.colors
                            }],
                        // These labels appear in the legend and in the tooltips when hovering different arcs
                        // labels: [
                        //     'Beruf',
                        //     'Vorsorge',
                        //     'Steuern',
                        //     'Familie',
                        //     'Hypothek',
                        //     'Ausland',
                        //     'Pension',
                        //     'Nachlass'
                        // ]
                    };
                    var options = {
                        legend: {
                            position: 'right'
                        },
                        tooltips: {
                            enabled: false
                         },
                         hover: {mode: null},
                        animation: {
                            animateRotate: false,
                            animateScale: true
                        }
                    };
                    var myChart = new Chart(ctx, {
                        type: 'doughnut',
                        data: data,
                        options: options
                    });
                    console.log("my colors" + score.colors.length);
                    if (score.colors.length == 8)
                    {
                        console.log("my colors" + score.colors);
                        ////count the occurance of options
                        var counts_color = {};
                        for (var i = 0; i < score.colors.length; i++) {
                            var num = score.colors[i];
                            counts_color[num] = counts_color[num] ? counts_color[num] + 1 : 1;
                        }

                        var nagitive = counts_color['#bf0711'] + counts_color['#d9212b'];
                        ////if section color red/light red is greater then 2 the show nagitive message
                        if (nagitive > 2)
                        {
                            $(".report-message").append('<h1>Nagitive, based on your report, you need help!</h1><h3>GET IN TOUCH WiTH VPZ AGENT</h3><h3 class="number">+49 778 1223</h3><p>We need email and phone number to contact with you</p><label class="control-label">Email address *</label><input type="email" name="email" class="form-control" placeholder="E-Mail Adresse" required>');
                        }
                        else if (counts_color['#527424'] > 5)
                        {
                            $(".report-message").append('<h1>Excelent, based on your report, you need help!</h1><h3>GET IN TOUCH WiTH VPZ AGENT</h3><h3 class="number">+49 778 1223</h3><p>We need email and phone number to contact with you</p><label class="control-label">Email address *</label><input type="email" name="email" class="form-control" placeholder="E-Mail Adresse" required>');
                        }
                        $(".report-message").append('</br><button class="btn btn-primary nextBtn btn-lg">Nächster</button>');
                    }
                }
            });
            $('div.setup-panel div a.btn-primary').trigger('click');
            var ctx = document.getElementById("myChart");
            var data = {
                datasets: [{
                        data: [20, 20, 20, 20, 20, 20, 20, 20],
                        backgroundColor: ['#E5E5E5', '#E5E5E5', '#E5E5E5', '#E5E5E5', '#E5E5E5', '#E5E5E5', '#E5E5E5', '#E5E5E5']
                    }],
                // These labels appear in the legend and in the tooltips when hovering different arcs
                // labels: [
                //     'Beruf',
                //     'Vorsorge',
                //     'Steuern',
                //     'Familie',
                //     'Hypothek',
                //     'Ausland',
                //     'Pension',
                //     'Nachlass'
                // ]
            };
            var options = {
                legend: {
                    position: 'right'
                },
                tooltips: {
                    enabled: false
                 },
                 hover: {mode: null},
                animation: {
                    animateRotate: false,
                    animateScale: true
                }
            };
            var myChart = new Chart(ctx, {
                type: 'doughnut',
                data: data,
                options: options
            });
            /////first slide show
            $(".first-slide").show();
            $(".first-slide-hide").hide();
            /////////disable click on slides
            $(".stepwizard-step a").css("pointer-events","none");

            $("[rel=popover]").popover();
            $('#main_slider').owlCarousel({
                items: 1,
                margin: 10
            });
            // $("#sendemail").click(function(){
            //    alert('i am here ');
            // });
        });
        ///////////send email///////
        $('.wordpress-ajax-form').on('submit', function(e) {
        		e.preventDefault();
        		var $form = $(this);
        		$.post($form.attr('action'), $form.serialize(), function(data) {
               $(".report-message").html('');
        			  $(".report-message").append('<h1>Thank you for submitting your info,Someone will get in touch with you!</h1>');
        		}, 'json');
        	});
        // var email_feilds = new Array();
          // function Sendemail(){
          //   console.log("dsad");
          //   $("select,input").each(function()
          //   {
          //     var question_label = $(this).prev('label').text();
          //     email_feilds.push(question_label);
          //       email_feilds.push($(this).val());
          //   });
          //   console.log(email_feilds);
          // }

        ///////////////////////////////
    });

})(jQuery, this);
