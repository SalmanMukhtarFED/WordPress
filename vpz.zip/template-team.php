<?php /* Template Name: Team Page Template */ get_header(); ?>

<?php get_header(); ?>
<?php
$pagename = get_query_var('pagename');
if (!$pagename && $id > 0) {
    // If a static page is set as the front page, $pagename will not be set. Retrieve it from the queried object  
    $post = $wp_query->get_queried_object();
    $pagename = $post->post_name;
    echo $pagename;
}
?>
<main role="main">
    <div class="container">
        <div class="page_content <?php echo $pagename ?>">

            <?php if (have_posts()): while (have_posts()) : the_post(); ?>

                    <!-- article -->

                    <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

                        <?php the_content(); ?>

                        <?php edit_post_link(); ?>

                    </div>
                    <!-- /article -->

                <?php endwhile; ?>
            <?php endif; ?>
            <?php
            if ($pagename == "team") {
                ?>
                <section class="team_members section_padder">
                    <div class="row">
                        <?php
                        $args = array('post_type' => 'team-members', 'order' => 'ASC');
                        $loop = new WP_Query($args);
                        $count = 1;


                        while ($loop->have_posts()) : $loop->the_post();
                            ?>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6 team_member">
                                <div class="member_image">
                                    <?php the_post_thumbnail('large'); ?>
                                </div>
                                <div class="member_title">
                                    <?php the_field('designation') ?>
                                </div>
                                <div class="member_title name">
                                    <?php the_title(); ?>
                                </div>

                                <div class="member_title education">
                                    <?php the_field('education'); ?>
                                </div>
                                <div class="member_message description">
                                    <?php the_content(); ?>
                                </div>
                            </div>
                            <?php if ($count % 3 == 0) { ?>
                            </div>   
                        <?php }
                        ?>
                        <?php
                        $count++;
                    endwhile;
                    wp_reset_query();
                    ?>
                </section>
            <?php } ?>
                    <?php
            if ($pagename == "kompetenzbeirat") {
                ?>
                <section class="team_members section_padder">
                    <div class="row">
                        <?php
                        $args = array('post_type' => 'team-members', 'category_name' => 'kompetenzbeirat', 'order' => 'ASC');
                        $loop = new WP_Query($args);
                        $count = 1;


                        while ($loop->have_posts()) : $loop->the_post();
                            ?>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6 team_member">
                                <div class="member_image">
                                    <?php the_post_thumbnail('large'); ?>
                                </div>
                                <div class="member_title">
                                    <?php the_field('designation') ?>
                                </div>
                                <div class="member_title name">
                                    <?php the_title(); ?>
                                </div>

                                <div class="member_title education">
                                    <?php the_field('education'); ?>
                                </div>
                                <div class="member_message description">
                                    <?php the_content(); ?>
                                </div>
                            </div>
                            <?php if ($count % 3 == 0) { ?>
                            </div>   
                        <?php }
                        ?>
                        <?php
                        $count++;
                    endwhile;
                    wp_reset_query();
                    ?>
                </section>
            <?php } ?>
                    <?php
            if ($pagename == "geschaftsleitung") {
                ?>
                <section class="team_members section_padder">
                    <div class="row">
                        <?php
                        $args = array('post_type' => 'team-members',  'category_name' => 'geschaftsleitung', 'order' => 'ASC');
                        $loop = new WP_Query($args);
                        $count = 1;


                        while ($loop->have_posts()) : $loop->the_post();
                            ?>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6 team_member">
                                <div class="member_image">
                                    <?php the_post_thumbnail('large'); ?>
                                </div>
                                <div class="member_title">
                                    <?php the_field('designation') ?>
                                </div>
                                <div class="member_title name">
                                    <?php the_title(); ?>
                                </div>

                                <div class="member_title education">
                                    <?php the_field('education'); ?>
                                </div>
                                <div class="member_message description">
                                    <?php the_content(); ?>
                                </div>
                            </div>
                            <?php if ($count % 3 == 0) { ?>
                            </div>   
                        <?php }
                        ?>
                        <?php
                        $count++;
                    endwhile;
                    wp_reset_query();
                    ?>
                </section>
            <?php } ?>
        </div>
    </div>
</main>

<?php get_footer(); ?>
