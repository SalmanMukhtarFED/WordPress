<form role="form" action="" method="post">
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label class="control-label">Andre *</label>
                [text* text-andre class:form-control]
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label class="control-label">Title *</label>
                [text* text-title class:form-control]
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label class="control-label">Name *</label>
                [text* text-name class:form-control]
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label class="control-label">Vorname *</label>
                [text* text-vorname class:form-control]
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label class="control-label">Firma *</label>
                [text* text-firma class:form-control]
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label class="control-label">Address *</label>
                [text* text-address class:form-control]
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label class="control-label">PLZ/Ort *</label>
                [text* text-plz class:form-control]
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label class="control-label">Land</label>
                [text* text-land class:form-control]
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label class="control-label">Telephone *</label>
                [text* text-telephone class:form-control]
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label class="control-label">E-Mail *</label>
                [email* email-address class:form-control]
            </div>
        </div>
    </div>
    <div class="form-group">
        <label class="control-label">Bemerkungen *</label>
        [textarea textarea-bemerkungen class:form-control]
    </div>
    <div class="form-group">
        <label class="control-label">Mich interessieren folgende Themen:</label>
        <div class="row">
            <div class="col-md-6">
                [checkbox checkbox-berufseinstieg use_label_element exclusive "Berufseinstieg"]
            </div>
            <div class="col-md-6">
                [checkbox checkbox-rermogens use_label_element exclusive "Vermögens- und Steuerplanung"]
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                [checkbox checkbox-familiengrundung use_label_element exclusive "Familiengründung"]
            </div>
            <div class="col-md-6">
                [checkbox checkbox-pensionsplanung use_label_element exclusive "Pensionsplanung"]
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                [checkbox checkbox-eigenheim use_label_element exclusive "Eigenheim"]
            </div>
            <div class="col-md-6">
                [checkbox checkbox-unternehmensplanung use_label_element exclusive "Unternehmensplanung"]

            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                [checkbox checkbox-firmengrundung use_label_element exclusive "Firmengründung"]

            </div>
            <div class="col-md-6">
                [checkbox checkbox-pensionsplanung use_label_element exclusive "Pensionsplanung"]
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
               [checkbox checkbox-expat use_label_element exclusive "Expat/Zuzug aus dem Ausland"]

            </div>
            <div class="col-md-6">
                [checkbox checkbox-klientenmagazin use_label_element exclusive "Klientenmagazin"]
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
               [checkbox checkbox-Vermogensoptimierung use_label_element exclusive "Vermögensoptimierung"]

            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                [submit class:btn class:btn-primary "Send"]
            </div>
            <div class="col-md-6">
                <div class="required_fields">
                    Felder mit * sind Pflichtfelder
                </div>
            </div>
        </div>
    </div>
</form>