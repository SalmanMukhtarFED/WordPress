<!doctype html>
<html <?php language_attributes(); ?> class="no-js">
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <title><?php wp_title(''); ?><?php
            if (wp_title('', false)) {
                echo ' :';
            }
            ?> <?php bloginfo('name'); ?></title>

        <link href="//www.google-analytics.com" rel="dns-prefetch">
        <link href="<?php echo get_template_directory_uri(); ?>/img/icons/favicon.ico" rel="shortcut icon">
        <link href="<?php echo get_template_directory_uri(); ?>/img/icons/touch.png" rel="apple-touch-icon-precomposed">

        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="<?php bloginfo('description'); ?>">
        <link href="https://fonts.googleapis.com/css?family=Work+Sans:300,400,500,600,700,800" rel="stylesheet">
        <link rel="stylesheet" media="all" type="text/css" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/>       
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/owl.carousel.min.css">
        <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/owl.theme.default.css">
         <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/steps_form.css">
         <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/checkbox-radio.css">
          
        <?php wp_head(); ?>
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>  
         <script src="<?php echo get_template_directory_uri(); ?>/js/owl.carousel.min.js"></script>
          <script src="//cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.bundle.min.js"></script>
          <script src="//cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js" type="text/javascript"></script>
        
        <script>
// conditionizr.com
// configure environment tests
            conditionizr.config({
                assets: '<?php echo get_template_directory_uri(); ?>',
                tests: {}
            });
        </script>
        

    </head>
    <body <?php body_class(); ?>>


        <?php
        /* getting values for top header functionality */

        // header enabled or not
        if (function_exists('ot_get_option')) {
            $top_switch = ot_get_option('enable_top_header');
            $top_header_text = ot_get_option('top_header_text');
            $top_header_cta = ot_get_option('top_header_button_text');
            $top_header_bg = ot_get_option('top_header_background');
            $top_header_cta_link = ot_get_option('header_cta_link');
        }
        ?>
        <?php if ($top_switch == "on") { ?>
            <div class="top_header" style="background: <?php echo $top_header_bg ?>">
                <div class="container">
                    <div class="row">
                        <div class="col-md-9 col-sm-8">
    <?php echo $top_header_text; ?>
                        </div>
                        <div class="col-md-3 col-sm-4">
                            <a href="<?php echo esc_url(get_permalink($top_header_cta_link)); ?>" class="top_header_cta"><?php echo $top_header_cta ?></a>
                        </div>
                    </div>
                </div>
            </div>
<?php } ?>
        <!-- header -->
        <header class="header clear" role="banner">


            <!-- nav -->
            <nav class="navbar">
                <div class="container">
                    <div class="navbar-header">
                        <a class="navbar-brand" href="<?php echo home_url(); ?>"> <img src="<?php echo get_template_directory_uri(); ?>/images/dark.svg" alt="Logo" class="logo-img"></a>
                    </div>
<?php html5blank_nav(); ?>
                </div>
            </nav>
        </header>
        <!-- /header -->
