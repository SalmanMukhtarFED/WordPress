<?php /* Template Name: Homepage Template */ get_header(); ?>

<?php
if (function_exists('ot_get_option')) {
    $slider = ot_get_option('slider');
    $num_of_slides = count($slider);
    $slider_links = ot_get_option('slider_link');
    $total_links = count($slider_links);
}

// if(isset($_POST["email"]))
// {
//
//     $url = home_url();
//     $email = $_POST['email'];
//     $to = "Michael.holste@proxation.de";
//     $subject = "New inquery";
//     $message = 'Age: '.$_POST['age'].'Familienstand *: '.$_POST['familienstand'].'Einkommen *: '.$_POST['einkommen'].'';
//     $headers = "From: " . $email;
//     if(wp_mail($to,$subject,$message,$headers))
//     {
//       print('<script>window.location.href="'.$url.'"</script>');
//     }
//
// }
?>
<main role="main">
    <div class="container">

        <?php echo do_shortcode('[rev_slider alias="homepage"]'); ?>
        <div class="homepage_slider_text">
            <?php the_field('homepage_slider_text'); ?>
        </div>
        <div class="separator"></div>
        <section class="calculator_area section_padder">
            <div class="container">
                <h3 class="section_title">Finanzkalkulator</h3>
                <div class="calculator_chart">
                    <div class="col-md-6 col-md-offset-3">
                        <canvas id="myChart" width="400" height="400"></canvas>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="calculator_form_wrap">
                    <div class="row">
                        <div class="col-md-3 col-sm-4">
                            <div class="stepwizard">
                                <div class="stepwizard-row setup-panel">
                                    <h4>PROGRESS</h4>
                                    <div class="stepwizard-step first-slide-hide">
                                        <a href="#step-0" type="button" class="btn btn-circle">0</a>

                                    </div>
                                    <div class="stepwizard-step">
                                        <a href="#step-1" type="button" class="btn btn-circle">1</a>
                                        <p>Beruf</p>
                                    </div>
                                    <div class="stepwizard-step">
                                        <a href="#step-2" type="button" class="btn btn-default btn-circle" disabled="disabled">2</a>
                                        <p>Vorsorge</p>
                                    </div>
                                    <div class="stepwizard-step">
                                        <a href="#step-3" type="button" class="btn btn-default btn-circle" disabled="disabled">3</a>
                                        <p>Steuern</p>
                                    </div>
                                    <div class="stepwizard-step">
                                        <a href="#step-4" type="button" class="btn btn-default btn-circle" disabled="disabled">4</a>
                                        <p>Familie</p>
                                    </div>
                                    <div class="stepwizard-step">
                                        <a href="#step-5" type="button" class="btn btn-default btn-circle" disabled="disabled">5</a>
                                        <p>Hypothek</p>
                                    </div>
                                    <div class="stepwizard-step">
                                        <a href="#step-6" type="button" class="btn btn-default btn-circle" disabled="disabled">6</a>
                                        <p>Ausland</p>
                                    </div>
                                    <div class="stepwizard-step">
                                        <a href="#step-7" type="button" class="btn btn-default btn-circle" disabled="disabled">7</a>
                                        <p>Pension</p>
                                    </div>
                                    <div class="stepwizard-step">
                                        <a href="#step-8" type="button" class="btn btn-default btn-circle" disabled="disabled">8</a>
                                        <p>Nachlass</p>
                                    </div>
                                    <div class="stepwizard-step first-slide-hide">
                                        <a href="#step-9" type="button" class="btn btn-default btn-circle" disabled="disabled">9</a>
                                        <p>Nachlass</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-9 col-sm-8">
                            <div class="calculator_form">
                                <form role="form"  class="wordpress-ajax-form"  action="<?php echo admin_url('admin-ajax.php'); ?>" method="post">

                                    <div class="setup-content first-slide"  id="step-0">

                                        <div class="form-group">
                                            <label class="control-label">Select Age *</label>
                                            <select class="form-control" name="age">
                                                <option value="18">18</option>
                                                <option value="19">19</option>
                                                <option value="20">20</option>
                                                <option value="21">21</option>
                                                <option value="22">22</option>
                                                <option value="23">23</option>
                                            </select>
                                                <!-- <input type="number" class="form-control" placeholder="Choose Age" /> -->
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label" >Familienstand *</label>
                                            <select class="form-control" name="familienstand">
                                                <option value="Ledig">Ledig</option>
                                                <option value="Geschieden">Geschieden</option>
                                                <option value="Verwittwert">Verwittwert</option>
                                                <option value="Verheiratet">Verheiratet</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label" >Einkommen *</label>
                                            <select class="form-control" name="einkommen">
                                                <option value="5000-10000">5000-10000</option>
                                                <option value="10000-25000">10000-25000</option>
                                                <option value="25000-50000">25000-50000</option>
                                                <option value="50000-100000">50000-100000</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Einkommen *</label>
                                            <input type="text" class="form-control" placeholder="Choose one" />
                                        </div>
                                        <button class="btn btn-primary nextBtn btn-lg" type="button" >Nächster</button>

                                    </div>

                                    <div class="setup-content" id="step-1" data-id="slides">

                                        <div class="form-group">
                                            <label class="control-label">Question 1</label>
                                            <select class="form-control steps" name="slide1question1">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 2 *</label>
                                            <select class="form-control steps" name="slide1question2">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label" >Question 3 *</label>
                                            <select class="form-control steps" name="slide1question3">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 4 *</label>
                                            <select class="form-control steps" name="slide1question4">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <button class="btn btn-primary nextBtn btn-lg" type="button" >Nächster</button>

                                    </div>
                                    <div class="setup-content" id="step-2" data-id="slides">
                                        <div class="form-group">
                                            <label class="control-label">Question 1</label>
                                            <select class="form-control steps" name="slide2question1">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 2 *</label>
                                            <select class="form-control steps" name="slide2question2">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 3 *</label>
                                            <select class="form-control steps" name="slide2question3">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 4 *</label>
                                            <select class="form-control steps" name="slide2question4">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <button class="btn btn-primary  nextBtn btn-lg" type="button" >Nächster</button>
                                    </div>
                                    <div class="setup-content" id="step-3" data-id="slides">
                                        <div class="form-group">
                                            <label class="control-label">Question 1</label>
                                            <select class="form-control steps" name="slide3question1">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 2 *</label>
                                            <select class="form-control steps" name="slide3question2">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 3 *</label>
                                            <select class="form-control steps" name="slide3question3">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 4 *</label>
                                            <select class="form-control steps" name="slide3question4">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <button class="btn btn-primary nextBtn btn-lg" type="button" >Nächster</button>
                                    </div>
                                    <div class="setup-content" id="step-4" data-id="slides">
                                        <div class="form-group">
                                            <label class="control-label">Question 1</label>
                                            <select class="form-control steps" name="slide4question1">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 2 *</label>
                                            <select class="form-control steps" name="slide4question2">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 3 *</label>
                                            <select class="form-control steps" name="slide4question3">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 4 *</label>
                                            <select class="form-control steps" name="slide4question4">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <button class="btn btn-primary nextBtn btn-lg" type="button" >Nächster</button>
                                    </div>
                                    <div class="setup-content" id="step-5" data-id="slides">
                                        <div class="form-group">
                                            <label class="control-label">Question 1</label>
                                            <select class="form-control steps" name="slide5question1">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 2 *</label>
                                            <select class="form-control steps" name="slide5question2">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 3 *</label>
                                            <select class="form-control steps" name="slide5question3">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 4 *</label>
                                            <select class="form-control steps" name="slide5question4">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <button class="btn btn-primary nextBtn btn-lg" type="button" >Nächster</button>
                                    </div>
                                    <div class="setup-content" id="step-6" data-id="slides">
                                        <div class="form-group">
                                            <label class="control-label">Question 1</label>
                                            <select class="form-control steps" name="slide6question1">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 2 *</label>
                                            <select class="form-control steps" name="slide6question2">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 3 *</label>
                                            <select class="form-control steps" name="slide6question3">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 4 *</label>
                                            <select class="form-control steps" name="slide6question4">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <button class="btn btn-primary nextBtn btn-lg" type="button" >Nächster</button>
                                    </div>
                                    <div class="setup-content" id="step-7" data-id="slides">
                                        <div class="form-group">
                                            <label class="control-label">Question 1</label>
                                            <select class="form-control steps" name="slide7question1">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 2 *</label>
                                            <select class="form-control steps" name="slide7question2">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 3 *</label>
                                            <select class="form-control steps" name="slide7question3">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 4 *</label>
                                            <select class="form-control steps" name="slide7question4">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <button class="btn btn-primary nextBtn btn-lg" type="button" >Nächster</button>
                                    </div>
                                    <div class="setup-content" id="step-8" data-id="slides">
                                        <div class="form-group">
                                            <label class="control-label">Question 1</label>
                                            <select class="form-control steps" name="slide8question1">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 2 *</label>
                                            <select class="form-control steps" name="slide8question2">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 3 *</label>
                                            <select class="form-control steps" name="slide8question3">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label">Question 4 *</label>
                                            <select class="form-control steps" name="slide8question4">
                                                <option value="Ja">Ja</option>
                                                <option value="Nein">Nein</option>
                                                <option value="Trifftnichtzu">Trifft nicht zu</option>
                                            </select>
                                        </div>
                                        <button class="btn btn-primary nextBtn btn-lg" type="button" >Nächster</button>
                                    </div>

                                    <div class="setup-content report-message" id="step-9">


                                    </div>

                                    <input type="hidden" name="action" value="custom_action">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="separator"></div>
        <section class="homepage-posts section_padder ">
            <div class="container">
                <div class="m-top m-bottom p-bottom">
                    <?php the_field('section_1'); ?>
                </div>
                <div class="homepage-posts-iframe  p-top m-top m-bottom">
                    <img src="<?php echo get_template_directory_uri() ?>/images/homepage_posts.png"/>
                </div>
            </div>
        </section>
        <section class="newsletter m-top">
            <div class="container">
                <div class="newsletter-box">
                    <div class="row">
                        <div class="col-lg-7 col-md-8">
                            <h3 class="text-dark">Unser kostenloser Newsletter</h3>
                            <p class="text-normal">Verpassen Sie Ihr Thema nicht, abonnieren Sie unseren Newsletter, Blog sowie unser Kundenmagazine oder laden Sie unsere App runter, so dass Sie künftig aus erster Hand erfahren, wenn Kunden erfolgreich Angelegenheiten planen.</p>
                        </div>
                        <div class="col-lg-5 col-md-4">
                            <div class="form-group">
                                <input class="form-control" placeholder="Email Address *"/>
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn_black btn-block" value="Bestatigen"/>
                            </div>
                        </div>
                        
                    </div>
                    <p class="text-center small m-top">Sie können diesen kostenlosen Informationen jederzeit abbestellen und der Verwendung Ihrer Daten für Werbezwecke widersprechen.</p>
                </div>
            </div>
        </section>
        <div class="separator"></div>
        <section class="homepage-contact section_padder">
            <div class="container">
                <div class="m-top m-bottom">
                    <?php the_field('section_2'); ?>
                </div>

                <div class="map p-bottom">
                    <div class="map_image">
                        <?php
                        if (function_exists('ot_get_option')) {
                            $addresses = ot_get_option('add_address');
                            $num_of_addresses = count($addresses);
                            //print_r($num_of_addresses);
                            //print_r($addresses);
                        }
                        ?>
                        <?php for ($address = 0; $address < $num_of_addresses; $address++) { ?>
                            <a href="javascript:void(0);" class="popover-link popover-link-<?php echo $address ?>" data-placement="left"  rel="popover"
                               data-content="<div class='media'>
                               <div class='media-body'>
                               <h4 class='text-dark'><?php echo $addresses[$address]['title'] ?></h4>
                               <?php echo $addresses[$address]['description'] ?>
                               </div>
                               </div>"
                               data-html="true" class="inline-block m-left medium text-blue text-underline"> <img src="<?php echo get_template_directory_uri() ?>/images/circle.svg"/> </a>
                           <?php }
                           ?>
                        <img src="<?php echo get_template_directory_uri() ?>/images/map.svg"/>
                    </div>
                </div>
                <div class="m-top p-top">
                    <div class="col-md-8 col-md-offset-2" style="font-size: 19px;">
                        <?php the_field('section_3'); ?>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </section>
        <div class="separator"></div>
        <section class="directors section_padder">
            <div class="container">
                <div class="m-bottom">
                    <?php the_field('section_4'); ?>
                </div>
                <div class="team_members p-top">
                    <div class="row">
                        <?php
                        /*
                         *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
                         *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
                         *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
                         */
                        $post_objects = get_field('select_team_members');

                        if ($post_objects):
                            ?>
                            <?php
                            $count = 1;
                            ?>
                            <?php foreach ($post_objects as $post): // variable must be called $post (IMPORTANT) ?>
                                <?php setup_postdata($post); ?>
                                <div class="col-lg-4 col-md-4 col-xs-4">
                                    <div class="member">
                                        <div class="member_image">
                                            <?php the_post_thumbnail(); ?>
                                        </div>
                                        <div class="member_title">
                                            <?php the_field('homepage_message_title') ?>
                                        </div>
                                        <div class="member_message">
                                            <?php the_field('homepage_message') ?>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                $count++;
                            endforeach;
                            ?>
                            <?php wp_reset_postdata(); // IMPORTANT - reset the $post object so the rest of the page works correctly ?>
                            <?php
                        endif;
                        ?>

                    </div>
                </div>
            </div>

        </section>
        <div class="separator"></div>
        <section class="section_padder">
            <div class="container">

                <h3 class="section_title p-top p-bottom">VPZ Key Facts </h3>
                <?php
                if (function_exists('ot_get_option')) {
                    $keyfacts = ot_get_option('key_facts');
                    $num_of_keyfacts = count($keyfacts);
                }
                ?>
                <div class="keyfacts">
                    <?php
                    for ($i = 0; $i < $num_of_keyfacts; $i++) {
                        ?>
                        <div class="keyfact">
                            <div class="key_number">
                                <span class="number">
                                    <?php echo $keyfacts[$i]['key_fact_number'] ?>
                                </span>
                                <span class="icon">
                                    <img src="<?php echo $keyfacts[$i]['keyfact_icon'] ?>" alt="<?php echo $keyfacts[$i]['title'] ?>"/>
                                </span>
                            </div>
                            <div class="description">
                                <?php echo $keyfacts[$i]['title'] ?>
                            </div>
                        </div>
                    <?php }
                    ?>
                </div>

            </div>
        </section>
        <div class="separator"></div>

        <section class="instagram_section section_padder">
            <div class="container">
                <div class="m-top m-bottom">
                    <?php the_field('section_7'); ?>
                </div>
                <div class="instagram_feeds">
                    <?php echo do_shortcode('[instagram-feed]'); ?>
                </div>
            </div>
        </section>
    </div>
</main>
<?php get_footer(); ?>
