
<?php get_header(); ?>

<main role="main" class="category-listing">
    <!-- section -->

    <div class="category-single-title">
        <div class="container">
           <h1><?php _e( 'Author Archives for ', 'html5blank' ); echo get_the_author(); ?></h1>
        </div>
    </div>
    <div class="section-padder">
        <div class="container">
            <?php get_template_part('loopauthor'); ?>

            <?php get_template_part('pagination'); ?>
        </div>
    </div>
</main>

<?php get_footer(); ?>

