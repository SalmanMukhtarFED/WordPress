<?php /* Template Name: Blog Page Template */ get_header(); ?>
<script>
    jQuery(document).ready(function () {
        jQuery('.overlay').fadeIn();
        setTimeout(function () {
            jQuery('.overlay').fadeOut();
            jQuery('.grid').isotope({
                // options
                itemSelector: '.grid-item'
            });
        }, 500);
    });
</script>

<style>

</style>
<div class="overlay" style="display: none;">
    <div class="loader"><img src="<?php echo get_template_directory_uri(); ?>/images/loader.gif"/></div>
</div>
<main role="main" class="blog-page">
    <!-- section -->
    <section class="banner">

        <div class="text-center blog-page-banner-text">

            <h1><?php the_field('banner_heading') ?></h1>
            <h2><?php the_field('banner_text'); ?></h2>
<!--            <p>Live in an abstract, whimsical, creative place called the TinkerVese... and it is where ideas are born... and then destroyed. And they have to
                reach a critical mass of traction before they can escape the silicon valley echo chamber that contains them in their little universe bubble... LOL.</p>-->
            
            <div class="blog-subscribe">
                <?php echo do_shortcode('[mc4wp_form id="94"]');?>
            </div>
            <div class="clearfix"></div>

        </div>
        </div>

    </section>
    <section class="blog-content">
        <div class="container">
            <?php
            /*
              $width = array(4,8);
              $img = array(1,2);
              for($i = 0; $i <= 12; $i++) {
              $width = array_reverse($width);
              $img = array_reverse($img);
              echo '<div class="row" style="height:400px;margin-bottom:20px;">';
              echo '<div class="col-md-'.$width[0].'">';
              echo '<img src="'.get_template_directory_uri().'/images/image'.$img[0].'.jpg" />';
              echo '</div>';
              echo '<div class="col-md-'.$width[1].'">';
              echo '<img src="'.get_template_directory_uri().'/images/image'.$img[1].'.jpg" />';
              echo '</div>';
              echo '<div class="clearfix"></div>';
              echo '</div>';
              } */
            ?>

            <?php
            $cat_array = get_categories('type=post');
            $count_categories = count($cat_array);
            //var_dump($count_categories);
            ?>
            <ul class="nav nav-tabs" role="tablist">
                <?php
                for ($i = 0; $i < $count_categories; $i++) {
                    if ($i == 0) {
                        $class = "active";
                    } else {
                        $class = "";
                    }
                    ?>
                    <li class="<?php echo $class; ?>">
                        <a data-toggle="tab" href="#tab-<?php echo $i; ?>" class="tab-link " aria-controls="tab-<?php echo $i; ?>">
                            <?php echo $cat_array[$i]->name; ?>
                        </a>
                    </li>
                <?php }
                ?>
            </ul>
            <div class="tab-content section-padder">
                <?php
                for ($i = 0; $i < $count_categories; $i++) {
                    if ($i == 0) {
                        $class = "active in";
                    } else {
                        $class = "";
                    }
                    ?>
                    <?php
                    if ($cat_array[$i]->slug == 'featured') {
                        ?>
                        <div  role="tabpanel" id="tab-<?php echo $i; ?>" class="tab-pane fade <?php echo $class; ?>">
                            <?php $current_category = $cat_array[$i]->slug ?>
                            <?php
                            $args = array('post_type' => 'post', 'order' => 'ASC', 'category_name' => $current_category);
                            $loop = new WP_Query($args);
                            $width = array(4, 8);
                            $counter = 1;
                            while ($loop->have_posts()) : $loop->the_post();
                                if ($counter % 2) {
                                    echo '<div class="row" style="height:400px;margin-bottom:20px;">';
                                }
                                echo '<div class="col-md-' . $width[0] . ' col-sm-' . $width[0] . ' m-bottom">';
                                echo '<a href="' . get_the_permalink() . '">' . get_the_post_thumbnail() . '</a>';
                                echo '</div>';
                                if (!($counter % 2)) {
                                    echo '<div class="clearfix"></div>';
                                    echo '</div>';
                                } else {
                                    $width = array_reverse($width);
                                }
                                $counter++;
                            endwhile;
                            wp_reset_query();
                            if (($counter - 1) % 2) {
                                echo '<div class="clearfix"></div>';
                                echo '</div>';
                            }
                            ?>
                        </div>
                        <?php
                    } else {
                        ?>
                        <div  role="tabpanel" id="tab-<?php echo $i; ?>" class="tab-pane fade <?php echo $class; ?>">
                            <div class="grid">
                                <div class="row">
                                    <?php $current_category = $cat_array[$i]->slug ?>
                                    <?php
                                    $args = array('post_type' => 'post', 'order' => 'ASC', 'category_name' => $current_category);
                                    $loop = new WP_Query($args);
                                    $width = array(4, 8);
                                    $counter = 1;
                                    while ($loop->have_posts()) : $loop->the_post();
                                        ?>
                                        <div class="grid-item" href="<?php the_permalink(); ?>">
                                            <div class="blog-post-grid">
                                                <div class="blog-thumbnail">
                                                    <?php the_post_thumbnail(); ?>
                                                </div>
                                                <div class="blog-info-container">
                                                    <div class="blog-info">
                                                        <h4 class="blog-title"><?php the_title(); ?> </h4>
                                                        <p class="blog-excerpt visible-xs"><?php echo the_excerpt(new_excerpt_length_mobile(10)); ?></p>
                                                        <p class="blog-excerpt hidden-xs"><?php echo the_excerpt(new_excerpt_length(30)); ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <?php
                                    endwhile;
                                    wp_reset_query();
                                    ?>
                                </div>
                            </div>
                        </div>
                    <?php } ?>


                <?php }
                ?>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
