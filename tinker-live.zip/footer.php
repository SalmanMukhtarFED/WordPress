<!-- footer -->
<footer class="footer" role="contentinfo">
    
    <div class="footer-top">
        <div class="container">
            <div class="col-md-6 col-sm-6">
                <?php dynamic_sidebar('first-footer-widget-area'); ?>
            </div>
            <div class="col-md-6 col-sm-6">
                <?php dynamic_sidebar('second-footer-widget-area'); ?>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <div class="footer-bottom">
        
        <div class="container">
            <!-- copyright -->
            <div class="footer-logo text-center p-top p-bottom m-top m-bottom">
                <a href="/"><img src="<?php echo get_template_directory_uri() ?>/images/footer-logo.png" alt="<?php bloginfo('name'); ?>"/></a>
            </div>
            <div class="footer-copyright">
                <p class="copyright text-center">
                    <span class="pink inline-block mr-right">(801) 228-0813</span>
                    <span class="inline-block mr-right">/</span>
                    <a class="pink inline-block" href="#">hello@tinkerventures.co</a>
                </p>
                <p class="copyright text-center">
                    <span class="inline-block mr-right">[c] copyright 2016</span>
                    <span class="inline-block mr-right">/</span>
                    <span class="inline-block mr-right">tinker inc.</span>
                    <span class="inline-block mr-right">/</span>
                    <span class="inline-block"> all rights reserved</span>

                </p>
            </div>
            <!-- /copyright -->
        </div>
    </div>
    <div class="footer-bg">
        
    </div>

</footer>
<!-- /footer -->



<?php wp_footer(); ?>

<!-- analytics -->
<script>
    (function (f, i, r, e, s, h, l) {
        i['GoogleAnalyticsObject'] = s;
        f[s] = f[s] || function () {
            (f[s].q = f[s].q || []).push(arguments)
        }, f[s].l = 1 * new Date();
        h = i.createElement(r),
                l = i.getElementsByTagName(r)[0];
        h.async = 1;
        h.src = e;
        l.parentNode.insertBefore(h, l)
    })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');
    ga('create', 'UA-XXXXXXXX-XX', 'yourdomain.com');
    ga('send', 'pageview');
</script>

</body>
</html>
