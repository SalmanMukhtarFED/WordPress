<?php /* Template Name: Front Page */ get_header(); ?>
<style>
    .testimonials-section::after{
        background-attachment: scroll;
        background-clip: border-box;
        background-color: rgba(0, 0, 0, 0);
        background-image: url("<?php the_field('testimonial_client_image') ?>");
        background-origin: padding-box;
        background-position: 30% 0;
        background-repeat: no-repeat;
        background-size:cover;
        content: "";
        height: 100%;
        position: absolute;
        right: 0;
        top: 0;
        width: 47%;
        
    }
</style>
<main role="main" class="home">
    <!-- section -->
    <section class="banner">
        <div class="mobile-bg-overlay visible-xs"></div>
        <div class="container">
            <div class="banner-text">
                <div class="col-md-9 col-sm-9">
                    <h1><?php the_field('banner_heading') ?></h1>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-5 col-sm-5">
                    <h3><a class="see-projects border-btn" href="/contact/">Talk to an engineer</a></h3>
                    <a href="#" class="inline-block down-scroll m-top"><img src="<?php echo get_template_directory_uri() ?>/images/scroll-arrow.png"/></a>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="tinker-block-image">
            <img src="<?php echo get_template_directory_uri(); ?>/images/tinker-banner-2.png"/>
        </div>
    </section>
    <section class="project-showcase scroll-section" >
        <div class="container">
            <div class="row">
                <div class="project-image">
                    <img src="<?php the_field('project_image'); ?>" alt="<?php the_field('project_title'); ?>"/>
                </div>
                <div class="projct-detail">
                    <div class="project-logo">
                        <img src="<?php the_field('project_logo'); ?>"/>
                    </div>
                    <div class="project-title">
                        <h2><?php the_field('project_title'); ?></h2>
                    </div>
                    <div class="project-title">
                        <?php the_field('project_description'); ?>
                    </div>
                    <div class="project-techstack">
                        <h3><?php the_field('techstack'); ?></h3>
                    </div>
                    <a class="see-projects border-btn" href="<?php the_field('projects_page_link'); ?>"><?php the_field('projects_cta_text'); ?></a>
                    <div class="projects-count">
                        <img src="<?php echo get_template_directory_uri() ?>/images/projects-count.jpg"/>  
                    </div>
                </div>

                <div class="clearfix"></div>
            </div>
        </div>
    </section>
    <!-- /section -->
    <section class="services-section">
        <div class="container">
            <div class="bg-container">
                <div class="services-text">
                    <div class="services-intro">
                        <h2><?php the_field('section_title') ?></h2>
                    </div>
                    <div class="services-description">
                        <p><?php the_field('description') ?></p>
                    </div>
                    <div class="service-icons visible-xs hidden-md hidden-sm hidden-lg">
                        <img src="<?php echo get_template_directory_uri() ?>/images/service-icons.jpg"/>
                    </div>
                    <a class="solid-btn" href="http://tinkerventures.co/services/">See All services</a>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>

    <section class="team-section">
        <div class="container">
            <div class="team-content">
                <div class="experience inline-block">
                    <div class="experiece-image">
                        <img src="<?php echo get_template_directory_uri() ?>/images/icon_experience.png"/>
                        <span class="count"><?php the_field('experience') ?></span>
                    </div>
                    <h3>/* years experience */</h3>
                </div>
                <div class="years inline-block">
                    <div class="experiece-image">
                        <img src="<?php echo get_template_directory_uri() ?>/images/icon_experts.png"/>
                        <span class="count"><?php the_field('total_employees') ?></span>
                    </div>
                    <h3>/* experts */</h3>
                </div>
                <div class="team-text inline-block">
                    <h2><?php the_field('team_titile'); ?></h2>
                    <p><?php the_field('team_description'); ?></p>
                    <a class="border-btn" href="<?php the_field('team_page_link'); ?>"><?php the_field('team_cta_text'); ?></a>
                </div>
            </div>
        </div>
    </section>
    <section class="testimonials-section section-padder" style="">
        <div class="mobile-bg-overlay visible-xs visible-sm"></div>
        <div class="container">
            <div class="row">
                <div class="testimonials-home">
                    <div class="col-md-6 col-sm-6">
                        <div class="app-logo p-bottom">
                            <img src="<?php the_field('testimonial_app_logo'); ?>"/>
                        </div>
                        <div class="testimonial-text">
                            <h2><?php the_field('testimonial_text'); ?></h2>
                        </div>
                        <h3 class="text-right mr-top"><?php the_field('testimonial_client_name'); ?></h3>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
    <section class="blog-section section-padder">
        <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-md-6 col-md-offset-3 col-sm-offset-3">
                    <div class="blog-text">
                        <h2 class="text-center"><?php the_field('blog_section_title'); ?></h2>
                        <p><?php the_field('blog_section_description'); ?></p>
                    </div>
                    <div class="text-center">
                        <a class="border-btn" href="#">Read Our Blog</a>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>
    <section class="quote section-padder">
        <div class="mobile-bg-overlay"></div>
        <div class="container">
            <div class="quote-text">
                <h2><?php the_field('quote_text'); ?></h2>
                <h3 class="text-white"><?php the_field('quote_author'); ?></h3>
                <a href="<?php the_field('quote_cta'); ?>" class="solid-btn"><?php the_field('quote_cta_text'); ?></a>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
