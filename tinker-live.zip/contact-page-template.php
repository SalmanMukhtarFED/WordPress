<?php /* Template Name: Contact Page */ get_header(); ?>

<main role="main" class="contact-page">

    <section class="contact">
        <div class="contactbg hidden-xs"></div>
        <div class="container">
            <div class="row">
                <div class="contact-form">
                    <div class="col-md-6 col-sm-6 col-lg-6  col-md-offset-6 col-sm-offset-6 col-lg-offset-6">
                        <h1><?php the_field('banner_heading') ?></h1>
                        <h3><?php the_field('banner_text'); ?></h3>
                        <div class="form-wrapper p-top p-bottom">
                            <?php
                            $contact_form = get_field('contact_form_shortcode');
                            echo do_shortcode($contact_form);
                            ?>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
