<?php get_header(); ?>

<main role="main">
    <!-- section -->
    <section class="page-not-found">
        <div class="container">
            <h1>404</h1>
            <h2>Sorry! The page you are looking for could not be found.</h2>
        </div>
        <div class="container">
            <div class="broken-tinker">
                <div class="col-md-4 col-sm-4 col-xs-6 col-md-offset-4 col-sm-offset-4 col-xs-offset-3">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/Tinker_3.svg"/>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="col-md-8 col-md-offset-2 icon-links">
            <a class="col-md-4 col-sm-4" href="/">
                <div class="icon-link text-center">
                    <div class="icon">
                        <i class="fa fa-home"></i>
                    </div>
                    <div class="icon-text">
                        Home
                    </div>
                </div>
            </a>
            <a class="col-md-4 col-sm-4" href="/services">
                <div class="icon-link text-center">
                    <div class="icon">
                        <i class="fa fa-list"></i>
                    </div>
                    <div class="icon-text">
                        Services
                    </div>
                </div>
            </a>
            <a class="col-md-4 col-sm-4" href="/contact">
                <div class="icon-link text-center">
                    <div class="icon">
                        <i class="fa fa-volume-control-phone"></i>
                    </div>
                    <div class="icon-text">
                        Contact
                    </div>
                </div>
            </a>
            <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
    </section>
    <!-- /section -->
</main>

<?php get_footer(); ?>
