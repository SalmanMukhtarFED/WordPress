<?php /* Template Name: Unsubscribe Page */ get_header(); ?>

<main role="main">
    <!-- section -->
    <section class="page-not-found">
        <div class="container">
            <h1 style="font-size: 42px; line-height: 50px;">You have been successfully <br class="visible-lg visible-md"/>unsubscribed from our email list.</h1>
            <h1 class="m-top"><span class="sad-cat">&#x1f62d;</span></h1>
        </div>
        <div class="container">
            <div class="broken-tinker">
                <div class="col-md-4 col-sm-4 col-xs-6 col-md-offset-4 col-sm-offset-4 col-xs-offset-3">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/Tinker_3.svg"/>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="col-md-8 col-md-offset-2 icon-links">
            <h2 class="text-center">We are sorry to see you go.</h2>
            <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
    </section>
    <!-- /section -->
</main>

<?php get_footer(); ?>
