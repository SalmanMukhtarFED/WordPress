<?php get_header(); ?>
<section class="category-archive-list section-padder">
    <?php
    if (is_category()) {
        $cat = get_query_var('cat');
        $current_category = get_category($cat);
        $category_slug = $current_category->slug;
    }
    ?>
    <?php
    $args = array('post_type' => 'portfolio', 'order' => 'ASC', 'category_name' => $category_slug);
    $loop = new WP_Query($args);
    $count = 1;
    while ($loop->have_posts()) : $loop->the_post();
        ?>
        <a class="portfolio-item-wrapper" href="<?php the_permalink(); ?>">
            <div class="item-thumbnail">
                <?php the_post_thumbnail(); ?>
            </div>
            <div class="item-info-container">
                <div class="item-info">
                    <p class="project-title"><?php the_title(); ?> </p>
                    <p class="project-tagline"><?php the_field('project_tagline') ?></p>
                </div>
            </div>
        </a>
        <?php
        $count++;
    endwhile;
    wp_reset_query();
    ?>

    <?php get_template_part('pagination'); ?>
</section>

