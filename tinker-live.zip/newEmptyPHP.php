<p class="text-center">
             
                </p>
                <div class="row hilight-list">

                    <div class="col-md-6">
                        <p>
                            Accelerated development and launch timeline
                        </p>
                        <p>
                            <img src="<?php echo get_template_directory_uri(); ?>/images/users.png" alt="">
                            Operational content creation costs cut by 70%
                        </p>
                    </div>
                    <div class="col-md-6">
                        <p>
                            Boost in sales and ROI
                        </p>
                        <p>
                           95% positive feedback from new and existing students

                        </p>
                    </div>				
                </div>