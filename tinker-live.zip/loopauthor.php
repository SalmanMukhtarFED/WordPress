<div class="grid">

    <?php if (have_posts()): while (have_posts()) : the_post(); ?>
            <div class="grid-item" href="<?php the_permalink(); ?>">
                <div class="blog-post-grid">
                    <div class="blog-thumbnail">
                        <?php the_post_thumbnail(); ?>
                    </div>
                    <div class="blog-info-container">
                        <div class="blog-info">
                            <h4 class="blog-title"><?php the_title(); ?> </h4>
                            <p class="blog-excerpt visible-xs"><?php echo the_excerpt(new_excerpt_length_mobile(10)); ?></p>
                            <p class="blog-excerpt hidden-xs"><?php echo the_excerpt(new_excerpt_length(30)); ?></p>
                        </div>
                    </div>
                </div>
            </div>

        <?php endwhile; ?>

    <?php else: ?>

        <!-- article -->
        <div class="section-padder">
            <h2><?php _e('Sorry, nothing to display.', 'html5blank'); ?></h2>
        </div>
        <!-- /article -->



    <?php endif; ?>
</div>
