<?php get_header(); ?>
<?php if (get_post_type() == 'portfolio') { ?>

    <main role="main" class="study-page landing-page">
        <!-- section -->
        <section class="section-padder tutoring_app">
            <div class="container">
                <div class="logo text-center">
                    <img src="<?php the_field('client_testimonial_logo'); ?>"
                </div>

                <h3 class="m-top"><?php the_field('project_tagline'); ?></h3>
                <div class="laptop_img m-top p-top text-center">
                    <img src="<?php the_field('project_main_image'); ?>"/>
                </div>
                <div class="text m-top p-top">
                    <?php if (have_posts()): while (have_posts()) : the_post(); ?>
                            <?php the_content(); ?>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <hr/>
        <section class="section-padder key_fact text-center">
            <div class="container">
                <div class="text-center  section-title m-bottom p-bottom ">
                    <h2 class="text-uppercase">Key Facts</h2>
                </div>
                <div class="row m-bottom">
                    <div class="col-md-4">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/platform.png" alt="Platform">
                        <h3 class="text-bold">Platform</h3>
                        <p>/* <?php the_field('platform'); ?> */</p>
                    </div>
                    <div class="col-md-4">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/industry.png" alt="Industry">
                        <h3>Industry</h3>
                        <p>/* <?php the_field('industry'); ?> */</p>
                    </div>
                    <div class="col-md-4">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/location.png" alt="Location">
                        <h3>Location</h3>
                        <p>/* <?php the_field('location'); ?> */</p>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="row m-top">
                    <div class="col-md-10 col-md-offset-1">
                        <div class="col-md-6">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/tech_used.png" alt="Tech Used">
                            <h3>Tech Used</h3>
                            <p>
                                /* <?php the_field('tech_stack'); ?> */
                            </p>
                        </div>
                        <div class="col-md-6">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/thinker_team.png" alt="Thinker Team">
                            <h3>Tinker Team</h3>
                            <p>/* <?php the_field('team_members_involved'); ?> */</p>
                        </div>				
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </section>
        <section class="section-padder edge_solution" style="padding-bottom:0;">
            <div class="container">
                <div class="section-title text-center">
                    <h2 class="text-uppercase">The <?php the_title(); ?> Solution</h2>
                </div>
                <div id="portfolio-carousel" class="owl-carousel owl-theme section-padder text-center">
                    <?php
                    if (get_field('portfolio_image_1') != "") {
                        ?>
                        <div class="item">
                            <img src="<?php the_field('portfolio_image_1'); ?>"/>
                        </div>
                    <?php } ?>
                    <?php
                    if (get_field('portfolio_image_2') != "") {
                        ?>
                        <div class="item">
                            <img src="<?php the_field('portfolio_image_2'); ?>"/>
                        </div>
                    <?php } ?>
                    <?php
                    if (get_field('portfolio_image_3') != "") {
                        ?>
                        <div class="item">
                            <img src="<?php the_field('portfolio_image_3'); ?>"/>
                        </div>
                    <?php } ?>
                    <?php
                    if (get_field('portfolio_image_4') != "") {
                        ?>
                        <div class="item">
                            <img src="<?php the_field('portfolio_image_4'); ?>"/>
                        </div>
                    <?php } ?>
                    <?php
                    if (get_field('portfolio_image_5') != "") {
                        ?>
                        <div class="item">
                            <img src="<?php the_field('portfolio_image_5'); ?>"/>
                        </div>
                    <?php } ?>

                </div>
                <div class="row">
                    <?php the_field('solution_provided_by_tinker'); ?>				
                </div>
            </div>
        </section>
        <section class="section-padder edge_solution">
            <div class="container">
                <div class="section-title  m-bottom p-bottom text-center">
                    <h2 class="text-uppercase">Project Hilights</h2>
                </div>
                <?php the_field('project_highlights'); ?>
                <div class="testimoial">
                    <p>
                        <?php the_field('client_testimonial_about_project'); ?>
                    </p>
                    <div class="logo text-center">
                        <img src="<?php the_field('client_testimonial_logo'); ?>"
                    </div>
                </div>
            </div>
        </section>
        <section class="landingpage-cta text-center">
            <div class="container">
                <h1><?php the_field('second_cta_heading'); ?></h1>
                <div class="cta-btn">
                    <a href="<?php the_field('second_cta_button'); ?>" class="solid-btn"><?php the_field('second_cta_button_text'); ?></a>
                </div>
            </div>
        </section>
    </main>
<?php } else {
    ?>
    <main role="main">
        <!-- section -->
        <section>
            <?php if (have_posts()): while (have_posts()) : the_post(); ?>
                    <div class="blog-single">
                        <div class="blog-single-title">
                            <div class="container">
                                <h1><?php the_title(); ?></h1>
                                <div class="blog-meta text-center">
                                    <!-- post details -->
                                    <span class="date"><?php the_time('F j, Y'); ?></span>
                                    <span class="author"><?php _e('Published by', 'html5blank'); ?> <?php the_author_posts_link(); ?></span>
                                </div>
                                <div class="categories">
                                    <p><?php
                                        the_category(); // Separated by commas  
                                        ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="blog-single-content section-padder">
                            <div class="container">
                                <div class="col-md-6 col-sm-6">
                                    <div class="blog-single-image">
                                        <?php if (has_post_thumbnail()) : // Check if Thumbnail exists   ?>
                                            <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
                                                <?php the_post_thumbnail(); // Fullsize image for the single post   ?>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php 
                                if (has_post_thumbnail()){
                                    $container_class="col-md-6 col-sm-6";
                                }else{
                                    $container_class="col-md-12 col-sm-12";
                                }
                                ?>
                                <div class="<?php echo $container_class; ?>">
                                    <div class="blog-single-text">
                                        <h2><?php the_title(); ?></h2>
                                        <?php the_content(); // Dynamic Content   ?>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="prev_post">
                                <?php
                                $prepo = get_previous_post();
                                $prepoid = $prepo->ID;
                                $pre_post_url = get_permalink($prepoid);
                                ?>
                                <a href="<?php echo $pre_post_url ?>"><i class="fa fa-angle-left"></i></a>
                            </div>
                            <div class="next_post">
                                <?php
                                $nepo = get_next_post();
                                $nepoid = $nepo->ID;
                                $next_post_url = get_permalink($nepoid);
                                ?>
                                <a href="<?php echo $next_post_url ?>"><i class="fa fa-angle-right"></i></a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>

            <?php else: ?>

                <!-- article -->
                <article>

                    <h1><?php _e('Sorry, nothing to display.', 'html5blank'); ?></h1>

                </article>
                <!-- /article -->

            <?php endif; ?>

        </section>
        <!-- /section -->
    </main>
<?php } ?>

<?php get_footer(); ?>
