<?php /* Template Name: Landing Pages */ get_header(); ?>

<script>
    jQuery(document).ready(function () {

        jQuery("#testimonials-carousel").owlCarousel({
            navigation: true, // Show next and prev buttons
            slideSpeed: 300,
            paginationSpeed: 400,
            singleItem: true,
            pagination: false

                    // "singleItem:true" is a shortcut for:
                    // items : 1, 
                    // itemsDesktop : false,
                    // itemsDesktopSmall : false,
                    // itemsTablet: false,
                    // itemsMobile : false

        });

    });

</script>
<style>
    .banner{
        background: url("<?php the_post_thumbnail_url() ?>") no-repeat 100% 0;
    }
</style>
<main role="main" class="home landing-page">
    <!-- section -->
    <section class="banner">
        <div class="mobile-bg-overlay visible-xs"></div>
        <div class="container">
            <div class="banner-text text-center">
                <h1 class=""><?php the_field('banner_heading') ?></h1>

                <div class="banner-subheading">
                    <h2><?php the_field('banner_text'); ?></h2>
                </div>
                <h3 class=""><a class="see-projects border-btn" href="/contact/">Start Your Project</a></h3>
                <p class="text-center"><a href="#" class="inline-block down-scroll m-top"><img src="<?php echo get_template_directory_uri() ?>/images/scroll-arrow.png"/></a></p>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>
    <section class="testimonials scroll-section">
        <div class="container">
            <div class="section-title p-bottom m-bottom">
                <h2>Testimonials</h2>
            </div>

            <?php
            /*
             *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
             *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
             *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
             */

            $post_objects = get_field('testimonials');

            if ($post_objects):
                ?>
                <div class="testimonials-carousel">
                    <div class="testimonial-icon text-center">
                        <i class="fa fa-quote-left"></i>
                    </div>
                    <div id="testimonials-carousel" class="owl-carousel owl-theme">

                        <?php foreach ($post_objects as $post): // variable must be called $post (IMPORTANT) ?>
                            <?php setup_postdata($post); ?>
                            <div class="item">
                                <div class="testimonial-text">
                                    <?php the_content(); ?>
                                </div>
                                <div class="testimonial-logo">
                                    <?php the_post_thumbnail(); ?>

                                </div>
                            </div>
                        <?php endforeach; ?>

                    </div>
                </div>
                <?php wp_reset_postdata(); // IMPORTANT - reset the $post object so the rest of the page works correctly ?>
                <?php
            endif;
            ?>

        </div>
    </section>
    <section class="landing-casestudies m-top p-top">
        <div class="container">
            <div class="text-center">
                <h1 class=""><?php the_field('case_study_section') ?></h1>

                <div class="banner-subheading m-top">
                    <h2><?php the_field('case_study_subtitle_section'); ?></h2>
                </div>
            </div>
        </div>
        <div class="casestudies m-top p-top">
            <?php
            /*
             *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
             *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
             *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
             */

            $post_objects = get_field('landing_page_case_studies');

            if ($post_objects):
                ?>
                <?php
                $count = 0;
                ?>
                <?php foreach ($post_objects as $post): // variable must be called $post (IMPORTANT) ?>

                    <?php setup_postdata($post); ?>
                    <?php
                    if ($count % 2 == 0) {
                        ?>
                        <div class="casestudy">
                            <div class="casestudy-image visible-xs">
                                <?php the_post_thumbnail(); ?>
                            </div>
                            <div class="casestudy-text">
                                <div class="title section-title"><h2><?php the_title(); ?></h2></div>
                                <div class="short-desc m-top m-bottom"><?php the_content(); ?></div>
                                <div class="view-casestudy">
                                    <a href="<?php the_field('case_study_link_to'); ?>" class="border-btn">See the success story</a>
                                </div>
                            </div>
                            <div class="casestudy-image hidden-xs">
                                <?php the_post_thumbnail(); ?>
                            </div>
                            <div class="clearfix"></div>
                        </div>

                        <?php
                    } else {
                        ?>
                        <div class="casestudy">
                            <div class="casestudy-image">
                                <?php the_post_thumbnail(); ?>
                            </div>
                            <div class="casestudy-text">
                                <div class="title section-title"><h2><?php the_title(); ?></h2></div>
                                <div class="short-desc m-bottom m-top"><?php the_content(); ?></div>
                                <div class="view-casestudy">
                                    <a href="<?php the_field('case_study_link_to'); ?>" class="border-btn">See the success story</a>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    <?php } ?>
                    <?php $count++; ?>
                <?php endforeach; ?>
                <?php wp_reset_postdata(); // IMPORTANT - reset the $post object so the rest of the page works correctly ?>
                <?php
            endif;
            ?>
        </div>
    </section>
    <section class="landingpage-cta text-center">
        <div class="container">
            <h1><?php the_field('first_cta_title'); ?></h1>
            <div class="cta-btn">
                <a href="<?php the_field('first_cta_button'); ?>" class="solid-btn"><?php the_field('first_cta_button_text'); ?></a>
            </div>
        </div>
    </section>
    <section class="keystrengths-section p-bottom m-bottom">
        <div class="container">
            <div class="keystrengths">
                <div class="image hidden-xs">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/keystrengths.png"/>
                </div>
                <div class="keystrengths-mobile visible-xs">
                        Key Strengths
                    </div>
                <div class="strengths">
                    
                    <div class="row">
                        <?php
                        /*
                         *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
                         *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
                         *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
                         */

                        $post_objects = get_field('landing_page_key_strengths');

                        if ($post_objects):
                            ?>
                            <?php
                            $count = 1;
                            ?>
                            <?php foreach ($post_objects as $post): // variable must be called $post (IMPORTANT) ?>
                                <?php setup_postdata($post); ?>
                                <div class="col-md-4 col-sm-4 col-lg-4">
                                    <div class="title">
                                        <h2><?php the_title(); ?></h2>
                                    </div>
                                    <div class="text">
                                        <?php the_content(); ?>
                                    </div>
                                </div>
                                <?php
                                $count++;
                            endforeach;
                            ?>
                            <?php wp_reset_postdata(); // IMPORTANT - reset the $post object so the rest of the page works correctly ?>
                            <?php
                        endif;
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="landingpage-cta text-center">
        <div class="container">
            <h1><?php the_field('second_cta_heading'); ?></h1>
            <div class="cta-btn">
                <a href="<?php the_field('second_cta_button'); ?>" class="solid-btn"><?php the_field('second_cta_button_text'); ?></a>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
