<?php /* Template Name: Team Page */ get_header(); ?>

<script>
    jQuery(document).ready(function () {
        setTimeout(function () {
            var markCubanHeight = jQuery('.markcuban-image img').height();
            console.log(markCubanHeight);
            jQuery('.markcuban').css('min-height', markCubanHeight);

            var markCubanBannerMargin = markCubanHeight / 5;

            var quote_height = jQuery('.markcuban .quote-text').height();

            var remHeight = markCubanHeight - quote_height;
            remHeight = (remHeight / 2) - 50;

            jQuery('.markcuban .quote-text').css('top', remHeight);
        },3000);
    });

    jQuery(window).resize(function () {
        var markCubanHeight = jQuery('.markcuban-image img').height();
        console.log(markCubanHeight);
        jQuery('.markcuban').css('min-height', markCubanHeight);
        var markCubanBannerMargin = markCubanHeight / 5;

        var quote_height = jQuery('.markcuban .quote-text').height();

        var remHeight = markCubanHeight - quote_height;
        remHeight = (remHeight / 2) - 50;

        jQuery('.markcuban .quote-text').css('top', remHeight / 2);
    });

</script>
<main role="main" class="team-page">
    <!-- section -->
    <section class="banner">
        <div class="container">
            <div class="banner-text">
                <div class="col-md-9 col-sm-9">
                    <h1 class="m-bottom"><?php the_field('banner_heading') ?></h1>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-5 col-sm-5">
                    <h3><?php the_field('banner_text'); ?></h3>
                    <a href="#" class="inline-block m-top down-scroll"><img src="<?php echo get_template_directory_uri() ?>/images/scroll-arrow.png"/></a>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
<!--         <div class="tinker-block-image">
            <img src="<?php// echo get_template_directory_uri(); ?>/images/tinker-banner-2.png"/>
        </div>-->
    </section>
    <section class="scroll-section section-padder team managing-directors">
        <div class="container">
            <div class="section-title p-bottom m-bottom">
                <h2>Managing Directors</h2>
            </div>
            <div class="row">
                <?php
                $args = array('post_type' => 'managing_directors', 'order' => 'ASC');
                $loop = new WP_Query($args);
                $count = 1;
                while ($loop->have_posts()) : $loop->the_post();
                    ?>
                    <div class="col-md-4 col-sm-4 responsive-block-item  m-bottom">
                        <div class="team-text">
                            <div class="image">
                                <?php the_post_thumbnail(); ?>
                            </div>
                            <div class="team-detail">
                                <div class="col-md-7 col-xs-12 col-sm-7">
                                    <div class="team-member-name"><?php the_title(); ?></div>
                                    <div class="team-member-designation"><?php the_field('designation'); ?></div>
                                </div>

                                <div class="col-md-5 col-xs-12 col-sm-5">
                                    <ul class="social-icons text-right">
                                        <li class="inline-block pink mr-right"><a class="pink" href="mailto:<?php the_field('email_address'); ?>"><i class="fa fa-envelope-o"></i></a></li>
                                        <li class="inline-block  "><a class="pink" href="<?php the_field('linkedin'); ?>"><i class="fa fa-linkedin"></i></a></li>
                                    </ul>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <?php
                    if ($count == 3) {
                        ?>
                        <div class="clearfix hidden-xs"></div>
                    <?php }
                    ?>

                    <?php
                    $count++;
                endwhile;
                wp_reset_query();
                ?>
            </div>
        </div>
    </section>
    <section class="scroll-section  team team-members p-bottom">
        <div class="container">
            <div class="section-title p-bottom m-bottom">
                <h2>Team</h2>
            </div>
            <div class="row">
                <?php
                $args = array('post_type' => 'team_members', 'order' => 'ASC');
                $loop = new WP_Query($args);
                $count = 0;
                while ($loop->have_posts()) : $loop->the_post();
                    ?>
                    <div class="col-md-4 col-sm-4 responsive-block-item m-bottom">
                        <div class="team-text">
                            <div class="image">
                                <?php the_post_thumbnail(); ?>
                            </div>
                            <div class="team-detail">
                                <div class="team-member-name"><?php the_title(); ?></div>
                                <div class="team-member-designation"><?php the_field('designation'); ?></div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <?php
                    if ($count == 2) {
                        ?>
                        <div class="clearfix hidden-xs"></div>
                    <?php }
                    ?>

                    <?php
                    $count++;
                endwhile;
                wp_reset_query();
                ?>
            </div>
        </div>
    </section>
    <section class="testimonials-section section-padder" style="background: url(<?php the_field('annual_dinner_team_pic') ?>) no-repeat 100% 85px;">
        <div class="container">
            <div class="row">
                <div class="testimonials-home">
                    <div class="col-md-6 col-sm-6">
                        <div class="">
                            <h1><?php the_field('annual_dinner_section_title'); ?></h1>
                        </div>
                        <div class="testimonial-text p-bottom">
                            <h2><?php the_field('annual_dinner_section_text'); ?></h2>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
    <section class="section-padder team-big-image">

    </section>
    <section class="quote section-padder markcuban">
        <div class="mobile-bg-overlay"></div>
        <div class="container">
            <div class="markcuban-image"><img src="<?php echo get_template_directory_uri(); ?>/images/markcuban-pic-new.jpg"/></div>
            <div class="quote-text">
                <h2><?php the_field('quote_text'); ?></h2>
                <h3 class="text-white"><?php the_field('quote_author'); ?></h3>
                <a href="<?php the_field('quote_cta'); ?>" class="solid-btn"><?php the_field('quote_cta_text'); ?></a>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
