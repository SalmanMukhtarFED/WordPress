<?php /* Template Name: Portfolio Page */ get_header(); ?>
<script>
    jQuery(document).ready(function () {

        jQuery("#testimonials-carousel").owlCarousel({
            navigation: true, // Show next and prev buttons
            slideSpeed: 300,
            paginationSpeed: 400,
            singleItem: true,
            pagination: false

                    // "singleItem:true" is a shortcut for:
                    // items : 1, 
                    // itemsDesktop : false,
                    // itemsDesktopSmall : false,
                    // itemsTablet: false,
                    // itemsMobile : false

        });

    });

</script>
<main role="main" class="portfolio-page landing-page">
    <!-- section -->
    <section class="banner">
        <div class="mobile-bg-overlay visible-xs"></div>
        <div class="container">
            <div class="banner-text">
                <div class="col-md-9 col-sm-9">
                    <h1 class="m-bottom"><?php the_field('banner_heading') ?></h1>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-6 col-sm-5">
                    <h3><?php the_field('banner_text'); ?></h3>
                    <a href="#" class="inline-block m-top down-scroll"><img src="<?php echo get_template_directory_uri() ?>/images/scroll-arrow.png"/></a>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </section>
    <section class="scroll-section section-padder portfolio-tabs">
        
        <div class="container">
            <?php
            $cat_array = get_categories(array('taxonomy' => 'portfoliocats')); //'type=portfolio'
            $count_categories = count($cat_array);
            //var_dump($count_categories);
            ?>
            <div class="row">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                    <?php
                    for ($i = 0; $i < $count_categories; $i++) {
                        if ($i == 0) {
                            $class = "active";
                        } else {
                            $class = "";
                        }
                        ?>
                        <li class="<?php echo $class; ?>">
                            <a data-toggle="tab" href="#tab-<?php echo $i; ?>" class="tab-link" aria-controls="tab-<?php echo $i; ?>">
                                <?php echo ($cat_array[$i]->name); ?>
                            </a>
                        </li>
                    <?php }
                    ?>
                </ul>
                
                <!-- Tab panes -->
                <div class="tab-content section-padder">
                    <?php
                    for ($i = 0; $i < $count_categories; $i++) {
                        if ($i == 0) {
                            $class = "active in";
                        } else {
                            $class = "";
                        }
                        ?>
                        <div role="tabpanel" id="tab-<?php echo $i; ?>" class="tab-pane fade <?php echo $class; ?>">
                            <?php $current_category = $cat_array[$i]->slug ?>
                            <?php
                            
                            $tax_queries = array(
                                array(
                                        'taxonomy' => 'portfoliocats',
                                        'field' => 'term_id',
                                        'terms' => array($cat_array[$i]->term_id)
                                    )
                            );
                                
                            
                            $args = array('post_type' => 'portfolio', 'order' => 'ASC', 'tax_query' => $tax_queries);
                            
                            $loop = new WP_Query($args);
                            
                            $count = 1;
                            while ($loop->have_posts()) : $loop->the_post();
                                ?>
                                <a class="portfolio-item-wrapper" href="<?php the_permalink(); ?>">
                                    <div class="item-thumbnail">
                                        <?php the_post_thumbnail(); ?>
                                    </div>
                                    <div class="item-info-container">
                                        <div class="item-info">
                                            <p class="project-title"><?php the_title(); ?> </p>
                                            <p class="project-tagline"><?php the_field('project_tagline') ?></p>
                                        </div>
                                    </div>
                                </a>
                                <?php
                                $count++;
                            endwhile;
                            wp_reset_query();
                            ?>
                        </div>
                    <?php }
                    ?>
                </div>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
