<!doctype html>
<html <?php language_attributes(); ?> class="no-js">
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <title><?php wp_title(''); ?><?php
            if (wp_title('', false)) {
                echo ' :';
            }
            ?> <?php bloginfo('name'); ?></title>

        <link href="//www.google-analytics.com" rel="dns-prefetch">
        <link href="https://fonts.googleapis.com/css?family=Varela+Round" rel="stylesheet"> 
        <link href="<?php echo get_template_directory_uri(); ?>/img/icons/tinker-favicon.ico" rel="shortcut icon">
        <link href="<?php echo get_template_directory_uri(); ?>/img/icons/touch.png" rel="apple-touch-icon-precomposed">
        <link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Inconsolata:400,700' rel='stylesheet' type='text/css'>
        <link href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css' rel='stylesheet' type='text/css'>
        <link href='<?php echo get_template_directory_uri(); ?>/css/jquery.customSelect.css' rel='stylesheet' type='text/css'>
        <link href='<?php echo get_template_directory_uri(); ?>/css/owl.carousel.css' rel='stylesheet' type='text/css'>
        <link href='<?php echo get_template_directory_uri(); ?>/css/owl.theme.css' rel='stylesheet' type='text/css'>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="<?php bloginfo('description'); ?>">

        <?php wp_head(); ?>
        <script src="https://unpkg.com/isotope-layout@3.0/dist/isotope.pkgd.min.js"></script>

        <script>
// conditionizr.com
// configure environment tests
            conditionizr.config({
                assets: '<?php echo get_template_directory_uri(); ?>',
                tests: {}
            });
        </script>
        <script>
            jQuery(document).ready(function () {
                var h_height = jQuery('.navbar').height();
                //console.log(h_height);

                var s_height = jQuery(window).height();
                // console.log(s_height);

                var rem_height = s_height - h_height;

                jQuery('.banner').css('min-height', rem_height);

                var banner_height = jQuery('.banner-text').height();

                var banner_margin = (rem_height - banner_height) / 2;

                jQuery('.banner-text').css('margin-top', banner_margin);

                jQuery(".down-scroll").click(function () {
                    //$(this).animate(function(){
                    var top_position = jQuery(".scroll-section").offset().top;
                    var top_position = top_position - 70;
                    jQuery('html, body').animate({
                        scrollTop: top_position
                    }, 1000);
                    //});
                });

//                setTimeout(function () {
//                    var pipedrive_exists = jQuery('.pipedriveWebForms iframe').length;
////                    jQuery('.pipedriveWebForms iframe body').css({
////                       background :'#333' 
////                    });
//                    console.log(pipedrive_exists);
//                    if (jQuery('.pipedriveWebForms iframe').contents().find("head") != undefined) {
//                        jQuery('.pipedriveWebForms iframe')
//                                .contents()
//                                .find("head")
//                                .append(
//                                        '<link rel="stylesheet" href="http://tinkerventures.iserver.purelogics.net/wp-content/themes/tinker/css/iframe.css" type="text/css" />');
//                    }
//
//                }, 2000);


                setTimeout(function () {
                    jQuery('.mc4wp-response').fadeOut();
                }, 5000);
                setTimeout(function () {
                    if (jQuery('.mc4wp-response').children().hasClass('mc4wp-notice')) {
                        jQuery('.mc4wp-response').show();
                    }
                }, 2000);

                jQuery('.wpcf7-select').customSelect();
                jQuery("#portfolio-carousel").owlCarousel({
                    navigation: false, // Show next and prev buttons
                    slideSpeed: 300,
                    paginationSpeed: 400,
                    singleItem: true,
                    autoPlay:true
                });


                if (window.location.href.indexOf("success") > -1) {
                    jQuery('.mc4wp-response').fadeIn();
                    jQuery('.mc4wp-response').html("<p>Thank you, your sign-up request was successful! Please check your email inbox to confirm.</p>");

                }

                jQuery('.mailchimp-form .form-control').on('blur', function () {
                    var blurEl = jQuery(this);
                    //console.log('called');
                    setTimeout(function () {
                        blurEl.focus();
                      //  console.log('called focus');
                    }, 10);
                });
                
                jQuery('.grid').isotope({
                    // options
                    itemSelector: '.grid-item'
                });
                

                jQuery('.blog-content .nav-tabs li a').click(function () {
                    jQuery('.overlay').fadeIn();
                    setTimeout(function () {
                        jQuery('.overlay').fadeOut();
                        jQuery('.grid').isotope({
                            // options
                            itemSelector: '.grid-item'
                        });
                    }, 500);
                });

            });


            jQuery(window).resize(function () {
                var h_height = jQuery('.navbar').height();
                // console.log(h_height);
                var s_height = jQuery(window).height();
                //console.log(s_height);

                var rem_height = s_height - h_height;

                jQuery('.banner').css('min-height', rem_height);

                var banner_height = jQuery('.banner-text').height();

                var banner_margin = (rem_height - banner_height) / 2;

                jQuery('.banner-text').css('margin-top', banner_margin);

            });

        </script>

    </head>
    <body <?php body_class(); ?>>
        <!-- header -->
        <header class="header clear" role="banner">
            <nav class="navbar navbar-fixed-top">
                <div class="container">
                    <div class="navbar-header">
                        <button aria-controls="navbar" aria-expanded="false" data-target="#navbar" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a href="/" class="navbar-brand">  <img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" alt="Logo" class="logo-img"></a>
                    </div>
                    <div class="navbar-collapse collapse" id="navbar">
                        <?php html5blank_nav(); ?>
                    </div><!--/.nav-collapse -->
                </div><!--/.container-fluid -->
            </nav>
        </header>
        <!-- /header -->
