<?php /* Template Name: Services Page Template */ get_header(); ?>
<script>
    jQuery(function () {
        jQuery('a[href*="#"]:not([href="#"])').click(function () {
            if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
                var target = jQuery(this.hash);
                target = target.length ? target : jQuery('[name=' + this.hash.slice(1) + ']');

                var top_position = target.offset().top;
                var top_position = top_position - 70;
                if (target.length) {
                    jQuery('html, body').animate({
                        scrollTop: top_position
                    }, 1000);
                    return false;
                }
            }
        });
        jQuery('[data-toggle="tooltip"]').tooltip({trigger: 'manual'}).tooltip('show');
        jQuery(window).on('resize', function () {
            jQuery('[data-toggle="tooltip"]').tooltip({trigger: 'manual'}).tooltip('show');
            //jQuery('[data-toggle="tooltip"]').tooltip(); 
        });

        var height = jQuery('.calculate-minheight').height();
        var height = height + 160;
        jQuery('.apply-minheight').css('min-height', height);

        jQuery(window).resize(function () {
            var height = jQuery('.calculate-minheight').height();
            var height = height + 160;
            jQuery('.apply-minheight').css('min-height', height);
        });
    });
</script>
<script>
    jQuery(document).ready(function () {
        setTimeout(function () {
            var markCubanHeight = jQuery('.markcuban-image img').height();
            console.log(markCubanHeight);
            jQuery('.markcuban').css('min-height', markCubanHeight);

            var markCubanBannerMargin = markCubanHeight / 5;

            var quote_height = jQuery('.markcuban .quote-text').height();

            var remHeight = markCubanHeight - quote_height;
            remHeight = (remHeight / 2) - 50;

            jQuery('.markcuban .quote-text').css('top', remHeight);
        },3000);
        
    });

    jQuery(window).resize(function () {
        var markCubanHeight = jQuery('.markcuban-image img').height();
        console.log(markCubanHeight);
        jQuery('.markcuban').css('min-height', markCubanHeight);
        var markCubanBannerMargin = markCubanHeight/5;
        
         var quote_height = jQuery('.markcuban .quote-text').height();
        
        var remHeight= markCubanHeight-quote_height;
        remHeight = (remHeight/2)-50;
        
        jQuery('.markcuban .quote-text').css('top', remHeight/2);
    });

</script>


<main role="main" class="services-page">
    <!-- section -->
    <section class="banner">

        <div class="text-center">
            <div class="">
                <h1><?php the_field('banner_heading') ?></h1>
            </div>
            <div class="clearfix"></div>
            <div class="">
                <h2><?php the_field('banner_text'); ?></h2>
            </div>
            <div class="process">
                <img src="<?php echo get_template_directory_uri() ?>/images/services-page-process.png"/>
                <a href="#strategy" class="strategy pink"><span class="align-bottom">/* strategy */</span></a>
                <a href="#strategy" class="design pink"><span class="align-bottom">/* design */</span></a>
                <a href="#build" class="build pink"><span>/* build *</span>/</a>
                <a href="#test" class="tinker pink"><span class="align-bottom">/* tinker */</span></a>
                <a href="#test" class="test pink"><span>/* test */</span></a>
                <a href="#launch" class="launch pink"><span class="align-bottom">/* launch */</span></a>
                <a href="#launch" class="scale pink"><span class="">/* scale */</span></a>
                <a href="#launch" class="raise pink"><span class="align-bottom">/* raise */</span></a>
                <a href="#launch" class="repeat pink"><span>/* repeat */</span></a>
            </div>
            <div class="visible-xs">
                <div class="mobile-links">
                    <ul>
                        <li><a href="#strategy" class="pink"> strategy </a></li>
                        <li><a href="#strategy" class="pink"> design </a></li>
                        <li><a href="#build" class="pink"> build </a></li>
                        <li><a href="#test" class="pink"> tinker </a></li>
                        <li><a href="#test" class="pink">test </a></li>
                        <li><a href="#launch" class="pink">launch </a></li>
                        <li><a href="#launch" class="pink">scale </a></li>
                        <li><a href="#launch" class="pink"> raise </a></li>
                        <li class="last"><a href="#launch" class="pink">repeat</a></li>
                    </ul>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </section>

    <section id="strategy" class="scroll-section section-padder product-design">
        <div class="container">
            <div class="product-design-bg">
                <div class="row">
                    <div class="col-md-5">
                        <div class="product-design-content">
                            <h2 class="bordered-heading"><?php the_field('product_design_title'); ?></h2>
                            <div class="text">
                                <?php the_field('product_design_content'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="product-design-image">
                            <img src="<?php the_field('product_design_image'); ?>"/>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>

    <section id="build" class="scroll-section section-padder build">
        <div class="container">
            <div class="product-design-bg">
                <div class="build-box-wrap">
                    <div class="build-text">
                        <div class="product-design-content">
                            <h2 class="bordered-heading"><?php the_field('build_section_title'); ?></h2>
                            <div class="text">
                                <?php the_field('build_section_text'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="build-box bg-black">
                        <div class="service-box ">
                            <h3 class="pink">/* Frontend Development */</h3>
                            <?php the_field('front_end_develop'); ?>
                        </div>
                    </div>
                    <div class="build-box bg-darkgray last">
                        <div class="service-box">
                            <h3 class="pink">/* Mobile Development */</h3>
                            <?php the_field('mobile_development'); ?>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="build-box-wrap">
                    <div class="spacer half-width">&nbsp;</div>
                    <div class="build-box bg-lightgray no-mr-top">
                        <div class="service-box bg-lightgray">
                            <h3 class="pink">/* Web Development */</h3>
                            <?php the_field('web_development'); ?>
                        </div>
                    </div>
                    <div class="build-box bg-pink no-mr-top">
                        <div class="service-box list-inline bg-pink">
                            <h3 class="pink">/* API Integrations */</h3>
                            <?php the_field('api_integrations'); ?>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="build-box-wrap">
                    <div class="spacer half-width">&nbsp;</div>
                    <div class="build-box bg-darkgray no-mr-top">
                        <div class="service-box bg-lightgray">
                            <h3 class="pink">/* 3rd Part Platform */</h3>
                            <?php the_field('3rd_party_platform'); ?>
                        </div>
                    </div>
                    <div class="build-box bg-black no-mr-top">
                        <div class="service-box bg-pink">
                            <h3 class="pink">/* Cloud Technologies */</h3>
                            <?php the_field('cloud_technologies'); ?>
                        </div>
                    </div>
                    <div class="build-box bg-lightgray no-mr-top last">
                        <div class="service-box bg-pink">
                            <h3 class="pink">/* Database */</h3>
                            <?php the_field('database'); ?>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="build-box-wrap">
                    <div class="spacer full-width">&nbsp;</div>
                    <div class="build-box bg-pink no-mr-top">
                        <div class="service-box bg-lightgray">
                            <h3 class="pink">/* Fancy Stuff */</h3>
                            <?php the_field('fancy_stuff'); ?>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
    <section id="test" class="scroll-section test-tinker">
        <div class="two-col">
            <div class="col text-col calculate-minheight">
                <h2 class="bordered-heading"><?php the_field('test_tinker_section_title'); ?></h2>
                <div class="text m-bottom">
                    <?php the_field('test_tinker_section_text'); ?>
                </div>
                <div class="testing-methods">
                    <div class="row">
                        <div class="col-md-6 col-sm-6">
                            <ul>

                                <li>User Testing</li>
                                <li>User Acceptance Testing</li>
                                <li>Regression Testing</li>
                                <li>Load Testing</li>
                                <li>Unit Testing </li>
                            </ul>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <ul>

                                <li>Feature Validation</li>
                                <li>Heat Mapping</li>
                                <li>Product Metrics</li>
                                <li>Product Analytics</li>
                                <li>Pivot</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col image apply-minheight">

            </div>
            <div class="clearfix"></div>
        </div> 
    </section>
    <section id="launch" class="scroll-section test-tinker launch-tinker">
        <div class="two-col">
            <div class="col text-col">
                <h2 class="bordered-heading"><?php the_field('launch_scale_title'); ?></h2>
                <div class="text m-bottom">
                    <?php the_field('launch_scale_text'); ?>
                </div>
            </div>
            <div class="col image">

            </div>
            <div class="clearfix"></div>
        </div> 
    </section> 
    <section class="clients section-padder">
        <div class="mobile-bg-overlay"></div>
        <div class="container">
            <div class="col-md-6 text-justify">
                <h2>Not a Startup? </h2>
                <p>Awesome. Our product development method is tailored to support innovation regardless of company or team size. Some clients start with an idea and a rough sketch, others are well-established companies looking for extra engineering muscle and specialize in supporting rapid growth companies.</p>
            </div>
            <div class="clients-logos visible-xs">
                <img src="<?php echo get_template_directory_uri() ?>/images/clients-logos.png"/>
            </div>
            <div class="clearfix"></div>
        </div> 
    </section>
    <section class="quote section-padder markcuban guy-kawasaki">
        <div class="mobile-bg-overlay"></div>
        <div class="container">
            <div class="markcuban-image"><img src="<?php echo get_template_directory_uri(); ?>/images/guy-kawasaki.jpg"/></div>
            <div class="quote-text">
                <h2><?php the_field('quote_text'); ?></h2>
                <h3 class="text-white"><?php the_field('quote_author'); ?></h3>
                <a href="<?php the_field('quote_cta'); ?>" class="solid-btn"><?php the_field('quote_cta_text'); ?></a>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
