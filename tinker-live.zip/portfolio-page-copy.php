<?php /* Template Name: Portfolio Page Copy */ get_header(); ?>
<script>
    jQuery(document).ready(function () {

        jQuery("#testimonials-carousel").owlCarousel({
            navigation: true, // Show next and prev buttons
            slideSpeed: 300,
            paginationSpeed: 400,
            singleItem: true,
            pagination: false

                    // "singleItem:true" is a shortcut for:
                    // items : 1, 
                    // itemsDesktop : false,
                    // itemsDesktopSmall : false,
                    // itemsTablet: false,
                    // itemsMobile : false

        });

    });

</script>
<main role="main" class="portfolio-page landing-page">
    <!-- section -->
    <section class="testimonials">
        <div class="container">
            <div class="section-title p-bottom m-bottom text-center">
                <h1 class="m-bottom"><?php the_field('banner_heading') ?></h1>
                <h3><?php the_field('banner_text'); ?></h3>
            </div>
            <div class="testimonials-carousel casestudies-carousel">
                <div id="testimonials-carousel" class="owl-carousel owl-theme">
                    <?php
                    $args = array('post_type' => 'landingpage_case_stu', 'order' => 'ASC');
                    $loop = new WP_Query($args);
                    $count = 1;
                    while ($loop->have_posts()) : $loop->the_post();
                        ?>
                        <div class="item">
                            <div class="casestudy-banner-image">
                                <img src="<?php the_field('case_study_banner_image'); ?>"/>
                            </div>
                            <div class="casestudy-banner-text">
                                <div class="testimonial-text">
                                    <?php the_excerpt(); ?>
                                </div>
                                <div class="view-casestudy">
                                    <a href="<?php the_field('case_study_link_to'); ?>" class="border-btn">See the success story</a>
                                </div>
                            </div>
                        </div>
                        <?php
                        $count++;
                    endwhile;
                    wp_reset_query();
                    ?>
                </div>
            </div>
        </div>
    </section>
    <section class="trusted-by section-padder">
        <div class="container">
            <div class="row">
                <div class="col-lg-11 col-lg-offset-1 col-md-11 col-md-offset-1">
                    <div class="row">
                        <div class="col-lg-7 col-md-7 col-sm-8">
                            <h1 class="text-normal m-bottom">Trusted by Founders <br class="visible-lg visible-md"/>
                                and the Fortune 500.</h1>
                            <p>
                                We collaborate with your team to deliver world-class,<br class="visible-lg visible-md"/> high-quality software engineering.
                            </p>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <div class="blocks-image text-left">
                                <img src="<?php echo get_template_directory_uri(); ?>/images/small-blocks.png"/>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="clients-list section-padder">
        <div class="container">
            <div class="row">
                <?php
                $args = array('post_type' => 'clients', 'order' => 'ASC');
                $loop = new WP_Query($args);
                $count = 1;
                while ($loop->have_posts()) : $loop->the_post();
                    if ($count % 4 == 0) {
                        $class = "last";
                    } else {
                        $class = "";
                    }
                    if ($count > 8 && $count <= 11) {
                        $no_border_bottom = "no_border_bottom";
                    }
                    ?>
                    <div class="client <?php
                    echo $class . " ";
                    echo $no_border_bottom;
                    ?>">
                        <div class="client-image">
                            <?php the_post_thumbnail(); ?>
                        </div>
                    </div>
                    <?php
                    $count++;
                endwhile;
                wp_reset_query();
                ?>
            </div>
            <div class="text-center m-top p-top">
                <h2 class="text-uppercase">+ Many More</h2>
            </div>
        </div>

    </section>
    <section class="project-hilights p-bottom m-bottom">
        <div class="container">
            <div class="section-title text-center ">
                <h2 class="text-uppercase">Highlights</h2>
            </div>
        </div>
        <div class="hilights">
            <div class="hilight text-center">
                <div class="number"><h1>10</h1></div>
                <div class="text">Years Experience</div>
            </div>
            <div class="hilight text-center">
                <div class="number"><h1>700+</h1></div>
                <div class="text">Products Shipped</div>
            </div>
            <div class="hilight text-center">
                <div class="number"><h1>95%</h1></div>
                <div class="text">Clients Satisfaction</div>
            </div>
            <div class="clearfix"></div>
        </div>
    </section>
    <section class="trusted-by section-padder">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-8">
                            <h1 class="text-normal m-bottom">Fast Enough for the <br class="visible-lg visible-md"/>
                                World’s Fastest Companies.</h1>
                            <p>
                                We have helped our clients succeed in some of the most 
                                <br class="visible-lg visible-md"/> prestigous startup accelerators in the world.
                            </p>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <div class="blocks-image text-center">
                                <img src="<?php echo get_template_directory_uri(); ?>/images/fastest-companies.png"/>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="scroll-section section-padder portfolio-tabs">
        <div class="container">
            <h1 class="text-center">Browse our success stories.</h1>
            <h2 class="text-center">Our clients are helping to build a better tomorrow. <br class="visible-lg visible-md"/>
                Here are some of the highlights.</h2>
            <div class="m-top p-top">
                <?php
                $args = array('post_type' => 'portfolio', 'order' => 'ASC', 'tax_query' => $tax_queries);

                $loop = new WP_Query($args);

                $count = 1;
                while ($loop->have_posts()) : $loop->the_post();
                    ?>
                    <a class="portfolio-item-wrapper" href="<?php the_permalink(); ?>">
                        <div class="item-thumbnail">
                            <?php the_post_thumbnail(); ?>
                        </div>
                        <div class="item-info-container">
                            <div class="item-info">
                                <p class="project-title"><?php the_title(); ?> </p>
                                <p class="project-tagline"><?php the_field('project_tagline') ?></p>
                            </div>
                        </div>
                    </a>
                    <?php
                    $count++;
                endwhile;
                wp_reset_query();
                ?>
            </div>
<!--            <p class="text-center text-center m-top m-bottom p-bottom"><a href="#" class="border-btn" style="font-size: 20px; padding: 10px 30px;">see more success stories</a></p>-->
            <div class="products-in-press m-top p-top">
                <h1 class="text-center text-center m-top p-top m-bottom">Our Products in the press</h1>
                <h2 class="blockquote">Americans looking to buy a used car can turn to new smartphone app MyVinny</h2> 
                <div class="press-logos row">
                    <div class="col-md-2 col-sm-2 col-xs-4">
                        <img src="<?php echo get_template_directory_uri() ?>/images/the-wall-street-journal-logo.png"/>
                    </div>
                    <div class="col-md-2 col-sm-2 col-xs-4">
                        <img src="<?php echo get_template_directory_uri() ?>/images/techcrunch-logo.png"/>
                    </div>
                    <div class="col-md-2 col-sm-2 col-xs-4">
                        <img src="<?php echo get_template_directory_uri() ?>/images/wired-logo.png"/>
                    </div>
                    <div class="clearfix visible-xs"></div>
                    <div class="col-md-2 col-sm-2 col-xs-4">
                        <img src="<?php echo get_template_directory_uri() ?>/images/inc-logo.png"/>
                    </div>
                    <div class="col-md-2 col-sm-2 col-xs-4">
                        <img src="<?php echo get_template_directory_uri() ?>/images/marie-claire-logo.png"/>
                    </div>
                    <div class="col-md-2 col-sm-2 col-xs-4">
                        <img src="<?php echo get_template_directory_uri() ?>/images/refinery-29-logo.png"/>
                    </div>
                </div>
            </div>
        </div>
        
    </section>
    <hr/>
    <section class="clients-reviews section-padder">
        <div class="container">
            <div class="section-title m-bottom p-bottom ">
                <h2 class="text-uppercase">Hear what our clients have to say...</h2>
            </div>
        </div>
        <?php
        /*
         *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
         *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
         *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
         */

        $post_objects = get_field('testimonials');

        if ($post_objects):
            ?>
            <div class="container">
                <?php foreach ($post_objects as $post): // variable must be called $post (IMPORTANT) ?>
                    <?php setup_postdata($post); ?>
                    <div class="row p-bottom m-bottom" style="border-bottom:1px solid #ccc;">
                        <div class="col-md-2 col-lg-2 col-sm-2">
                            <div class="testimonial-logo">
                                <?php the_post_thumbnail(); ?>

                            </div>    
                        </div>
                        <div class="col-lg-10 col-md-10 col-sm-10">
                            <div class="testimonial-text">
                                <?php the_content(); ?>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                <?php endforeach; ?>
<!--                <div class="p-top m-top m-bottom p-bottom text-center">
                    <a href="#" class="border-btn">Read More Reviews</a>
                </div>-->
            </div>

            <?php wp_reset_postdata(); // IMPORTANT - reset the $post object so the rest of the page works correctly ?>
            <?php
        endif;
        ?>
    </section>
    <section class="landingpage-cta text-center">
        <div class="container">
            <h1><?php the_field('second_cta_heading'); ?></h1>
            <div class="cta-btn">
                <a href="<?php the_field('second_cta_button'); ?>" class="solid-btn"><?php the_field('second_cta_button_text'); ?></a>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
