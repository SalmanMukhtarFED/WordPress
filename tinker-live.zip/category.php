<?php get_header(); ?>

<main role="main" class="category-listing">
    <!-- section -->

    <div class="category-single-title">
        <div class="container">
            <h1 class="text-center"><?php
                _e('Categories for ', 'html5blank');
                single_cat_title();
                ?></h1>
        </div>
    </div>
    <div class="section-padder">
        <div class="container">
            <?php get_template_part('loopcategory'); ?>

            <?php get_template_part('pagination'); ?>
        </div>
    </div>
</main>

<?php get_footer(); ?>
