<?php /* */ get_header(); ?> 

<main role="main" class="press-center">
    <!-- section -->
    <section class="banner">
        <div class="banner-text">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-4 col-sm-5">
                        <h1 class="animated fadeIn"><?php the_field('page_header _title'); ?></h1>
                    </div>
                    <div class="col-lg-7 col-md-8 col-sm-7">
                        <p><?php the_field('page_title_description'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="recent_news">
        <div class="container">
            <div id="recent_news">
                <h2 class="text-capitalize m-bottom"><?php the_field('recent_news_title'); ?></h2>
                <div class="row">

                    <div class="container">
                        <div class="masonrow">
                            <?php
                            /*
                             *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
                             *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
                             *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
                             */

                            $post_objects = get_field('select_recent_news_to_show_on_homepage');

                            if ($post_objects):
                                ?>
                                <?php
                                $count = 1;
                                ?>
                                <?php foreach ($post_objects as $post): // variable must be called $post (IMPORTANT) ?>
                                    <?php setup_postdata($post); ?>
                                    <div class="item">
                                        <div class="recent_news_box">
                                            <?php
                                            if (has_post_thumbnail()) {
                                                ?>
                                                <div class="image">
                                                    <?php
                                                    the_post_thumbnail('large');
                                                    ?>
                                                </div>
                                            <?php } else { ?>
                                                <div class="no_image">
                                                    <img src="/wp-content/uploads/2017/03/Placeholder.png" alt="" />
                                                </div>
                                            <?php } ?>
                                            <div class="overlay">
                                                <h2><?php the_title(); ?></h2>
                                                <a class="view-article text_green text-uppercase" href="<?php the_permalink(); ?>" title="Read more">Read more</a>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $count++;
                                endforeach;
                                ?>
                                <?php wp_reset_postdata(); // IMPORTANT - reset the $post object so the rest of the page works correctly ?>
                                <?php
                            endif;
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="blog-section line_bg">
        <div class="container">
            <h2 class="p-bottom text-capitalize">Blog</h2>
            <div class="row">
                <div class="blog-wrapper">


                    <?php
                    // Display blog posts on any page @ https://m0n.co/l
                    $temp = $wp_query;
                    $wp_query = null;
                    $wp_query = new WP_Query();
                    $wp_query->query('posts_per_page=6' . '&paged=' . $paged);
                    while ($wp_query->have_posts()) : $wp_query->the_post();
                        ?>
                        <div class="col-lg-6 m-bottom  col-md-6 col-sm-6">
                            <h2><?php the_title(); ?></h2>
                            <!--<a href="<?php //the_permalink();                        ?>" title="Read more"></a>-->
                            <p class="m-top-s m-bottom-s"><?php the_excerpt(); ?></p>
                        </div>
                    <?php endwhile; ?>

                    <?php if ($paged > 1) { ?>

                        <nav id="nav-posts">
                            <div class="prev"><?php next_posts_link('&laquo; Previous Posts'); ?></div>
                            <div class="next"><?php previous_posts_link('Newer Posts &raquo;'); ?></div>
                        </nav>

                    <?php } else { ?>

                        <nav id="nav-posts">
                            <div class="prev"><?php next_posts_link('&laquo; Previous Posts'); ?></div>
                        </nav>

                    <?php } ?>

                    <?php wp_reset_postdata(); ?>

                    <div class="clearfix"></div>
                    <div class="subcribe">
                        <a href="/contact/">
                            Subscribe
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="show_blog_news">

        <div class="container">

            <div class="member-tabs">
                <h2 class="inline-block">Archives</h2>
                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                    <li class="active">
                        <a data-toggle="tab" href="#all" class="tab-link" aria-controls="all">
                            Show ALL
                        </a>
                    </li>
                    <li>
                        <a data-toggle="tab" href="#blog" class="tab-link" aria-controls="blog">Blog</a>
                    </li>
                    <li>
                        <a data-toggle="tab" href="#recentnews" class="tab-link" aria-controls="recentnews">Recent News</a>
                    </li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content recent_news">
                    <div role="tabpanel" id="all" class="tab-pane fade active in">
                        <div class="row">

                            <?php
                            $args = array( 'post_type' => array( 'post', 'recent_news', 'order' => 'ASC' ));
                            $loop = new WP_Query($args);
                            $count = 1;
                            while ($loop->have_posts()) : $loop->the_post();
                                ?>
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="row post">
                                        <div class="col-lg-3 col-md-3 col-sm-3">
                                            <?php
                                            if (has_post_thumbnail()) {
                                                ?>
                                                <div class="image">
                                                    <a href="<?php the_permalink(); ?>" title="Read more">  <?php
                                                        the_post_thumbnail('thumbnail');
                                                        ?>
                                                    </a>
                                                </div>
                                            <?php } else { ?>
                                                <div class="no_image">
                                                    <a href="<?php the_permalink(); ?>" title="Read more"> 
                                                        <img src="/wp-content/uploads/2017/03/Placeholder.png" alt="" />
                                                    </a>
                                                </div>
                                            <?php } ?>
                                        </div>
                                        <div class="col-lg-9 col-md-9 col-sm-9">
                                            <div class="recent_news_text">
                                                <h2><?php the_title(); ?></h2>
                                                <div class="recent_news_meta">
                                                    <div class="categories inline-block">
                                                        <?php
                                                        if (has_category()) {
                                                            ?>
                                                            <ul class="post-categories">
                                                                <li>
                                                                    <?php
                                                                    $categories = get_the_category();
                                                                    $separator = ' ';
                                                                    $output = '';
                                                                    if (!empty($categories)) {
                                                                        foreach ($categories as $category) {
                                                                            $output .= '<a href="' . esc_url(get_category_link($category->term_id)) . '" alt="' . esc_attr(sprintf(__('View all posts in %s', 'textdomain'), $category->name)) . '">' . esc_html($category->name) . '</a>' . $separator;
                                                                        }
                                                                        echo trim($output, $separator);
                                                                        ?>
                                                                    </li>
                                                                </ul>

                                                                <?php
                                                            }
                                                        } else {
                                                            ?>
                                                            <ul class="post-categories">
                                                                <?php $category = 'Recent News'; ?>
                                                                <li>
                                                                    <a href="javascript:void(0);" ><?php echo $category ?></a>
                                                                </li>
                                                            </ul>
                                                        <?php }
                                                        ?>
                                                    </div>
                                                    <span class="inline-block text_green"> - </span>
                                                    <div class="date_author inline-block">
                                                        <?php the_time('F j, Y'); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                $count++;
                            endwhile;
                            wp_reset_query();
                            ?>
                        </div>

                        <?php if ($paged > 1) { ?>

                            <nav id="nav-posts">
                                <div class="prev"><?php next_posts_link('&laquo; Previous Posts'); ?></div>
                                <div class="next"><?php previous_posts_link('Newer Posts &raquo;'); ?></div>
                            </nav>

                        <?php } else { ?>

                            <nav id="nav-posts">
                                <div class="prev"><?php next_posts_link('&laquo; Previous Posts'); ?></div>
                            </nav>

                        <?php } ?>
                        <div class="load_more">
                            <a href="#">
                                <i class="fa fa-chevron-down" aria-hidden="true"></i>
                            </a>
                        </div>
                        <?php wp_reset_postdata(); ?>
                    </div>
                    <div role="tabpanel" id="blog" class="tab-pane fade">
                        <div class="row">
                            <!-- showing blog posts -->
                            <?php
// Display blog posts on any page @ https://m0n.co/l
                            $temp = $wp_query;
                            $wp_query = null;
                            $wp_query = new WP_Query();
                            $wp_query->query('posts_per_page=5' . '&paged=' . $paged);
                            while ($wp_query->have_posts()) : $wp_query->the_post();
                                ?>
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <h2><?php the_title(); ?></h2>
                                    <p><?php the_excerpt(); ?></p>
                                </div>
                            <?php endwhile; ?>
                        </div>
                        <?php if ($paged > 1) { ?>

                            <nav id="nav-posts">
                                <div class="prev"><?php next_posts_link('&laquo; Previous Posts'); ?></div>
                                <div class="next"><?php previous_posts_link('Newer Posts &raquo;'); ?></div>
                            </nav>

                        <?php } else { ?>

                            <nav id="nav-posts">
                                <div class="prev"><?php next_posts_link('&laquo; Previous Posts'); ?></div>
                            </nav>

                        <?php } ?>
                        <div class="load_more">
                            <a href="#">
                                <i class="fa fa-chevron-down" aria-hidden="true"></i>
                            </a>
                        </div>
                        <?php wp_reset_postdata(); ?>
                    </div>
                    <div role="tabpanel" id="recentnews" class="tab-pane fade">
                        <div class="row">
                            <?php
                            $args = array('post_type' => 'recent_news', 'order' => 'ASC');
                            $loop = new WP_Query($args);
                            $count = 1;
                            while ($loop->have_posts()) : $loop->the_post();
                                ?>
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="row post">
                                        <div class="col-lg-3 col-md-3 col-sm-3">
                                            <?php
                                            if (has_post_thumbnail()) {
                                                ?>
                                                <div class="image">
                                                    <a href="<?php the_permalink(); ?>" title="Read more"> 
                                                        <?php
                                                        the_post_thumbnail('thumbnail');
                                                        ?>
                                                    </a>
                                                </div>
                                            <?php } else { ?>
                                                <div class="no_image">
                                                    <a href="<?php the_permalink(); ?>" title="Read more"> 

                                                    </a>
                                                </div>
                                            <?php } ?>
                                        </div>
                                        <div class="col-lg-9 col-md-9 col-sm-9">
                                            <div class="recent_news_text">
                                                <h2><?php the_title(); ?></h2>
                                                <div class="recent_news_meta">
                                                    <div class="categories inline-block">
                                                        <?php
                                                        if (has_category()) {
                                                            ?>
                                                            <ul class="post-categories">
                                                                <li>
                                                                    <?php
                                                                    $categories = get_the_category();
                                                                    $separator = ' ';
                                                                    $output = '';
                                                                    if (!empty($categories)) {
                                                                        foreach ($categories as $category) {
                                                                            $output .= '<a href="' . esc_url(get_category_link($category->term_id)) . '" alt="' . esc_attr(sprintf(__('View all posts in %s', 'textdomain'), $category->name)) . '">' . esc_html($category->name) . '</a>' . $separator;
                                                                        }
                                                                        echo trim($output, $separator);
                                                                        ?>
                                                                    </li>
                                                                </ul>

                                                                <?php
                                                            }
                                                        } else {
                                                            ?>
                                                            <ul class="post-categories">
                                                                <?php $category = 'Recent News'; ?>
                                                                <li>
                                                                    <a href="javascript:void(0);" ><?php echo $category ?></a>
                                                                </li>
                                                            </ul>
                                                        <?php }
                                                        ?>
                                                    </div>
                                                    <span class="inline-block text_green"> - </span>
                                                    <div class="date_author inline-block">
                                                        <?php the_time('F j, Y'); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                $count++;
                            endwhile;
                            ?>
                            <?php wp_reset_query();
                            ?>
                        </div>
                        <div class="load_more">
                            <a href="#">
                                <i class="fa fa-chevron-down" aria-hidden="true"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /section -->
</main>
<script>
    jQuery(document).ready(function () {
        jQuery("div.approach-tab-menu>div.list-group>a").on('click', function (e) {
            e.preventDefault();
            jQuery(this).siblings('a.active').removeClass("active");
            jQuery(this).addClass("active");
            var index = jQuery(this).index();
            jQuery("div.approach-tab>div.approach-tab-content").removeClass("active");
            jQuery("div.approach-tab>div.approach-tab-content").eq(index).addClass("active");
        });
        jQuery(".down-scroll").click(function () {
            //$(this).animate(function(){
            var top_position = jQuery(".scroll-section").offset().top;
            var top_position = top_position;
            jQuery('html, body').animate({
                scrollTop: top_position
            }, 1000);
            //});
        });
    });

</script>
<?php get_footer(); ?>
