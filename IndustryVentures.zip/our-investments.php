<?php /* Template Name: Investments */ get_header(); ?> 

<main role="main" class="our-investments">
    <!-- section -->
    <section class="banner">
        <div class="banner-text">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-4 col-sm-5">
                        <h1 class="animated fadeIn"><?php the_field('page_header _title'); ?></h1>
                    </div>
                    <div class="col-lg-7 col-md-8 col-sm-7">
                        <p><?php the_field('page_title_description'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="featured_invetments">
        <div class="container">
            <h2>Featured Exits
                <a href="javascript:void(0)" class="pull-right view_all down-scroll">View All</a>
                <div class="clearfix"></div>
            </h2>
            <div class="flex_container">
                <?php
                $args = array(
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'investments_categories',
                            'field' => 'slug',
                            'terms' => array('featured')
                        ),
                    ),
                    'post_type' => 'investment_partners'
                );
                $loop = new WP_Query($args);
                if ($loop->have_posts()) {
                    $term = $wp_query->queried_object;
                    while ($loop->have_posts()) : $loop->the_post();
                        $has_company_details = get_field('has_company_info');
                        ?>    
                        <div class="investments_logo flex_item">
                            <?php if ($has_company_details == 'yes') { ?>

                                <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('medium'); ?></a>
                            <?php } else { ?>
                                <a href="<?php the_field('investment_company_link') ?>" target="_blank"><?php the_post_thumbnail('medium'); ?></a>
                            <?php }
                            ?>

                        </div>
                        <?php
                    endwhile;
                    wp_reset_query();
                }
                ?>
            </div>
        </div>
    </section>
    <section class="all_invenstments scroll-section">

        <div class="container">
            <?php
            $cat_array = get_categories(array('taxonomy' => 'investments_categories')); //'type=portfolio'
            $count_categories = count($cat_array);
            //var_dump($count_categories);
            ?>
            <div class="row">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                    <li class="active">
                        <a data-toggle="tab" href="#all" class="tab-link" aria-controls="all">
                            Show ALL
                        </a>
                    </li>
                    <?php
                    for ($i = 0; $i < $count_categories; $i++) {
//                        if ($i == 0) {
//                            $class = "active";
//                        } else {
//                            $class = "";
//                        }

                        if ($i == 0) {
                            $class = "hide";
                        } else {
                            $class = "";
                        }
                        ?>
                        <li class="<?php echo $class; ?>">
                            <a data-toggle="tab" href="#tab-<?php echo $i; ?>" class="tab-link <?php echo $class ?>" aria-controls="tab-<?php echo $i; ?>">
                                <?php echo ($cat_array[$i]->name); ?>
                            </a>
                        </li>
                    <?php }
                    ?>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content">
                    <?php
                    $count_posts = wp_count_posts('investment_partners');
                    //var_dump($count_posts);
                    ?>
                    <div role="tabpanel" id="all" class="tab-pane fade active in">
                        <?php
                        $args = array('post_type' => 'investment_partners', 'posts_per_page' => $count_posts->publish, 'orderby'=> 'title', 'order' => 'ASC');
                        $loop = new WP_Query($args);
                        $count = 1;
                        while ($loop->have_posts()) : $loop->the_post();
                            ?>
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6 m-bottom">
                                <?php $has_company_details = get_field('has_company_info'); ?>
                                <?php if ($has_company_details == 'yes') { ?>
                                    <a class="partner_name" href="<?php the_permalink(); ?>">
                                        <?php the_title(); ?>
                                    </a> <?php } else { ?>
                                    <a class="partner_name" href="<?php the_field('investment_company_link'); ?>" target="_blank">
                                        <?php the_title(); ?>
                                    </a>
                                <?php } ?>
                            </div>
                            <?php if ($count % 2 == 0) { ?>
                                <div class="clearfix visible-xs"></div>   
                            <?php } if ($count % 4 == 0) {
                                ?>

                                <div class="clearfix visible-lg visible-md visible-sm hidden-xs"></div>   
                            <?php }
                            ?>

                            <?php
                            $count++;
                        endwhile;
                        wp_reset_query();
                        ?>
                    </div>

                    <?php
                    for ($i = 0; $i < $count_categories; $i++) {
                        if ($i == 0) {
                            $class = "hide";
                        } else {
                            $class = "";
                        }
                        ?>
                        <div role="tabpanel" id="tab-<?php echo $i; ?>" class="tab-pane fade <?php echo $class; ?>">
                            <?php $current_category = $cat_array[$i]->slug ?>
                            <?php
                            $tax_queries = array(
                                array(
                                    'taxonomy' => 'investments_categories',
                                    'field' => 'term_id',
                                    'terms' => array($cat_array[$i]->term_id)
                                )
                            );
                            


                            $args = array('post_type' => 'investment_partners', 'posts_per_page' => $count_posts->publish, 'orderby'=> 'title', 'order' => 'ASC', 'tax_query' => $tax_queries);

                            $loop = new WP_Query($args);

                            $count = 1;
                            while ($loop->have_posts()) : $loop->the_post();
                                ?>
                                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6 m-bottom">
                                    <?php $has_company_details = get_field('has_company_info'); ?>
                                    <?php if ($has_company_details == 'yes') { ?>
                                        <a class="partner_name" href="<?php the_permalink(); ?>">
                                            <?php the_title(); ?>
                                        </a> <?php } else { ?>
                                        <a class="partner_name" href="<?php the_field('investment_company_link'); ?>" target="_blank">
                                            <?php the_title(); ?>
                                        </a>
                                    <?php } ?>
                                </div>
                                <?php if ($count % 2 == 0) { ?>
                                    <div class="clearfix visible-xs"></div>   
                                <?php } if ($count % 4 == 0) {
                                    ?>

                                    <div class="clearfix visible-lg visible-md visible-sm hidden-xs"></div>   
                                <?php }
                                ?>
                                <?php
                                $count++;
                            endwhile;
                            wp_reset_query();
                            ?>
                        </div>
                    <?php }
                    ?>
                </div>
            </div>
        </div>
    </section>
    <section class="disclaimer_text">
        <div class="container">
            <div class="text">
                <?php the_field('investment_disclaimer_text'); ?>
            </div>
        </div>
    </section>

    <!-- /section -->
</main>
<script>
    jQuery(document).ready(function () {
        jQuery("div.approach-tab-menu>div.list-group>a").on('click', function (e) {
            e.preventDefault();
            jQuery(this).siblings('a.active').removeClass("active");
            jQuery(this).addClass("active");
            var index = jQuery(this).index();
            jQuery("div.approach-tab>div.approach-tab-content").removeClass("active");
            jQuery("div.approach-tab>div.approach-tab-content").eq(index).addClass("active");
        });
        jQuery(".down-scroll").click(function () {
            //$(this).animate(function(){
            var top_position = jQuery(".scroll-section").offset().top;
            var top_position = top_position;
            jQuery('html, body').animate({
                scrollTop: top_position
            }, 1000);
            //});
        });
    });

</script>
<?php get_footer(); ?>
