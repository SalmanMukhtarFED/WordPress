<style>
    .wrapper.inner_page .banner,
    .wrapper.home .banner .container{
        min-height: 450px !important;
    }
</style>
