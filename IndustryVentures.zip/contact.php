<?php /* Template Name: Contact */ get_header(); ?> 

<main role="main" class="contact">
    <!-- section -->
    <section class="banner">
        <div class="banner-text">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-4 col-sm-3">
                        <h1 class="animated fadeIn"><?php the_field('page_header _title'); ?></h1>
                    </div>
                    <div class="col-lg-7 col-md-8 col-sm-9">
                        <p><?php the_field('page_title_description'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="contact_address">
        <div class="container">
        <div class="col-md-10 col-md-offset-1">
            <div class="row">
                <div class="col-lg-4 col-md-4">
                    <div class="address m-bottom p-bottom">
                        <?php dynamic_sidebar('contact-1'); ?>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="address m-bottom">
                        <?php dynamic_sidebar('contact-2'); ?>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="address m-bottom">
                        <?php dynamic_sidebar('contact-3'); ?>
                    </div>
                </div>
            </div>
            <div>
                <?php echo do_shortcode('[contact-form-7 id="163" title="Contact form 1"]') ?>
            </div>
        </div>
            </div>
    </section>
    <!-- /section -->
</main>

<?php get_footer(); ?>
