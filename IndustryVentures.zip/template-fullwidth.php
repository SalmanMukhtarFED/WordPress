<?php /* Template Name: Full Width Page */ get_header(); ?>
<?php get_header(); ?>

<main role="main">
    <!-- section -->
    <section class="banner">
        <div class="banner-text">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-4 col-sm-5">
                        <h1 class="animated fadeIn"><?php the_field('page_header _title'); ?></h1>
                    </div>
                    <div class="col-lg-7 col-md-8 col-sm-7">
                        <p><?php the_field('page_title_description'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- section -->
    <section class="content">
        <div class="container">
            <div class="text">
                <h1><?php the_title(); ?></h1>

                <?php if (have_posts()): while (have_posts()) : the_post(); ?>

                        <!-- article -->
                        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

                            <?php the_content(); ?>
                            <?php edit_post_link(); ?>

                        </article>
                        <!-- /article -->

                    <?php endwhile; ?>

                <?php else: ?>

                    <!-- article -->
                    <article>

                        <h2><?php _e('Sorry, nothing to display.', 'html5blank'); ?></h2>

                    </article>
                    <!-- /article -->

                <?php endif; ?>
            </div>
        </div>

    </section>
    <section class="blog-section">
        <div class="recent_news line_bg">
            <div class="container">
                <div class="blog-wrapper">
                    <div id="recent_news" class="">
                        <div class="section_header">
                            <h2 class="pull-left">Recent News</h2>
                            <a href="/press/" class="pull-right text-uppercase">view all</a>
                            <div class="clearfix"></div>
                        </div>
                        <div class="row">
                            <?php
                            /*
                             *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
                             *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
                             *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
                             */

                            $query = new WP_Query(array(
                                'post_type' => 'recent_news',
                                'post_status' => 'publish',
                                'posts_per_page' => 6
                            ));
                            $count = 1;
                            while ($query->have_posts()) {
                                $query->the_post();
                                ?>
                                <div class="col-lg-6 col-md-6">
                                    <div class="recent_news_meta">
                                        <div class="categories inline-block">

                                            <?php
                                            if (has_category()) {
                                                ?>
                                                <ul class="post-categories">
                                                    <li>
                                                        <?php
                                                        $categories = get_the_category();
                                                        $separator = ' ';
                                                        $output = '';
                                                        $page = 'press';
                                                        if (!empty($categories)) {
                                                            foreach ($categories as $category) {
                                                                $output .= '<a href="/' . $page . '/#tab' . esc_html($category->slug) . '" alt="' . esc_attr(sprintf(__('View all posts in %s', 'textdomain'), $category->name)) . '">' . esc_html($category->name) . '</a>' . $separator;
                                                            }
                                                            echo trim($output, $separator);
                                                            ?>
                                                        </li>
                                                    </ul>

                                                    <?php
                                                }
                                            } else {
                                                ?>
                                                <ul class="post-categories">
                                                    <?php $category = 'Recent News'; ?>
                                                    <li>
                                                        <a href="javascript:void(0);" ><?php echo $category ?></a>
                                                    </li>
                                                </ul>
                                            <?php }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="post">
                                        <h2><a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?> ><?php the_title(); ?></a></h2>
                                        <p class="m-top-s m-bottom-s"><?php the_excerpt(); ?></p>
                                    </div>
                                </div>
                                <?php if ($count % 2 == 0) { ?>
                                    <div class="clearfix"></div>   
                                <?php }
                                ?>
                                <?php
                                $count++;
                            }
                            wp_reset_query();
                            ?>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
    <!-- /section -->
</main>

<?php get_footer(); ?>

