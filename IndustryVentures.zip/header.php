<!doctype html>
<html <?php language_attributes(); ?> class="no-js">
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <title><?php wp_title(''); ?><?php
            if (wp_title('', false)) {
                echo ' :';
            }
            ?> <?php bloginfo('name'); ?></title> 
        <meta name="description" content="Born amidst the dot-com crash, we understand firsthand the challenges of illiquidity. Over the last two decades, we pioneered new segments of the venture capital market. Today, Industry Ventures manages over $3 billion and serves founders, venture funds and institutions across the ecosystem.">
        <link href="//www.google-analytics.com" rel="dns-prefetch">
        <link href="<?php echo get_template_directory_uri(); ?>/img/icons/favicon_new.ico" rel="shortcut icon">
        <link href="<?php echo get_template_directory_uri(); ?>/img/icons/apple_touch_new.ico" rel="apple-touch-icon-precomposed">

        <link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta property="og:title" content="<?php wp_title(''); ?>"/>
        <meta property="og:image" content="<?php echo get_template_directory_uri(); ?>/images/og-image.png"/>
        <meta property="og:site_name" content="<?php bloginfo('name'); ?>"/>
        <meta property="og:description" content="<?php bloginfo('description'); ?>"/> 
         <meta property="og:url" content="<?php echo get_site_url(); ?>"/> 
        <?php
        $version = preg_replace("/(.*) OS ([0-9]*)_(.*)/", "$2", $_SERVER['HTTP_USER_AGENT']);
        if ($version == 7) {
            ?>
                  <link href="<?php echo get_template_directory_uri(); ?>/css/iOS-fix.css" rel="stylesheet" media="all">
              <?php }
              ?> 

        <?php wp_head(); ?>
        <script>
// conditionizr.com
// configure environment tests
            conditionizr.config({
                assets: '<?php echo get_template_directory_uri(); ?>',
                tests: {}
            });
        </script>
        <script>
            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                jQuery(document).ready(function () {
                    jQuery('.menu-item-256 a').click(function () {
                        jQuery('.menu-item-256').find('.sub-menu').slideToggle();
                    });
                     jQuery('.menu-item-257 a').click(function () {
                        jQuery('.menu-item-257').find('.sub-menu').slideToggle();
                    });
                });
            }


        </script>
    </head>
    <?php
    if (is_front_page()) {
        $class = 'home';
    } else {
        $class = 'inner_page';
    }
    ?>

    <body <?php body_class(); ?>>

        <!-- wrapper -->
        <div class="wrapper <?php echo $class; ?>">
            <header class="header clear" role="banner">
                <nav class="navbar">
                    <div class="container">
                        <div class="navbar-header">
                            <button aria-controls="navbar" aria-expanded="false" data-target="#navbar" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a href="/" class="navbar-brand"> <img src="<?php echo get_template_directory_uri(); ?>/images/iv-website-logo-dark.svg" alt="Logo" class="logo-img visible-xs"> <img src="<?php echo get_template_directory_uri(); ?>/images/iv-website-logo-white.svg" alt="Logo" class="logo-img hidden-xs"></a>
                        </div>
                        <div class="navbar-collapse collapse" id="navbar">
                            <?php html5blank_nav(); ?>
                            <?php html5blank_subnav(); ?>
                        </div><!--/.nav-collapse -->
                    </div><!--/.container-fluid -->
                </nav>
            </header>

