<div class="col-lg-6 col-md-6 col-sm-6">
    <div class="row post">
        <div class="col-lg-3 col-md-3 col-sm-3">
            <?php
            if (has_post_thumbnail()) {
                ?>
                <div class="image">
                    <a href="<?php echo check_post_external_link(); ?>" title="Read more">  <?php
                        the_post_thumbnail('thumbnail');
                        ?>
                    </a>
                </div>
            <?php } else { ?>
                <div class="no_image">
                    <a href="<?php echo check_post_external_link(); ?>" title="Read more"> 

                    </a>
                </div>
            <?php } ?>
        </div>
        <div class="col-lg-9 col-md-9 col-sm-9">
            <div class="recent_news_text">
                <h2><a class="" href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?>><?php the_title(); ?></a></h2>
                <div class="recent_news_meta">

                    <?php
                    if (has_category()) {
                        ?>
                        <ul class="post-categories inline-block v-middle">
                            <li>
                                <?php
                                $categories = get_the_category();
                                $separator = ' ';
                                $output = '';
                                if (!empty($categories)) {
                                    foreach ($categories as $category) {
                                        $output .= '<a href="#tab' . esc_html($category->slug) . '" alt="">' . esc_html($category->name) . '</a>' . $separator;
                                    }
                                    echo trim($output, $separator);
                                    ?>
                                </li>
                            </ul>

                            <?php
                        }
                    } else {
                        ?>
                        <ul class="post-categories inline-block v-middle">
                            <?php $category = 'Recent News'; ?>
                            <li>
                                <a href="javascript:void(0);" ><?php echo $category ?></a>
                            </li>
                        </ul>
                    <?php }
                    ?>

                    <span class="inline-block v-middle text_green hidden-xs"> - </span>
                    <div class="date_author inline-block v-middle">
                        <?php the_time('F j, Y'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>