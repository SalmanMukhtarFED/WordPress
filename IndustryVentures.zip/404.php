<?php get_header(); ?>

<main role="main">
    <section class="page-not-found">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2">
                    <div class="col-lg-3 col-md-3 col-sm-3">
                        <div class="gear_icon text_green">
                            <i class="fa fa-gear fa-5x"></i>
                        </div>
                    </div>
                    <div class="col-lg-9 col-md-9 col-sm-9">
                        <h1>404</h1>
                        <h2>Page Not Found</h2>
                        <p>
                            The page you were looking for doesn't exist. You may have mistyped the address or the page may have moved.
                        </p>
                        <div class="m-top">
                            <a href="/" class="btn btn_green btn-lg m-right">Go Home</a>
                            <a href="/contact/" class="btn btn_green btn-lg">Contact Us</a>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
</main>


<?php get_footer(); ?>
