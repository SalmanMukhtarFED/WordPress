<!-- footer -->
<?php
if (is_page('press-center')) {
    // the page is "About", or the parent of the page is "About"
    $class = 'hide';
}
if (is_page('contact')) {
    // the page is "About", or the parent of the page is "About"
    $class = 'hide';
}
if (is_page()) {
    ?>
    <section class="next-page <?php echo $class ?>">
        <?php
        $next_post = get_next_post();
        $page_excerpt = $next_post->post_content;
        if (!empty($next_post)):
            ?>
            <div class="container">
                <h2>
                    <?php
                    if (is_front_page()) {
                        ?>
                        START: <span class="text-capitalize"><?php echo $next_post->post_title; ?></span>
                    <?php } else { ?>
                        NEXT: <span class="text-capitalize"><?php echo $next_post->post_title; ?></span>
                    <?php } ?>
                </h2>
                <div class="next_excerpt">
                    <?php
                    if (is_front_page()) {
                        ?>
                        <p> Find out more about our history and our venture capital platform.</p>
                    <?php } else { ?>
                        <p><?php echo plugin_myContentFilter($page_excerpt); ?></p>
                    <?php } ?>
                </div>
                <p class="p-top"><a href="<?php echo get_permalink($next_post->ID); ?>">Learn More</a></p>
            </div>
        <?php endif; ?>
    </section>
<?php } ?>
<footer class="footer" role="contentinfo">
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-md-2 col-sm-2">
                    <?php dynamic_sidebar('contact-1'); ?>
                </div>
                <div class="col-md-2 col-sm-2">
                    <?php dynamic_sidebar('contact-2'); ?>
                </div>
                <div class="col-md-3 col-sm-3">
                    <?php dynamic_sidebar('contact-3'); ?>
                </div>

                <div class="col-md-3 col-sm-3">
                    <?php dynamic_sidebar('menu-1'); ?>
                </div>
                <div class="col-md-2 col-sm-2">
                    <?php dynamic_sidebar('menu-2'); ?>
                    <?php echo do_shortcode('[aps-social id="2"]') ?>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <!-- copyright -->
        <div class="container">
            <p class="copyright pull-left">
                &copy; <?php echo date('Y'); ?> Copyright Industry Ventures. All Rights Reserved.
            </p>
            <ul class="pull-right">
                <li><a href="/terms-conditions/">Terms &AMP; Conditions</a></li>
                <li>|</li>
                <li><a href="/privacy-policy/">Privacy Policy</a></li>
            </ul>
            <div class="clearfix"></div>
        </div>
        <!-- /copyright -->
    </div>

</footer>
<!-- /footer -->

</div>
<!-- /wrapper -->

<?php wp_footer(); ?>

<!-- analytics -->
<script>
    (function (f, i, r, e, s, h, l) {
        i['GoogleAnalyticsObject'] = s;
        f[s] = f[s] || function () {
            (f[s].q = f[s].q || []).push(arguments)
        }, f[s].l = 1 * new Date();
        h = i.createElement(r),
                l = i.getElementsByTagName(r)[0];
        h.async = 1;
        h.src = e;
        l.parentNode.insertBefore(h, l)
    })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');
    ga('create', 'UA-XXXXXXXX-XX', 'yourdomain.com');
    ga('send', 'pageview');
</script>

</body>
</html>
