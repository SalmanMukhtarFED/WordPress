<?php
$version = preg_replace("/(.*) OS ([0-9]*)_(.*)/", "$2", $_SERVER['HTTP_USER_AGENT']);
if ($version == 7) {
    ?>
    <link href="<?php echo get_template_directory_uri(); ?>/css/iOS-fix.css" rel="stylesheet" media="all">
<?php }
?> 
<?php if (have_posts()): while (have_posts()) : the_post(); ?>
        <?php $featured_image = get_the_post_thumbnail_url() ?>
        <!-- section -->
        <section class="banner" style="background-image: url('<?php echo $featured_image; ?>') !important;">
            <div class="banner-text">
                <div class="container">
                    <div class="row">
                        <h1 class="animated fadeIn"><?php the_title(); ?></h1>
                        <p class="text-italic"><?php the_field('member_designation'); ?></p>
                        <ul class="member_social_links">
                            <?php
                            $twitter = get_field('member_twitter_url');
                            if ($twitter != '') {
                                ?>
                                <li>
                                    <a href="<?php echo $twitter ?>" target="_blank"><i class="fa fa-twitter"></i></a>
                                </li>
                            <?php } ?>
                            <?php
                            $linkedin = get_field('member_linkedin_url');
                            if ($linkedin != '') {
                                ?>
                                <li>
                                    <a href="<?php echo $linkedin ?>"><i class="fa fa-linkedin"></i></a>
                                </li>
                            <?php } ?>
                            <?php
                            $facebook = get_field('member_facebook_url');
                            if ($facebook != '') {
                                ?>
                                <li>
                                    <a href="<?php echo $facebook ?>"><i class="fa fa-facebook"></i></a>
                                </li>
                            <?php } ?>
                            <?php
                            $email = get_field('member_email');
                            if ($email != '') {
                                ?>
                                <li>
                                    <a href="mailto:<?php echo $email ?>"><i class="fa fa-envelope"></i></a>
                                </li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <section class="member_detail">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-5">
                        <h2>Key Facts</h2>
                        <p><?php the_field('member_key_facts') ?></p>
                    </div>
                    <div class="col-lg-7 col-md-7">
                        <h2>Biography</h2>
                        <?php the_content(); ?>
                    </div>
                </div>
            </div>
        </section>
        <section class="next-previous">
            <div class="container">
                <div class="text-center">
                    <?php
                    $next_post = get_next_post();
                    $prev_post = get_previous_post();
                    ?>
                    <?php if (get_adjacent_post(false, '', false)): ?>
                        <div class="pull-left">
                            <a href="<?php echo get_permalink($next_post->ID); ?>"><i class="fa fa-angle-left m-right-s"></i> Previous</a>
                        </div>
                    <?php endif; ?>
                    <div class="all-team inline-block">
                        <a href="/our-team/">All Team</a>
                    </div>
                    <?php if (get_adjacent_post(false, '', true)): ?>
                        <div class="pull-right">
                            <a href="<?php echo get_permalink($prev_post->ID) ?>">Next <i class="fa fa-angle-right m-left-s"></i> </a>
                        </div>
                    <?php endif; ?>
                    <div class="clear"></div>
                </div>
            </div>
        </section>
    <?php endwhile; ?>

<?php else: ?>

    <!-- article -->
    <article>

        <h1><?php _e('Sorry, nothing to display.', 'html5blank'); ?></h1>

    </article>
    <!-- /article -->

<?php endif; ?>
