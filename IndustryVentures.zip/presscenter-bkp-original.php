<?php /**/ get_header(); ?> 

<main role="main" class="press-center">
    <!-- section -->
    <section class="banner banner_test">
        <div class="banner-text">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-4 col-sm-5">
                        <h1 class="animated fadeIn">sadsa<?php the_field('page_header _title'); ?></h1>
                    </div>
                    <div class="col-lg-7 col-md-8 col-sm-7">
                        <p><?php the_field('page_title_description'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="recent_news" id="recent_news">
        <div class="container">
            <div id="recent_news">
                <div>
                    <h2 class="text-capitalize m-bottom pull-left"><?php the_field('recent_news_title'); ?></h2>
                    <div class="pull-right m-top-s press-center-social"><?php echo do_shortcode('[aps-social id="3"]') ?></div>
                    <div class="clearfix"></div>
                </div>
                <div class="row">
                    <div class="container">
                        <div class="masonrow">
                            <?php
                            /*
                             *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
                             *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
                             *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
                             */

                            $post_objects = get_field('press_center_featured_news');

                            if ($post_objects):
                                ?>
                                <?php
                                $count = 1;
                                ?>
                                <?php foreach ($post_objects as $post): // variable must be called $post (IMPORTANT) ?>
                                    <?php setup_postdata($post); ?>
                                    <div class="item">
                                        <div class="recent_news_box">
                                            <?php
                                            if (has_post_thumbnail()) {
                                                ?>
                                                <div class="image">
                                                    <?php
                                                    the_post_thumbnail('large');
                                                    ?>
                                                </div>
                                            <?php } else { ?>
                                                <div class="no_image">
                                                    <img src="/wp-content/uploads/2017/03/Placeholder.png" alt="" />
                                                </div>
                                            <?php } ?>
                                            <div class="overlay">
                                                <h2><a class="" href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?>><?php the_title(); ?></a></h2>
                                                <a class="view-article text_green text-uppercase" href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?> title="Read more">Read more</a>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $count++;
                                endforeach;
                                ?>
                                <?php wp_reset_postdata(); // IMPORTANT - reset the $post object so the rest of the page works correctly ?>
                                <?php
                            endif;
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="blog-section line_bg" id="blog">
        <div class="container">
            <h2 class="p-bottom text-capitalize">Blog</h2>
            <div class="row">
                <div class="blog-wrapper">
                    <?php echo do_shortcode('[ajax_load_more id="loadAllPosts" container_type="div" css_classes="ajax-loadmore" post_type="post" posts_per_page="4" scroll="false" repeater="template_2"  transition="fade" transition_speed="500" images_loaded="true" button_label=""]') ?>
                    <div class="clearfix"></div>
                    <div class="subcribe">
                        <a href="/contact/">
                            Subscribe
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="show_blog_news" id="archives">
        <div class="container">
            <div class="member-tabs">
                <h2 class="inline-block">Archives</h2>
                <?php
                // loop for displaying categories
                $cat_array = get_categories(array('post_type' => 'recent_news')); //'type=portfolio'
                $count_categories = count($cat_array);
                ?>
                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                    <li class="active">
                        <a data-toggle="tab" href="#all" class="tab-link" aria-controls="all">
                            Show ALL
                        </a>
                    </li>
                    <?php
                    for ($i = 0; $i < $count_categories; $i++) {
                        ?>
                        <li class="<?php echo $class; ?>">
                            <a data-toggle="tab" href="#tab<?php echo ($cat_array[$i]->slug) ?>" class="tab-link">
                                <?php echo ($cat_array[$i]->name); ?>
                            </a>
                        </li>
                    <?php }
                    ?>
                </ul>
                <!-- Tab panes -->
                <div class="tab-content recent_news">
                    <div role="tabpanel" id="all" class="tab-pane fade active in">
                        <div class="">
                            <?php echo do_shortcode('[ajax_load_more id="loadAllPosts" container_type="div" css_classes="ajax-loadmore" post_type="post, recent_news" posts_per_page="6" scroll="false"  transition="fade" transition_speed="500" images_loaded="true" button_label=""]') ?>                              
                        </div>
                    </div>
                    <?php
                    $count == 1;
                    for ($i = 0; $i < $count_categories; $i++) {
                        ?>
                        <?php
                        if ($cat_array[$i]->slug == "all") {
                            ?>
                            <div role="tabpanel" id="tab<?php echo ($cat_array[$i]->slug) ?>" class="tab-pane fade">
                                <?php echo do_shortcode('[ajax_load_more id="loadAllPosts" container_type="div" css_classes="ajax-loadmore" post_type="post" posts_per_page="4" scroll="false" repeater="template_2"  transition="fade" transition_speed="500" images_loaded="true" button_label=""]') ?>
                            </div>
                        <?php } else { ?>

                            <div role="tabpanel" id="tab<?php echo ($cat_array[$i]->slug) ?>" class="tab-pane fade">
                                <?php echo do_shortcode('[ajax_load_more id="loadAllPosts" container_type="div" css_classes="ajax-loadmore" post_type="recent_news" category="' . $cat_array[$i]->slug . '" posts_per_page="6" scroll="false"  transition="fade" transition_speed="500" images_loaded="true" button_label=""]') ?>                            
                            </div>
                            <?php
                        }
                        $count++;
                        ?>
                    <?php } ?>

                </div>
            </div>
        </div>
    </section>
    <!-- /section -->
</main>
<script>
    jQuery(function () {
        var hash = window.location.hash;
        hash && jQuery('ul.nav a[href="' + hash + '"]').tab('show');

        jQuery('.nav-tabs a').click(function (e) {
            jQuery(this).tab('show');
            var scrollmem = jQuery('body').scrollTop() || jQuery('html').scrollTop();
            window.location.hash = this.hash;
            jQuery('html,body').scrollTop(scrollmem);
        });

    });
    var currentLength = 0;

    function activaTab(tab) {
        jQuery('.nav-tabs a[href="#' + tab + '"]').tab('show');
    }
    ;

    function rebindHashTags() {
        var hashTag = setInterval(function () {
            var list = jQuery('.ajax-loadmore .post');
            if (list && list.length > currentLength) {
                jQuery('.post-categories a[href*="#tab"]').on('click', function (e) {
                    activaTab((e.currentTarget.hash).replace('#', ''));
                })
                currentLength = list.length;
                clearInterval(hashTag);
            }
        }, 1000);
    }
    jQuery(document).ready(function () {
        jQuery('.post-categories a[href*="#tab"]').on('click', function (e) {
            activaTab((e.currentTarget.hash).replace('#', ''));
        });

        var hashTag = setInterval(function () {
            var list = jQuery('.ajax-loadmore .post');
            if (list && list.length > currentLength) {
                jQuery('.post-categories a[href*="#tab"]').on('click', function (e) {
                    activaTab((e.currentTarget.hash).replace('#', ''));
                });
                currentLength = list.length;
                clearInterval(hashTag);
            }
        }, 1000);

        jQuery('#load-more').click(function () {
            rebindHashTags();
        });

        jQuery('a[href*=#]:not([href=#])').click(function () {
            if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
                var target = jQuery(this.hash);
                target = target.length ? target : jQuery('[name=' + this.hash.slice(1) + ']');
                if (target.length) {
                    jQuery('html,body').animate({
                        scrollTop: target.offset().top
                    }, 800);
                    return false;
                }
            }
        });

    });
</script>
<?php get_footer(); ?>
