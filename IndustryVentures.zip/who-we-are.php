<?php /* Template Name: Who We Are */ get_header(); ?> 
<link rel="stylesheet" type="text/css" href="<?php bloginfo("template_directory"); ?>/css/timeline.css" />
<script src="<?php bloginfo("template_directory"); ?>/js/main.js"></script> 
<main role="main" class="who-we-are">
    <!-- section -->
    <section class="banner">
        <div class="banner-text">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-4 col-sm-5">
                        <h1 class="animated fadeIn"><?php the_field('page_header _title'); ?></h1>
                    </div>
                    <div class="col-lg-7 col-md-8 col-sm-7">
                        <p><?php the_field('page_title_description'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="p-top m-top p-bottom m-bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-5 col-sm-5">
                    <div id="cd-timeline" class="cd-container">
                        <?php
                        $args = array('post_type' => 'timeline', 'order' => 'DSC');
                        $loop = new WP_Query($args);
                        $count = 1;
                        while ($loop->have_posts()) : $loop->the_post();
                            ?>
                            <div class="cd-timeline-block">
                                <div class="cd-timeline-img"></div>
                                <div class="cd-timeline-content">
                                    <h2><?php the_title(); ?></h2>
                                    <div class="counter_subtexts">
                                        <?php the_content(); ?>
                                    </div>
                                    <span class="cd-date">
                                        <span class="counter_numbers">
                                            <?php the_field('date'); ?>
                                        </span>

                                    </span>
                                </div> 
                            </div> 
                            <?php
                            $count++;
                        endwhile;
                        wp_reset_query();
                        ?>
                    </div>
                </div>
                <div class="col-lg-7 col-md-7 col-sm-7">
                    <?php if (have_posts()): while (have_posts()) : the_post(); ?>

                            <!-- article -->
                            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                                <?php the_content(); ?>
                            </article>
                            <!-- /article -->

                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <section class="what-we-offer">
        <div class="container">
            <h2 class="text-capitalize"><?php the_field('our_venture_platform_heading'); ?></h2>
            <p class="m-bottom p-bottom"><?php the_field('our_venture_platform_text'); ?></p>
            <div class="row">
                <?php
                $args = array('post_type' => 'what_we_offer', 'order' => 'ASC');
                $loop = new WP_Query($args);
                $count = 1;
                while ($loop->have_posts()) : $loop->the_post();
                    ?>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="what-we-offer-box m-bottom">
                            <h3><?php the_title(); ?></h3>
                            <div class="text">
                                <?php the_content() ?>
                            </div>
                        </div>
                    </div>
                    <?php
                    $count++;
                endwhile;
                wp_reset_query();
                ?>
            </div>
        </div>

    </section>

    <section class="mission-vision">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-7 col-sm-8">
                    <h2 class="m-bottom"><?php the_field('vision_heading'); ?></h2>
                    <p><?php the_field('vision_text'); ?></p>
                </div>
                <div class="col-md-5 col-sm-5 col-sm-4">
                    <h2 class="m-bottom"><?php the_field('mission_heading'); ?></h2>
                    <p><?php the_field('misson_text'); ?></p>
                </div>
            </div>
        </div>
    </section>

    <!-- /section -->
</main>
<?php get_footer(); ?>
