<?php /* Template Name: Approach */ get_header(); ?> 

<main role="main" class="our-approach">
    <!-- section -->
    <section class="banner">
        <div class="banner-text">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-4 col-sm-5">
                        <h1 class="animated fadeIn"><?php the_field('page_header _title'); ?></h1>
                    </div>
                    <div class="col-lg-7 col-md-8 col-sm-7">
                        <p><?php the_field('page_title_description'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="our-approach-tabs">
        <div class="container">
            <div class="row">
                <div class="approach-tab-container">
                    <div class="col-lg-4 col-md-4 col-sm-4">
                        <div class="approach-tab-menu">
                            <div class="list-group">
                                <a href="#" class="list-group-item active text-center">
                                    <?php the_field('direct_secondaries_tab'); ?>
                                </a>
                                <a href="#" class="list-group-item text-center">
                                    <?php the_field('lp_interest_tab'); ?>
                                </a>
                                <a href="#" class="list-group-item text-center">
                                    <?php the_field('primary_commitments'); ?>
                                </a>
                                <a href="#" class="list-group-item text-center">
                                    <?php the_field('direct_co_Investments'); ?>
                                </a>
                                <a href="#" class="list-group-item text-center">
                                    <?php the_field('tech_buy_out_tab'); ?>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-8 col-sm-8 approach-tab-container col-lg-offset-1">
                        <div class="approach-tab">
                            <!-- flight section -->
                            <div class="approach-tab-content active">
                                <?php the_field('direct_secondaries_content'); ?>
                                <div class="blog-section m-top">
                                    <h2 class="m-bottom">Related Articles</h2>
                                    <div class="recent_news">
                                        <?php
                                        /*
                                         *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
                                         *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
                                         *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
                                         */

                                        $post_objects = get_field('direct_seondaries_posts');

                                        if ($post_objects):
                                            ?>
                                            <?php
                                            $count = 1;
                                            ?>
                                            <?php foreach ($post_objects as $post): // variable must be called $post (IMPORTANT) ?>
                                                <?php setup_postdata($post); ?>
                                                <div class="row post">
                                                    <div class="col-lg-3 col-md-3 col-sm-3">
                                                        <?php
                                                        if (has_post_thumbnail()) {
                                                            ?>
                                                            <div class="image">
                                                                <a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?> title="Read more">  <?php
                                                                    the_post_thumbnail('medium');
                                                                    ?>
                                                                </a>
                                                            </div>
                                                        <?php } else { ?>
                                                            <div class="no_image">
                                                                <a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?> title="Read more"> 

                                                                </a>
                                                            </div>
                                                        <?php } ?>
                                                    </div>
                                                    <div class="col-lg-9 col-md-9 col-sm-9">
                                                        <div class="recent_news_text">
                                                            <h2><a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?>><?php the_title(); ?></a></h2>
                                                            <div class="recent_news_meta">

                                                                <?php
                                                                if (has_category()) {
                                                                    ?>
                                                                    <ul class="post-categories inline-block v-middle">
                                                                        <li>
                                                                            <?php
                                                                            $categories = get_the_category();
                                                                            $separator = ' ';
                                                                            $output = '';
                                                                            $page = 'press';
                                                                            if (!empty($categories)) {
                                                                                foreach ($categories as $category) {
                                                                                    $output .= '<a href="/' . $page . '/#tab' . esc_html($category->slug) . '" alt="' . esc_attr(sprintf(__('View all posts in %s', 'textdomain'), $category->name)) . '">' . esc_html($category->name) . '</a>' . $separator;
                                                                                }
                                                                                echo trim($output, $separator);
                                                                                ?>
                                                                            </li>
                                                                        </ul>

                                                                        <?php
                                                                    }
                                                                } else {
                                                                    ?>
                                                                    <ul class="post-categories inline-block">
                                                                        <?php $category = 'Recent News'; ?>
                                                                        <li>
                                                                            <a href="javascript:void(0);" ><?php echo $category ?></a>
                                                                        </li>
                                                                    </ul>
                                                                <?php }
                                                                ?>

                                                                <span class="inline-block text_green"> - </span>
                                                                <div class="date_author inline-block">
                                                                    <?php the_time('F j, Y'); ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <?php
                                                $count++;
                                            endforeach;
                                            ?>
                                            <?php wp_reset_postdata(); // IMPORTANT - reset the $post object so the rest of the page works correctly ?>
                                            <?php
                                        endif;
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <!-- train section -->
                            <div class="approach-tab-content">
                                <?php the_field('lp_secondaries_content'); ?>
                                <div class="blog-section m-top">
                                    <h2 class="m-bottom">Related Articles</h2>
                                    <div class="recent_news">
                                        <?php
                                        /*
                                         *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
                                         *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
                                         *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
                                         */

                                        $post_objects = get_field('lp_interest_posts');

                                        if ($post_objects):
                                            ?>
                                            <?php
                                            $count = 1;
                                            ?>
                                            <?php foreach ($post_objects as $post): // variable must be called $post (IMPORTANT) ?>
                                                <?php setup_postdata($post); ?>
                                                <div class="row post">
                                                    <div class="col-lg-3 col-md-3 col-sm-3">
                                                        <?php
                                                        if (has_post_thumbnail()) {
                                                            ?>
                                                            <div class="image">
                                                                <a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?> title="Read more">  <?php
                                                                    the_post_thumbnail('medium');
                                                                    ?>
                                                                </a>
                                                            </div>
                                                        <?php } else { ?>
                                                            <div class="no_image">
                                                                <a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?> title="Read more"> 

                                                                </a>
                                                            </div>
                                                        <?php } ?>
                                                    </div>
                                                    <div class="col-lg-9 col-md-9 col-sm-9">
                                                        <div class="recent_news_text">
                                                            <h2><a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?>><?php the_title(); ?></a></h2>
                                                            <div class="recent_news_meta">

                                                                <?php
                                                                if (has_category()) {
                                                                    ?>
                                                                    <ul class="post-categories inline-block">
                                                                        <li>
                                                                            <?php
                                                                            $categories = get_the_category();
                                                                            $separator = ' ';
                                                                            $output = '';
                                                                            $page = 'press';
                                                                            if (!empty($categories)) {
                                                                                foreach ($categories as $category) {
                                                                                    $output .= '<a href="/' . $page . '/#tab' . esc_html($category->slug) . '" alt="' . esc_attr(sprintf(__('View all posts in %s', 'textdomain'), $category->name)) . '">' . esc_html($category->name) . '</a>' . $separator;
                                                                                }
                                                                                echo trim($output, $separator);
                                                                                ?>
                                                                            </li>
                                                                        </ul>

                                                                        <?php
                                                                    }
                                                                } else {
                                                                    ?>
                                                                    <ul class="post-categories inline-block">
                                                                        <?php $category = 'Recent News'; ?>
                                                                        <li>
                                                                            <a href="javascript:void(0);" ><?php echo $category ?></a>
                                                                        </li>
                                                                    </ul>
                                                                <?php }
                                                                ?>

                                                                <span class="inline-block text_green"> - </span>
                                                                <div class="date_author inline-block">
                                                                    <?php the_time('F j, Y'); ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <?php
                                                $count++;
                                            endforeach;
                                            ?>
                                            <?php wp_reset_postdata(); // IMPORTANT - reset the $post object so the rest of the page works correctly ?>
                                            <?php
                                        endif;
                                        ?>
                                    </div>
                                </div>
                            </div>

                            <!-- hotel search -->
                            <div class="approach-tab-content">
                                <?php the_field('primary_commitment_content'); ?>
                                <div class="blog-section m-top">
                                    <h2 class="m-bottom">Related Articles</h2>
                                    <div class="recent_news">
                                        <?php
                                        /*
                                         *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
                                         *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
                                         *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
                                         */

                                        $post_objects = get_field('primary_commitments_posts');

                                        if ($post_objects):
                                            ?>
                                            <?php
                                            $count = 1;
                                            ?>
                                            <?php foreach ($post_objects as $post): // variable must be called $post (IMPORTANT) ?>
                                                <?php setup_postdata($post); ?>
                                                <div class="row post">
                                                    <div class="col-lg-3 col-md-3 col-sm-3">
                                                        <?php
                                                        if (has_post_thumbnail()) {
                                                            ?>
                                                            <div class="image">
                                                                <a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?> title="Read more">  <?php
                                                                    the_post_thumbnail('medium');
                                                                    ?>
                                                                </a>
                                                            </div>
                                                        <?php } else { ?>
                                                            <div class="no_image">
                                                                <a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?> title="Read more"> 

                                                                </a>
                                                            </div>
                                                        <?php } ?>
                                                    </div>
                                                    <div class="col-lg-9 col-md-9 col-sm-9">
                                                        <div class="recent_news_text">
                                                            <h2><a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?>><?php the_title(); ?></a></h2>
                                                            <div class="recent_news_meta">

                                                                <?php
                                                                if (has_category()) {
                                                                    ?>
                                                                    <ul class="post-categories inline-block">
                                                                        <li>
                                                                            <?php
                                                                            $categories = get_the_category();
                                                                            $separator = ' ';
                                                                            $output = '';
                                                                            $page = 'press';
                                                                            if (!empty($categories)) {
                                                                                foreach ($categories as $category) {
                                                                                    $output .= '<a href="/' . $page . '/#tab' . esc_html($category->slug) . '" alt="' . esc_attr(sprintf(__('View all posts in %s', 'textdomain'), $category->name)) . '">' . esc_html($category->name) . '</a>' . $separator;
                                                                                }
                                                                                echo trim($output, $separator);
                                                                                ?>
                                                                            </li>
                                                                        </ul>

                                                                        <?php
                                                                    }
                                                                } else {
                                                                    ?>
                                                                    <ul class="post-categories inline-block">
                                                                        <?php $category = 'Recent News'; ?>
                                                                        <li>
                                                                            <a href="javascript:void(0);" ><?php echo $category ?></a>
                                                                        </li>
                                                                    </ul>
                                                                <?php }
                                                                ?>

                                                                <span class="inline-block text_green"> - </span>
                                                                <div class="date_author inline-block">
                                                                    <?php the_time('F j, Y'); ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <?php
                                                $count++;
                                            endforeach;
                                            ?>
                                            <?php wp_reset_postdata(); // IMPORTANT - reset the $post object so the rest of the page works correctly ?>
                                            <?php
                                        endif;
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="approach-tab-content">
                                <?php the_field('direct_co_Investments_content'); ?>
                                <div class="blog-section m-top">
                                    <h2 class="m-bottom">Related Articles</h2>
                                    <div class="recent_news">
                                        <?php
                                        /*
                                         *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
                                         *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
                                         *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
                                         */

                                        $post_objects = get_field('direct_co-investments_blog_posts');

                                        if ($post_objects):
                                            ?>
                                            <?php
                                            $count = 1;
                                            ?>
                                            <?php foreach ($post_objects as $post): // variable must be called $post (IMPORTANT) ?>
                                                <?php setup_postdata($post); ?>
                                                <div class="row post">
                                                    <div class="col-lg-3 col-md-3 col-sm-3">
                                                        <?php
                                                        if (has_post_thumbnail()) {
                                                            ?>
                                                            <div class="image">
                                                                <a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?> title="Read more">  <?php
                                                                    the_post_thumbnail('medium');
                                                                    ?>
                                                                </a>
                                                            </div>
                                                        <?php } else { ?>
                                                            <div class="no_image">
                                                                <a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?> title="Read more"> 

                                                                </a>
                                                            </div>
                                                        <?php } ?>
                                                    </div>
                                                    <div class="col-lg-9 col-md-9 col-sm-9">
                                                        <div class="recent_news_text">
                                                            <h2><a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?>><?php the_title(); ?></a></h2>
                                                            <div class="recent_news_meta">

                                                                <?php
                                                                if (has_category()) {
                                                                    ?>
                                                                    <ul class="post-categories inline-block">
                                                                        <li>
                                                                            <?php
                                                                            $categories = get_the_category();
                                                                            $separator = ' ';
                                                                            $output = '';
                                                                            $page = 'press';
                                                                            if (!empty($categories)) {
                                                                                foreach ($categories as $category) {
                                                                                    $output .= '<a href="/' . $page . '/#tab' . esc_html($category->slug) . '" alt="' . esc_attr(sprintf(__('View all posts in %s', 'textdomain'), $category->name)) . '">' . esc_html($category->name) . '</a>' . $separator;
                                                                                }
                                                                                echo trim($output, $separator);
                                                                                ?>
                                                                            </li>
                                                                        </ul>

                                                                        <?php
                                                                    }
                                                                } else {
                                                                    ?>
                                                                    <ul class="post-categories inline-block">
                                                                        <?php $category = 'Recent News'; ?>
                                                                        <li>
                                                                            <a href="javascript:void(0);" ><?php echo $category ?></a>
                                                                        </li>
                                                                    </ul>
                                                                <?php }
                                                                ?>

                                                                <span class="inline-block text_green"> - </span>
                                                                <div class="date_author inline-block">
                                                                    <?php the_time('F j, Y'); ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <?php
                                                $count++;
                                            endforeach;
                                            ?>
                                            <?php wp_reset_postdata(); // IMPORTANT - reset the $post object so the rest of the page works correctly ?>
                                            <?php
                                        endif;
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="approach-tab-content">
                                <?php the_field('techbuyout_content'); ?>
                                <div class="blog-section m-top">
                                    <h2 class="m-bottom">Related Articles</h2>
                                    <div class="recent_news">
                                        <?php
                                        /*
                                         *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
                                         *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
                                         *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
                                         */

                                        $post_objects = get_field('tech_buyout_related');

                                        if ($post_objects):
                                            ?>
                                            <?php
                                            $count = 1;
                                            ?>
                                            <?php foreach ($post_objects as $post): // variable must be called $post (IMPORTANT) ?>
                                                <?php setup_postdata($post); ?>
                                                <div class="row post">
                                                    <div class="col-lg-3 col-md-3 col-sm-3">
                                                        <?php
                                                        if (has_post_thumbnail()) {
                                                            ?>
                                                            <div class="image">
                                                                <a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?> title="Read more">  <?php
                                                                    the_post_thumbnail('medium');
                                                                    ?>
                                                                </a>
                                                            </div>
                                                        <?php } else { ?>
                                                            <div class="no_image">
                                                                <a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?> title="Read more"> 

                                                                </a>
                                                            </div>
                                                        <?php } ?>
                                                    </div>
                                                    <div class="col-lg-9 col-md-9 col-sm-9">
                                                        <div class="recent_news_text">
                                                            <h2><a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?>><?php the_title(); ?></a></h2>
                                                            <div class="recent_news_meta">

                                                                <?php
                                                                if (has_category()) {
                                                                    ?>
                                                                    <ul class="post-categories inline-block">
                                                                        <li>
                                                                            <?php
                                                                            $categories = get_the_category();
                                                                            $separator = ' ';
                                                                            $output = '';
                                                                            $page = 'press';
                                                                            if (!empty($categories)) {
                                                                                foreach ($categories as $category) {
                                                                                    $output .= '<a href="/' . $page . '/#tab' . esc_html($category->slug) . '" alt="' . esc_attr(sprintf(__('View all posts in %s', 'textdomain'), $category->name)) . '">' . esc_html($category->name) . '</a>' . $separator;
                                                                                }
                                                                                echo trim($output, $separator);
                                                                                ?>
                                                                            </li>
                                                                        </ul>

                                                                        <?php
                                                                    }
                                                                } else {
                                                                    ?>
                                                                    <ul class="post-categories inline-block">
                                                                        <?php $category = 'Recent News'; ?>
                                                                        <li>
                                                                            <a href="javascript:void(0);" ><?php echo $category ?></a>
                                                                        </li>
                                                                    </ul>
                                                                <?php }
                                                                ?>

                                                                <span class="inline-block text_green"> - </span>
                                                                <div class="date_author inline-block">
                                                                    <?php the_time('F j, Y'); ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <?php
                                                $count++;
                                            endforeach;
                                            ?>
                                            <?php wp_reset_postdata(); // IMPORTANT - reset the $post object so the rest of the page works correctly ?>
                                            <?php
                                        endif;
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
    <section class="white-papers line_bg" id="whitepapers">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-4 col-sm-4">
                    <h2>White Papers</h2>
                </div>
                <div class="col-lg-7 col-md-8 col-sm-8">
                    <p><?php the_field('white_paper_content'); ?></p>
                    <div class="cta-btns m-top p-top">
                        <a href="<?php the_field('whitepaper_cta_1'); ?>" class="btn btn_green btn-lg" target="_blank">Venture Capital Secondaries</a>
                        <a href="<?php the_field('whitepaper_cta_2'); ?>" class="btn btn_green btn-lg" target="_blank">Venture Capital Rebound</a>
                        <a href="http://www.industryventures.com/small-tech-buyout/" class="btn btn_green btn-lg" target="_blank">Small Tech Buyout</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- /section -->
</main>
<script>
    jQuery(document).ready(function () {
        jQuery("div.approach-tab-menu>div.list-group>a").on('click', function (e) {
            e.preventDefault();
            jQuery(this).siblings('a.active').removeClass("active");
            jQuery(this).addClass("active");
            var index = jQuery(this).index();
            jQuery("div.approach-tab>div.approach-tab-content").removeClass("active");
            jQuery("div.approach-tab>div.approach-tab-content").eq(index).addClass("active");
        });
    });
</script>
<?php get_footer(); ?>
