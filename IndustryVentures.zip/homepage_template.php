<?php /* Template Name: Home Template */ get_header(); ?> 

<main role="main">
    <!-- section -->
    <section class="banner">
        <div class="container">
            <h1 class="animated fadeIn"><?php the_field('page_header _title'); ?></h1>
        </div>
    </section>
    <section class="p-top m-top p-bottom m-bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-4">
                    <h2><?php the_field('section_title') ?></h2>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4">
                    <h3><?php the_field('difference_page_title_1'); ?></h3>
                    <p><?php the_field('difference_page_1_description'); ?></p>
                    <p class="m-top"><a class="btn btn_green" href="<?php the_field('difference_page_link_1'); ?>">Learn More</a></p>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4">
                    <h3><?php the_field('difference_page_title_2'); ?></h3>
                    <p><?php the_field('difference_page_2_description'); ?></p>
                    <p class="m-top"><a class="btn btn_green" href="<?php the_field('difference_page_link_2'); ?>">Learn More</a></p>
                </div>
            </div>
        </div>
    </section>
    <section class="counters bg_green">
        <div class="container">
            <div class="row">
                <?php
                $args = array('post_type' => 'counter_numbers', 'order' => 'ASC');
                $loop = new WP_Query($args);
                $count = 1;
                while ($loop->have_posts()) : $loop->the_post();
                    ?>
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                        <div class="counter_box">
                            <div class="counter_numbers">
                                <?php the_field('counter_number'); ?>
                            </div>
                            <div class="counter_subtexts">
                                <?php the_field('counter_text'); ?>
                            </div>
                        </div>
                    </div>
                    <?php if ($count % 2 == 0) { ?>
                        <div class="clearfix visible-xs"></div>   
                    <?php }
                    ?>
                    <?php
                    $count++;
                endwhile;
                wp_reset_query();
                ?>
            </div>
        </div>
    </section>
    <section class="bg_dark">

    </section>
    <section class="investments-section">
        <div class="container-fluid">
            <div class="row">
                <div class="investments-wrapper">
                    <div class="col-lg-6 col-md-6">
                        <div class="row">
                            <div class="investment-col line_bg">
                                <div class="m-bottom p-bottom">
                                    <h2><?php the_field('investement_section_title'); ?></h2>
                                    <h3><?php the_field('portfolio_companies'); ?></h3>
                                    <p><?php the_field('portfolio_companies_description'); ?></p>
                                </div>
                                <div class="m-bottom p-bottom">
                                    <h3><?php the_field('venture_funds'); ?></h3>
                                    <p><?php the_field('venture_funds_description'); ?></p>
                                </div>
                                <div class="m-bottom p-bottom">
                                    <a href="<?php the_field('investments_page_link'); ?>" class="btn btn-lg btn_green text-uppercase">View All Exits</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="partners-logos">
                            <div class="row">
                                <?php
                                /*
                                 *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
                                 *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
                                 *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
                                 */

                                $post_objects = get_field('homepage_partner_logos');

                                if ($post_objects):
                                    ?>
                                    <?php
                                    $count = 1;
                                    ?>
                                    <?php foreach ($post_objects as $post): // variable must be called $post (IMPORTANT) ?>
                                        <?php setup_postdata($post); ?>
                                        <div class="col-lg-6 col-md-6 col-xs-6">
                                            <div class="investment_logos text-center">
                                                <?php the_post_thumbnail(); ?>
                                            </div>
                                        </div>
                                        <?php if ($count % 2 == 0) { ?>
                                            <div class="clearfix"></div>
                                        <?php }
                                        ?>
                                        <?php
                                        $count++;
                                    endforeach;
                                    ?>
                                    <?php wp_reset_postdata(); // IMPORTANT - reset the $post object so the rest of the page works correctly ?>
                                    <?php
                                endif;
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
    <section class="bg_dark_two">

    </section>
    <section class="blog-section">
        <div class="container-fluid">
            <div class="row">
                <div class="blog-wrapper">
                    <div class="col-lg-6 col-md-6">
                        <div class="row">

                            <div id="blog_posts" class="blog_posts">
                                <div class="section_header">
                                    <h2 class="pull-left"><?php the_field('blog_section_title'); ?></h2>
                                    <a href="/press/" class="pull-right text-uppercase">view all</a>
                                    <div class="clearfix"></div>
                                </div>
                                <?php
                                // Display blog posts on any page @ https://m0n.co/l
                                $temp = $wp_query;
                                $wp_query = null;
                                $wp_query = new WP_Query();
                                $wp_query->query('posts_per_page=3' . '&paged=' . $paged);
                                $count = 1;
                                while ($wp_query->have_posts()) : $wp_query->the_post();
                                    ?>
                                    <div class="post m-bottom p-bottom-s">
                                        <h2><a class="" href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?>><?php the_title(); ?></a></h2>
                                        <div class="blog-post-meta">
                                            <span class="date inline-block v-middle"><?php the_time('F j, Y'); ?></span>
                                            <span class="inline-block v-middle">-</span>
                                            <span class="author inline-block v-middle"><?php _e('By', 'html5blank'); ?></span>
                                            <?php
                                            $second_author = get_field('post_second_author');
                                            if ($second_author != '') {
                                                ?>
                                                <span class="author inline-block v-middle">
                                                    <?php echo $second_author; ?> 
                                                </span>
                                            <?php } ?>
                                        </div>
                                        <p class="m-top-s m-bottom-s"><?php the_excerpt(); ?></p>
                                        <a class="view-article text_green text-uppercase" href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?>>Read More</a>
                                    </div>
                                    <?php
                                    $count++;
                                endwhile;
                                ?>



                                <?php wp_reset_postdata(); // IMPORTANT - reset the $post object so the rest of the page works correctly  ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="row">
                            <div id="recent_news" class="recent_news line_bg">
                                <div class="section_header">
                                    <h2 class="pull-left">Recent News </h2>
                                    <a href="/press/" class="pull-right text-uppercase">view all</a>
                                    <div class="clearfix"></div>
                                </div>
                                <?php
                                $args = array('post_type' => 'recent_news', 'showposts' => 6, 'order' => 'DSC');
                                $loop = new WP_Query($args);
                                $count = 1;
                                while ($loop->have_posts()) : $loop->the_post(); 
                                    ?>
                                    <div class="row post">
                                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                                            <?php
                                            if (has_post_thumbnail()) {
                                                ?>
                                                <div class="image">
                                                    <a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?>>
                                                        <?php
                                                        the_post_thumbnail('medium');
                                                        ?>
                                                    </a>
                                                </div>
                                            <?php } else { ?>
                                                <div class="no_image">
                                                    <a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?>></a>
                                                </div>
                                            <?php } ?>
                                        </div>
                                        <div class="col-lg-9 col-md-9 col-sm-9 col-xs-9">
                                            <div class="recent_news_text">
                                                <h2><a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?>><?php the_title(); ?></a></h2>
                                                <div class="recent_news_meta">

                                                    <?php
                                                    if (has_category()) {
                                                        ?>
                                                        <ul class="post-categories inline-block v-middle">
                                                            <li>
                                                                <?php
                                                                $categories = get_the_category();
                                                                $separator = ' ';
                                                                $output = '';
                                                                $page = 'press';
                                                                if (!empty($categories)) {
                                                                    foreach ($categories as $category) {
                                                                        $output .= '<a href="/' . $page . '/#tab' . esc_html($category->slug) . '" alt="' . esc_attr(sprintf(__('View all posts in %s', 'textdomain'), $category->name)) . '">' . esc_html($category->name) . '</a>' . $separator;
                                                                    }
                                                                    echo trim($output, $separator);
                                                                    ?>
                                                                </li>
                                                            </ul>

                                                            <?php
                                                        }
                                                    } else {
                                                        ?>
                                                        <ul class="post-categories inline-block v-middle">
                                                            <?php $category = 'Recent News'; ?>
                                                            <li>
                                                                <a href="javascript:void(0);" ><?php echo $category ?></a>
                                                            </li>
                                                        </ul>
                                                    <?php }
                                                    ?>

                                                    <span class="inline-block text_green v-middle"> - </span>
                                                    <div class="date_author inline-block v-middle">
                                                        <?php the_time('F j, Y'); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $count++;
                                endwhile;
                                wp_reset_query();
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
    <!-- /section -->
</main>
<script>
    jQuery(document).ready(function () {
        var height = jQuery('.blog-wrapper').height();
        jQuery('#recent_news').css('min-height', height);
    });
    jQuery(document).ready(function ($) {
        $('.counter').counterUp({
            delay: 10,
            time: 1000
        });
    });
    jQuery(window).resize(function () {
        var height = jQuery('.blog-wrapper').height();
        jQuery('#recent_news').css('min-height', height);
    });
</script>
<?php get_footer(); ?>
