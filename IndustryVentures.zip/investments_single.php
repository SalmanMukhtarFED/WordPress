<?php if (have_posts()): while (have_posts()) : the_post(); ?>

        <section class="company_info">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <h2 class="m-bottom"><?php the_title(); ?></h2>
                        <div class="text">
                            <?php the_content(); ?>
                        </div>
                        <div class="m-top small">
                            <?php
                            $date = get_field('company_date');
                            if ($date != '') {
                                ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <strong>Date:</strong>
                                    </div>
                                    <div class="col-md-4">
                                        <?php echo $date ?>
                                    </div>
                                </div>
                            <?php } ?>
                            <?php
                            $location = get_field('company_location');
                            if ($date != '') {
                                ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <strong>Location:</strong>
                                    </div>
                                    <div class="col-md-4">
                                        <?php echo $location ?>
                                    </div>
                                </div>
                            <?php } ?>
                            <?php
                            $status = get_field('company_status');
                            if ($status != '') {
                                ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <strong>Status:</strong>
                                    </div>
                                    <div class="col-md-4">
                                        <?php echo $status ?>
                                    </div>
                                </div>
                            <?php } ?>
                            <?php
                            $company_link = get_field('investment_company_link');
                            if ($company_link != '') {
                                ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <strong>Website:</strong>
                                    </div>
                                    <div class="col-md-4">
                                        <?php echo $company_link ?>
                                    </div>
                                </div>
                            <?php } ?>

                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="image">
                            <?php the_post_thumbnail(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="next-previous">
            <div class="container">
                <div class="text-center">
                    <?php
                    $next_post = get_next_post();
                    $prev_post = get_previous_post();
                    ?>

                    <div class="all-team inline-block">
                        <a href="/investments/">All Investments</a>
                    </div>

                    <div class="clear"></div>
                </div>
            </div>
        </section>
        <section class="blog-section">
            <div class="container">
                <div class="">
                    <div class="blog-wrapper">
                        <div id="recent_news" class="recent_news line_bg">
                            <div class="section_header">
                                <h2 class="pull-left">Recent News</h2>
                                <a href="/press-center" class="pull-right text-uppercase">view all</a>
                                <div class="clearfix"></div>
                            </div>
                            <div class="row">
                                <?php
                                /*
                                 *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
                                 *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
                                 *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
                                 */

                                $query = new WP_Query(array(
                                    'post_type' => 'recent_news',
                                    'post_status' => 'publish',
                                    'posts_per_page' => 6
                                ));
                                $count = 1;
                                while ($query->have_posts()) {
                                    $query->the_post();
                                    ?>
                                    <div class="col-lg-6 col-md-6">
                                        <div class="recent_news_meta">
                                            <div class="categories inline-block">

                                                <?php
                                                if (has_category()) {
                                                    ?>
                                                    <ul class="post-categories">
                                                        <li>
                                                            <?php
                                                            $categories = get_the_category();
                                                            $separator = ' ';
                                                            $output = '';
                                                            $page = 'press-center';
                                                            if (!empty($categories)) {
                                                                foreach ($categories as $category) {
                                                                    $output .= '<a href="/' . $page . '/#tab' . esc_html($category->slug) . '" alt="' . esc_attr(sprintf(__('View all posts in %s', 'textdomain'), $category->name)) . '">' . esc_html($category->name) . '</a>' . $separator;
                                                                }
                                                                echo trim($output, $separator);
                                                                ?>
                                                            </li>
                                                        </ul>

                                                        <?php
                                                    }
                                                } else {
                                                    ?>
                                                    <ul class="post-categories">
                                                        <?php $category = 'Recent News'; ?>
                                                        <li>
                                                            <a href="javascript:void(0);" ><?php echo $category ?></a>
                                                        </li>
                                                    </ul>
                                                <?php }
                                                ?>
                                            </div>
                                            <span class="inline-block dot"> . </span>
                                            <div class="date_author inline-block">
                                                <a href="<?php the_permalink(); ?>" class="text_green" > <?php the_time('F j, Y'); ?></a>
                                            </div>
                                        </div>
                                        <div class="post">
                                            <h2><a href="<?php the_permalink(); ?>" ><?php the_title(); ?></a></h2>
                                            <p class="m-top-s m-bottom-s"><?php the_excerpt(); ?></p>
                                        </div>
                                    </div>
                                    <?php if ($count % 2 == 0) { ?>
                                        <div class="clearfix"></div>   
                                    <?php }
                                    ?>
                                    <?php $count++;
                                }
                                wp_reset_query();
                                ?>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </section>
    <?php endwhile; ?>

<?php else: ?>

    <!-- article -->
    <article>

        <h1><?php _e('Sorry, nothing to display.', 'html5blank'); ?></h1>

    </article>
    <!-- /article -->

<?php endif; ?>
