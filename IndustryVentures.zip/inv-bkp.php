<?php /* Template Name: Investments */ get_header(); ?> 

<main role="main" class="our-investments">
    <!-- section -->
    <section class="banner">
        <div class="banner-text">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-3">
                        <h1 class="animated fadeIn"><?php the_field('page_header _title'); ?></h1>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-9">
                        <p><?php the_field('page_title_description'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="featured_invetments">
        <div class="container">
            <h2>Featured</h2>
            <div class="flex_container">
                <?php
                $args = array(
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'investments_categories',
                            'field' => 'slug',
                            'terms' => array('featured')
                        ),
                    ),
                    'post_type' => 'investment_partners'
                );
                $loop = new WP_Query($args);
                if ($loop->have_posts()) {
                    $term = $wp_query->queried_object;
                    while ($loop->have_posts()) : $loop->the_post();
                        ?>    
                        <div class="investments_logo flex_item">
                            <?php the_post_thumbnail(); ?>
                        </div>
                        <?php
                    endwhile;
                    wp_reset_query();
                }
                ?>
            </div>
        </div>
    </section>
    <section class="all_invenstments">
        <div class="container">
            <div class="row">
                <div class="gallery col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <h1 class="gallery-title">Gallery</h1>
                </div>

                <div align="center">
                    <button class="btn btn-default filter-button active" data-filter="all">All</button>
                    <button class="btn btn-default filter-button" data-filter="hdpe">HDPE Pipes</button>
                    <button class="btn btn-default filter-button" data-filter="sprinkle">Sprinkle Pipes</button>
                    <button class="btn btn-default filter-button" data-filter="spray">Spray Nozzle</button>
                    <button class="btn btn-default filter-button" data-filter="irrigation">Irrigation Pipes</button>
                </div>
                <br/>



                <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter hdpe">
                    <img src="http://fakeimg.pl/365x365/" class="img-responsive">
                </div>

                <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter sprinkle">
                    <img src="http://fakeimg.pl/365x365/" class="img-responsive">
                </div>

                <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter hdpe">
                    <img src="http://fakeimg.pl/365x365/" class="img-responsive">
                </div>

                <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter irrigation">
                    <img src="http://fakeimg.pl/365x365/" class="img-responsive">
                </div>

                <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter spray">
                    <img src="http://fakeimg.pl/365x365/" class="img-responsive">
                </div>

                <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter irrigation">
                    <img src="http://fakeimg.pl/365x365/" class="img-responsive">
                </div>

                <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter spray">
                    <img src="http://fakeimg.pl/365x365/" class="img-responsive">
                </div>

                <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter irrigation">
                    <img src="http://fakeimg.pl/365x365/" class="img-responsive">
                </div>

                <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter irrigation">
                    <img src="http://fakeimg.pl/365x365/" class="img-responsive">
                </div>

                <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter hdpe">
                    <img src="http://fakeimg.pl/365x365/" class="img-responsive">
                </div>

                <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter spray">
                    <img src="http://fakeimg.pl/365x365/" class="img-responsive">
                </div>

                <div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter sprinkle">
                    <img src="http://fakeimg.pl/365x365/" class="img-responsive">
                </div>
            </div>
        </div>
    </section>
    <section class="scroll-section section-padder portfolio-tabs">

        <div class="container">
            <?php
            $cat_array = get_categories(array('taxonomy' => 'investments_categories')); //'type=portfolio'
            $count_categories = count($cat_array);
            //var_dump($count_categories);
            ?>
            <div class="row">
                <!-- Nav tabs -->
                <ul class="filters" role="tablist">
                    <?php
                    for ($i = 0; $i < $count_categories; $i++) {
                        
                        ?>
                        <li class="<?php echo $class; ?>">
                            <a data-filter="<?php echo $i; ?>" class="filter-button">
                                <?php echo ($cat_array[$i]->name); ?>
                            </a>
                        </li>
                    <?php }
                    ?>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content section-padder">
                    <div class="filter all">
                        <?php
                        $args = array('post_type' => 'investment_partners', 'order' => 'ASC');
                        $loop = new WP_Query($args);
                        $count = 1;
                        while ($loop->have_posts()) : $loop->the_post();
                            ?>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6">
                                    <a class="portfolio-item-wrapper" href="<?php the_permalink(); ?>">
                                        <div class="item-thumbnail">
                                            <?php the_title(); ?>
                                        </div>
                                    </a>
                                </div>
                            
                            <?php
                            $count++;
                        endwhile;
                        wp_reset_query();
                        ?>
                    </div>
                    <?php
                    for ($i = 0; $i < $count_categories; $i++) {
                        ?>

                        <div class="filter <?php echo $i; ?>">
                            <?php $current_category = $cat_array[$i]->slug ?>
                            <?php
                            $tax_queries = array(
                                array(
                                    'taxonomy' => 'investments_categories',
                                    'field' => 'term_id',
                                    'terms' => array($cat_array[$i]->term_id)
                                )
                            );


                            $args = array('post_type' => 'investment_partners', 'order' => 'ASC', 'tax_query' => $tax_queries);

                            $loop = new WP_Query($args);

                            $count = 1;
                            while ($loop->have_posts()) : $loop->the_post();
                                ?>
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6">
                                    <a class="portfolio-item-wrapper" href="<?php the_permalink(); ?>">
                                        <div class="item-thumbnail">
                                            <?php the_title(); ?>
                                        </div>
                                    </a>
                                </div>
                                <?php
                                $count++;
                            endwhile;
                            wp_reset_query();
                            ?>
                        </div>
                    <?php }
                    ?>
                </div>
            </div>
        </div>
    </section>

    <!-- /section -->
</main>
<script>
    jQuery(document).ready(function () {
        jQuery("div.approach-tab-menu>div.list-group>a").on('click', function (e) {
            e.preventDefault();
            jQuery(this).siblings('a.active').removeClass("active");
            jQuery(this).addClass("active");
            var index = jQuery(this).index();
            jQuery("div.approach-tab>div.approach-tab-content").removeClass("active");
            jQuery("div.approach-tab>div.approach-tab-content").eq(index).addClass("active");
        });

    });
    jQuery(document).ready(function () {

        jQuery(".filter-button").click(function () {
            var value = jQuery(this).attr('data-filter');

            if (value == "all")
            {
                //$('.filter').removeClass('hidden');
                jQuery('.filter').show('1000');
            }
            else
            {
//            $('.filter[filter-item="'+value+'"]').removeClass('hidden');
//            $(".filter").not('.filter[filter-item="'+value+'"]').addClass('hidden');
                jQuery(".filter").not('.' + value).hide('3000');
                jQuery('.filter').filter('.' + value).show('3000');

            }
        });

    });
</script>
<?php get_footer(); ?>
