<?php if (have_posts()): while (have_posts()) : the_post(); ?>
        <?php $featured_image = get_the_post_thumbnail_url() ?>
        <!-- section -->
        <section class="press_single_wrap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-8">
                        <h1 class="animated fadeIn title"><?php the_title(); ?></h1>
                        <div class="recent_news_meta">
                            <div class="date_author inline-block v-middle">
                                <?php the_time('F j, Y'); ?>
                            </div>
                            <span class="inline-block hidden-xs"> | </span>
                            <div class="categories inline-block v-middle">


                                <?php
                                $type = get_post_type();
                                if ($type == 'post') {
                                    $type = 'blog';
                                }
                                $type = str_replace('_', ' ', $type);
                                echo 'In ' . ucfirst($type);
                                ?>
                                
                                <?php
                                $second_author = get_field('post_second_author');
                                if ($second_author != '') {
                                    ?>
                                    <span class="inline-block v-middle hidden-xs"> | </span>
                                    <span class="inline-block v-middle">By </span>
                                    <span class="author inline-block v-middle">
                                        <?php echo $second_author; ?> 
                                    </span>
                                <?php } ?>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <?php if ($featured_image != '') { ?>

                <div class="press_single_img" style="background: url(<?php echo $featured_image; ?>) no-repeat;"></div>
            <?php }
            ?>
        </section>



    <?php endwhile; ?>

    <section class="press_single_content">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-8 col-sm-8 press_single_details">
                    <?php the_content(get_the_title()); ?>

                </div>
                <div class="col-lg-4 col-md-4 col-sm-4">
                    <div class="blog-section">
                        <div id="blog_posts" class="blog_posts">
                            <div class="section_header">
                                <h2 class="pull-left">Recent Blogs Articles</h2>
                                <a href="/press/" class="pull-right text-uppercase text_green">view all</a>
                                <div class="clearfix"></div>
                            </div>
                            <?php
                            /*
                             *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
                             *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
                             *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
                             */
                            $query = new WP_Query(array(
                                'post_type' => 'post',
                                'post_status' => 'publish',
                                'posts_per_page' => 2
                            ));

                            while ($query->have_posts()) {
                                $query->the_post();
                                ?>
                                <div class="post m-bottom">
                                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                    <p class="m-top-s m-bottom-s"><?php the_excerpt(); ?></p>
                                    <p><a href="<?php the_permalink();?>" class="view-article text_green text-uppercase">Read More</a></p>
                                </div>
                                <?php
                            }
                            wp_reset_query();
                            ?>
                        </div>
                    </div>
                    <div class="blog-section">
                        <div id="recent_news" class="recent_news line_bg">
                            <div class="section_header">
                                <h2 class="pull-left">Recent News</h2>
                                <a href="/press/" class="pull-right text-uppercase text_green">view all</a>
                                <div class="clearfix"></div>
                            </div>

                            <?php
                            /*
                             *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
                             *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
                             *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
                             */

                            $post_objects = get_field('select_recent_news_to_show_on_homepage');

                            $query = new WP_Query(array(
                                'post_type' => 'recent_news',
                                'post_status' => 'publish',
                                'posts_per_page' => 3
                            ));

                            while ($query->have_posts()) {
                                $query->the_post();
                                ?>
                                <div class="row post">
                                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-3">
                                        <?php
                                        if (has_post_thumbnail()) {
                                            ?>
                                            <div class="image">
                                                <a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?>>
                                                    <?php
                                                    the_post_thumbnail('thumbnail');
                                                    ?>
                                                </a>
                                            </div>
                                        <?php } else { ?>
                                            <div class="no_image">
                                                <a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?>></a>
                                            </div>
                                        <?php } ?>
                                    </div>
                                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-9">
                                        <div class="recent_news_text">
                                            <h2><a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?>><?php the_title(); ?></a></h2>
                                            <div class="recent_news_meta">
                                                <?php
                                                    if (has_category()) {
                                                        ?>
                                                        <ul class="post-categories inline-block v-middle">
                                                            <li>
                                                                <?php
                                                                $categories = get_the_category();
                                                                $separator = ' ';
                                                                $output = '';
                                                                $page = 'press';
                                                                if (!empty($categories)) {
                                                                    foreach ($categories as $category) {
                                                                        $output .= '<a href="/' . $page . '/#tab' . esc_html($category->slug) . '" alt="' . esc_attr(sprintf(__('View all posts in %s', 'textdomain'), $category->name)) . '">' . esc_html($category->name) . '</a>' . $separator;
                                                                    }
                                                                    echo trim($output, $separator);
                                                                    ?>
                                                                </li>
                                                            </ul>

                                                            <?php
                                                        }
                                                    } else {
                                                        ?>
                                                        <ul class="post-categories inline-block v-middle">
                                                            <?php $category = 'Recent News'; ?>
                                                            <li>
                                                                <a href="javascript:void(0);" ><?php echo $category ?></a>
                                                            </li>
                                                        </ul>
                                                    <?php }
                                                    ?>
                                                <span class="inline-block v-middle text_green"> - </span>
                                                <div class="date_author inline-block v-middle">
                                                    <?php the_time('F j, Y'); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            wp_reset_query();
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="post_social_icon">
        <?php echo do_shortcode('[aps-social id="1"]') ?>
    </div>

<?php else: ?>

    <!-- article -->
    <article>

        <h1><?php _e('Sorry, nothing to display.', 'html5blank'); ?></h1>

    </article>
    <!-- /article -->

<?php endif; ?>

<script>
    jQuery(document).ready(function () {

        jQuery('body').addClass('press-single');

    });
</script>