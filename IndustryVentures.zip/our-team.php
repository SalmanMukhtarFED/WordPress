<?php /* Template Name: Our Team Page */ get_header(); ?>

<main role="main" class="our-team">
    <!-- section -->
    <section class="banner">
        <div class="banner-text">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-4 col-sm-5">
                        <h1 class="animated fadeIn"><?php the_field('page_header _title'); ?></h1>

                    </div>
                    <div class="col-lg-7 col-md-8 col-sm-7">
                        <p><?php the_field('page_title_description'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="team_members">

        <div class="container">
            <?php
            $cat_array = get_categories(array('taxonomy' => 'team_taxonomy')); //'type=portfolio'
            $count_categories = count($cat_array);
            //var_dump($count_categories);
            ?>
            <div class="member-tabs">
                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist">
                    <li class="active">
                        <a data-toggle="tab" href="#all" class="tab-link" aria-controls="all">
                            Show ALL
                        </a>
                    </li>
                    <?php
                    for ($i = 0; $i < $count_categories; $i++) {
                        ?>
                        <li class="<?php echo $class; ?>">
                            <a data-toggle="tab" href="#tab-<?php echo $i; ?>" class="tab-link <?php echo $class ?>" aria-controls="tab-<?php echo $i; ?>">
                                <?php echo ($cat_array[$i]->name); ?>
                            </a>
                        </li>
                    <?php }
                    ?>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content">

                    <div role="tabpanel" id="all" class="tab-pane fade active in">
                        <div class="row">
                            <?php
                            $args = array('post_type' => 'team_members', 'order' => 'ASC');
                            $loop = new WP_Query($args);
                            $count = 1;
                            while ($loop->have_posts()) : $loop->the_post();
                                ?>
                                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 team_member">
                                    <a href="<?php the_permalink() ?>">
                                        <?php
                                        $image_arr = wp_get_attachment_image_src(get_post_thumbnail_id($post_array->ID), 'large');
                                        $image_url = $image_arr[0]; // $image_url is your URL.
                                        //var_dump($image_url);
                                        //$featured_image = the_post_thumbnail_url('large');
                                        //var_dump($featured_image);
                                        //$size = getimagesize($featured_image);
                                        //var_dump($size);
                                        ?>
                                        <div class="image_wrap">
                                            <div class="image" style="background-image: url(<?php echo $image_url ?>)">
                                                <div class="overlay">

                                                </div>
                                            </div>
                                        </div>
                                        <div class="name">
                                            <?php the_title(); ?>
                                        </div>
                                        <div class="designation">
                                            <?php the_field('member_designation'); ?>
                                        </div>
                                    </a>
                                </div>
                                <?php if ($count % 2 == 0) { ?>
                                    <div class="clearfix visible-xs visible-sm"></div>   
                                <?php }
                                ?>
                                <?php
                                $count++;
                            endwhile;
                            wp_reset_query();
                            ?>
                        </div>
                    </div>

                    <?php
                    for ($i = 0; $i < $count_categories; $i++) {
                        ?>
                        <div role="tabpanel" id="tab-<?php echo $i; ?>" class="tab-pane fade">
                            <?php $current_category = $cat_array[$i]->slug ?>
                            <?php
                            $tax_queries = array(
                                array(
                                    'taxonomy' => 'team_taxonomy',
                                    'field' => 'term_id',
                                    'terms' => array($cat_array[$i]->term_id)
                                )
                            );


                            $args = array('post_type' => 'team_members', 'order' => 'ASC', 'tax_query' => $tax_queries);

                            $loop = new WP_Query($args);

                            $count = 1;
                            while ($loop->have_posts()) : $loop->the_post();
                                ?>
                                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6 team_member">
                                    <a href="<?php the_permalink() ?>">
                                        <?php
                                        $image_arr = wp_get_attachment_image_src(get_post_thumbnail_id($post_array->ID), 'large');
                                        $image_url = $image_arr[0]; // $image_url is your URL.
                                        //var_dump($image_url);
                                        //$featured_image = the_post_thumbnail_url('large');
                                        //var_dump($featured_image);
                                        //$size = getimagesize($featured_image);
                                        //var_dump($size);
                                        ?>
                                        <div class="image_wrap">
                                            <div class="image" style="background-image: url(<?php echo $image_url ?>)">
                                                <div class="overlay">

                                                </div>
                                            </div>
                                        </div>
                                        <div class="name">
                                            <?php the_title(); ?>
                                        </div>
                                        <div class="designation">
                                            <?php the_field('member_designation'); ?>
                                        </div>
                                    </a>
                                </div>
                                <?php if ($count % 2 == 0) { ?>
                                    <div class="clearfix visible-xs"></div>   
                                <?php }
                                ?>
                                <?php
                                $count++;
                            endwhile;
                            wp_reset_query();
                            ?>
                        </div>
                    <?php }
                    ?>
                </div>
            </div>
        </div>
    </section>

    <!-- /section -->
</main>
<script>
    jQuery(document).ready(function () {
        jQuery("div.approach-tab-menu>div.list-group>a").on('click', function (e) {
            e.preventDefault();
            jQuery(this).siblings('a.active').removeClass("active");
            jQuery(this).addClass("active");
            var index = jQuery(this).index();
            jQuery("div.approach-tab>div.approach-tab-content").removeClass("active");
            jQuery("div.approach-tab>div.approach-tab-content").eq(index).addClass("active");
        });
        jQuery(".down-scroll").click(function () {
            //$(this).animate(function(){
            var top_position = jQuery(".scroll-section").offset().top;
            var top_position = top_position;
            jQuery('html, body').animate({
                scrollTop: top_position
            }, 1000);
            //});
        });
    });

</script>
<?php get_footer(); ?>
