<?php /* Template Name: Page with Right Sidebar */ get_header(); ?>
<?php get_header(); ?>

<main role="main">
    <!-- section -->
    <section class="banner">
        <div class="banner-text">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-4 col-sm-5">
                        <h1 class="animated fadeIn"><?php the_field('page_header _title'); ?></h1>
                    </div>
                    <div class="col-lg-7 col-md-8 col-sm-7">
                        <p><?php the_field('page_title_description'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- section -->
    <section class="content">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <div class="text">
                        <h1><?php the_title(); ?></h1>

                        <?php if (have_posts()): while (have_posts()) : the_post(); ?>

                                <!-- article -->
                                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

                                    <?php the_content(); ?>
                                    <?php edit_post_link(); ?>

                                </article>
                                <!-- /article -->

                            <?php endwhile; ?>

                        <?php else: ?>

                            <!-- article -->
                            <article>

                                <h2><?php _e('Sorry, nothing to display.', 'html5blank'); ?></h2>

                            </article>
                            <!-- /article -->

                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 sidebar">
                    <div class="blog-section">
                        <div id="blog_posts" class="blog_posts">
                            <div class="section_header">
                                <h2 class="pull-left">Recent Blogs Articles</h2>
                                <div class="clearfix"></div>
                            </div>
                            <?php
                            /*
                             *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
                             *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
                             *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
                             */
                            $query = new WP_Query(array(
                                'post_type' => 'post',
                                'post_status' => 'publish',
                                'posts_per_page' => 2
                            ));

                            while ($query->have_posts()) {
                                $query->the_post();
                                ?>
                                <div class="post">
                                    <h2><?php the_title(); ?></h2>
                                    <p class="m-top-s m-bottom-s"><?php the_excerpt(); ?></p>
                                </div>
                                <?php
                            }
                            wp_reset_query();
                            ?>
                            <p class="text-right"><a href="/press/" class="text-uppercase btn btn_green text_green"><strong>view all</strong></a></p>
                        </div>

                    </div>
                    <hr/>
                    <div class="blog-section">
                        <div id="recent_news" class="recent_news line_bg">
                            <div class="section_header">
                                <h2 class="pull-left">Recent News</h2>
                                <div class="clearfix"></div>
                            </div>

                            <?php
                            /*
                             *  Loop through post objects (assuming this is a multi-select field) ( setup postdata )
                             *  Using this method, you can use all the normal WP functions as the $post object is temporarily initialized within the loop
                             *  Read more: http://codex.wordpress.org/Template_Tags/get_posts#Reset_after_Postlists_with_offset
                             */

                            $post_objects = get_field('select_recent_news_to_show_on_homepage');

                            $query = new WP_Query(array(
                                'post_type' => 'recent_news',
                                'post_status' => 'publish',
                                'posts_per_page' => 3
                            ));

                            while ($query->have_posts()) {
                                $query->the_post();
                                ?>
                                <div class="row post">
                                    <div class="col-lg-4 col-md-4 col-sm-4">
                                        <?php
                                        if (has_post_thumbnail()) {
                                            ?>
                                            <div class="image">
                                                <a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?>>
                                                    <?php
                                                    the_post_thumbnail('thumbnail');
                                                    ?>
                                                </a>
                                            </div>
                                        <?php } else { ?>
                                            <div class="no_image">
                                                <a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?>></a>
                                            </div>
                                        <?php } ?>
                                    </div>
                                    <div class="col-lg-8 col-md-8 col-sm-8">
                                        <div class="recent_news_text">
                                            <h2><a href="<?php echo check_post_external_link(); ?>" <?php echo check_post_link_target(); ?>><?php the_title(); ?></a></h2>
                                            <div class="recent_news_meta">
                                                <div class="categories inline-block">
                                                    <?php
                                                    if (has_category()) {
                                                        ?>
                                                        <ul class="post-categories">
                                                            <li>
                                                                <?php
                                                                $categories = get_the_category();
                                                                $separator = ' ';
                                                                $output = '';
                                                                $page = 'press';
                                                                if (!empty($categories)) {
                                                                    foreach ($categories as $category) {
                                                                        $output .= '<a href="/' . $page . '/#tab' . esc_html($category->slug) . '" alt="' . esc_attr(sprintf(__('View all posts in %s', 'textdomain'), $category->name)) . '">' . esc_html($category->name) . '</a>' . $separator;
                                                                    }
                                                                    echo trim($output, $separator);
                                                                    ?>
                                                                </li>
                                                            </ul>

                                                            <?php
                                                        }
                                                    } else {
                                                        ?>
                                                        <ul class="post-categories">
                                                            <?php $category = 'Recent News'; ?>
                                                            <li>
                                                                <a href="javascript:void(0);" ><?php echo $category ?></a>
                                                            </li>
                                                        </ul>
                                                    <?php }
                                                    ?>
                                                </div>
                                                <span class="inline-block text_green"> - </span>
                                                <div class="date_author inline-block">
                                                    <?php the_time('F j, Y'); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            wp_reset_query();
                            ?>
                            <p class="text-right"><a href="/press/" class="text-uppercase btn btn_green text_green"><strong>view all</strong></a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <!-- /section -->
</main>

<?php get_footer(); ?>

