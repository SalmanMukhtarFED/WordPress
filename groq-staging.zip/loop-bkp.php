
    <?php
// args
    $args = array(
        'numberposts' => 1,
        'post_type' => 'post',
        'meta_key' => 'highlight_post',
        'meta_value' => true
    );

    $the_query = new WP_Query($args);
    ?>
    <?php if ($the_query->have_posts()): ?>
       <div class="higlighted-post">
            <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>
                
                    <div class="row">
                        <div class="col-xl-5 col-lg-5 col-12">
                            <div class="text">
                                <h2 class="main-title-small">Highlighted</h2>
                                <div class="published-date pt-2 pb-3"><span class="date"><?php the_time('F j, Y'); ?></span></div>
                                <h3 class="title">
                                    <?php the_title(); ?>
                                </h3>
                                <div class="pt-3 pb-5">
                                    <?php the_excerpt(); ?>
                                </div>
                                <a class="btn-border" href="<?php the_permalink(); ?>">Read More</a>
                            </div>
                        </div>
                        <div class="col-xl-7 col-lg-7 col-12">
                            <?php the_post_thumbnail(); ?>
                        </div>
                    </div>
                
            <?php endwhile; ?>
        </div>
    <?php endif; ?>

    <?php wp_reset_query();  // Restore global post data stomped by the_post(). ?>
<div class="row">
    <?php if (have_posts()): while (have_posts()) : the_post(); ?>

            <?php /*
              $has_higlighted_post = get_field('highlight_post');
              if ($has_higlighted_post == true) {
              ?>
              <div class="higlighted-post">
              <div class="row">
              <div class="col-xl-5 col-lg-5 col-12">
              <div class="text">
              <h2 class="main-title-small">Highlighted</h2>
              <div class="published-date pt-2 pb-3"><span class="date"><?php the_time('F j, Y'); ?></span></div>
              <h3 class="title">
              <?php the_title(); ?>
              </h3>
              <div class="pt-3 pb-5">
              <?php the_excerpt(); ?>
              </div>
              <a class="btn-border" href="<?php the_permalink(); ?>">Read More</a>
              </div>
              </div>
              <div class="col-xl-7 col-lg-7 col-12">
              <?php the_post_thumbnail(); ?>
              </div>
              </div>
              </div> */ ?>


            <article class="col-xl-4 col-lg-4 col-md-4 col-12">
                <!-- post thumbnail -->
                <?php if (has_post_thumbnail()) : // Check if thumbnail exists  ?>
                    <div class="has-image">
                        <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
                            <?php the_post_thumbnail(); // Declare pixel size you need inside the array ?>

                        </a>
                        <div class="post-tags">
                            <?php the_tags(); ?>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="no-image">
                        <img src="<?php echo get_template_directory_uri() ?>/img/groq_logo.svg "/>
                        <div class="post-tags">
                            <?php the_tags(); ?>
                        </div>
                    </div>
                <?php endif; ?>
                <!-- /post thumbnail -->

                <div class="post-details">
                    <div class="published-date pt-2 pb-2"><span class="date"><?php the_time('F j, Y'); ?></span></div>
                    <h3 class="post-title">
                        <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
                    </h3>
                    <div class="">
                        <?php echo get_excerpt(200); ?>
                    </div>
                    <a class="text-orange read-more" href="<?php the_permalink(); ?>">Read More</a>
                </div>
                <?php edit_post_link(); ?>
            </article>

        <?php endwhile; ?>
    </div>

<?php else: ?>

    <!-- article -->
    <article>
        <h2><?php _e('Sorry, nothing to display.', 'html5blank'); ?></h2>
    </article>
    <!-- /article -->

<?php endif; ?>

