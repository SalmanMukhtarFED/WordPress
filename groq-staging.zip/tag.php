<?php get_header(); ?>

<main role="main">

    <h1 class="page-header">
         <div class="container"><?php
        _e('Tag Archive: ', 'html5blank');
        echo single_tag_title('', false);
        ?></div>
    </h1>
    <section class="posts-wrapper no-p-top">
        <div class="container">
            <div class="back"><a href="/blog/">Back</a>
            </div>
            <?php get_template_part('loop-tag'); ?>

            <?php get_template_part('pagination'); ?>
              <div class="back"><a href="/blog/">Back</a>
            </div>
        </div>

    </section>
    <!-- /section -->
</main>
<?php get_footer(); ?>