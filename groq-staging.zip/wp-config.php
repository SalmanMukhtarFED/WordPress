<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'groq_test' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'Gnc#423ed@' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '>OHEKb)J:7z(/gCO3;iu1<;-i,jq;g#0C5]r@NI8!EvY%&SQ.e (Lu%`n,>>%_tz' );
define( 'SECURE_AUTH_KEY',  'wbV7aR=T0b0% dZ1 mF/uy+&D(i@^l#X%*.XF%VL4?`c`b|2jJ/gG-uFtf_Tt0_{' );
define( 'LOGGED_IN_KEY',    'nzBZ#A V$HwV!JE~x%iCi-4iu:31p/Mav!5]sLXV8e!z%!k,|v)Y  _DaEhD-T1Z' );
define( 'NONCE_KEY',        '7C~.mi<|vU2ps/UOY^xY!729b?7&p;_!f|qNlom}qaE~Y1vCmLB1LHmA7Sb>ymrT' );
define( 'AUTH_SALT',        '(j eL@z~w9,U3J#8u]zm<%|[E4x,j=Qc$x=p?[L,[3Bjvak~FIy~m3$._:03AMq4' );
define( 'SECURE_AUTH_SALT', '&)K++%gV6b+&THj<EmXet_`u8z(`pki3#qD[Jkc}21CRL^3($C%[>~K9X`s@V2$r' );
define( 'LOGGED_IN_SALT',   'q1#1Vp.1Rqjr`3+W ;Wo&pgVrfWQ2; ~a>D^ ?Qmt>0+qE;nR$)ov+=/W;8FA2Zs' );
define( 'NONCE_SALT',       'S5iJ(/Mk^7?y**AuL^&t(`a=1jDW5u1,zQ|J43W_fi_sxoNYaYzDdc;@M;oo3>G9' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );

define('WP_HOME','http://test.groq.com');
define('WP_SITEURL','http://test.groq.com');
