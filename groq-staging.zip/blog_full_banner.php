<?php if (have_posts()): while (have_posts()) : the_post(); ?>
        <?php ?>
        <div class="blog-single">
            <div class="container">
                <div class="banner mb-5 full-width-image">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-12">
                            <div class="featured-image">
                                <?php the_post_thumbnail(); ?>
                            </div>
                        </div>
                        <div class="col-xl-12 col-lg-12 col-12">
                            <div class="text">
                                <div class="row">
                                    <div class="col-md-8">
                                        <h3 class="title">
                                            <?php the_title(); ?>
                                        </h3>
                                        <div class="author text-orange">
                                            <?php _e('By', 'html5blank'); ?> <?php the_author_posts_link(); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="published-date"><span class="date"><?php the_time('F j, Y'); ?></span></div>
                                        <div class="post-tags">
                                            <?php the_tags(__('Tags: ', 'html5blank'), ', ', '<br>'); // Separated by commas with a line break at the end ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                $has_abstract = get_field('abstract');
                $download_link = get_field('whitepaper_download_link');
                $requires_optin = get_field('requires_opt_in');
                $random_number = mt_rand(1000, 10000);
                if ($requires_optin != '') {
                    ?>
                    <div class="single-content abstract">
                        <div class="row">
                            <div class="col-md-12">
                                <h4>Abstract</h4>
                                <?php the_excerpt(); ?>
                                <?php //if ($requires_optin == 'no') { ?>
                                <?php if ($requires_optin == 'no' || Check_if_post_subscribed()) { ?>
                                    <?php the_content(); ?>
                                <?php } else { ?>
                                    <hr/>
                                    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
                                    <div id="robly_embed_signup">
                                        <form action="https://list.robly.com/subscribe/post" method="post" id="robly_embedded_subscribe_form" name="robly_embedded_subscribe_form" class="validate" novalidate="">

                                            <input type="hidden" name="a" value="8df7aa5ce4387401554eefca94003bb0" />
                                            <input type="hidden" name="sub_lists[]" value="367647" />
                                            <input type="hidden" name="c_url" value="<?php echo home_url($wp->request) ?>/?success" />
                                            <h3 class="m-bottom text-orange text-center">Request Access to this article</h3>
                                            <h5 class="text-orange text-center no-margin">Your will receive an email from us with a download link to the entire article. </h5>
                                            <h5 class="text-orange text-center">Signing up to our mailing list is mandatory, but you can remove yourself at any time.</h5>
                                            <div id="contant_form">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <input type="text" data-validation="required" name="FNAME" id="DATA1" placeholder="First Name" class="required form-control" value="">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <input type="text" data-validation="required" name="LNAME" id="DATA2" placeholder="Last Name" class="required form-control" value="">
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <input type="email" data-validation-error-msg="Invalid email address." data-validation="email" name="EMAIL" id="DATA0" placeholder="Email" class="required form-control" autocapitalize="off" autocorrect="off" value="">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="DATA3" id="DATA3" class="form-control" value="" placeholder="Company">
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" name="DATA4" id="DATA4" placeholder="Title/Role" class="form-control" value="">
                                                </div>
                                                <div class="form-group">
                                                    <textarea name="DATA5" id="DATA5" rows="5" placeholder="Describe Your interest in Groq (Optional)" class="form-control" value=""></textarea>
                                                </div>
                                                <div class="form-group">
                                                    <input type="checkbox" data-validation="required" data-validation-error-msg="Please check the box to opt-in."  class="required" name="accept_gdpr" id="accept_robly_gdpr" value="367647" name="sub_lists[]"> <span class="check-text">I would like to receive product updates and newsletters from Groq.</span>
                                                </div>
                                                <!-- passing the current url where use has subscribed -->
                                                <div class="form-group">
                                                    <input type="hidden" name="DATA6" id="DATA6" value="<?php echo home_url($wp->request) ?>" >
                                                </div>
                                                <div class="form-group">
                                                    <input type="hidden" name="DATA7" id="DATA7" value="<?php echo $random_number; ?>" >
                                                </div>
                                                <input type="submit" id="Submit" disabled value="Subscribe" name="subscribe" class="button  g-recaptcha" data-sitekey="6Ld9XlUUAAAAABcR5houwBXwlA_3STKsG2SzYCVw" data-callback="robly_recaptcha_callback"/>
                                            </div>
                                        </form>
                                    </div>
                                    <h3 class="d-none thankyou-message text-center text-orange">Thank your for your request. You should be <br/> receiving an email momentarily with a link to<br/> download this article.</h3>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                <?php } else {
                    ?>
                    <div class="single-content">
                        <div class="row">
                            <div class="col-md-9">
                                <?php the_content(); ?>
                                <hr/>
                            </div>
                            <div class="col-md-3">
                                <div class="social-share">
                                    <h3>Share</h3>
                                    <?php echo do_shortcode('[DISPLAY_ULTIMATE_SOCIAL_ICONS]'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>

    <?php endwhile; ?>

<?php else: ?>

    <!-- article -->
    <article>

        <h1><?php _e('Sorry, nothing to display.', 'html5blank'); ?></h1>

    </article>
    <!-- /article -->

<?php endif; ?>
