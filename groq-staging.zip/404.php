<?php get_header(); ?>

<main role="main">
    <!-- section -->
    <section>
        <div class="container">

            <!-- article -->
            <article id="post-404" class="page-not-found">
                <h1>Error</h1>
                
                <h2>404</h2>
                <h3> <?php _e('Page not found', 'html5blank'); ?></h3>

                <div class="back-to-home text-center">
                    <a class="btn-border mr-auto ml-auto mt-5" href="<?php echo home_url(); ?>"><?php _e('Back to Home', 'html5blank'); ?></a>
                </div>


            </article>
            <!-- /article -->
        </div>

    </section>
    <!-- /section -->
</main>

<?php get_footer(); ?>
