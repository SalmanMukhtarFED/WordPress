<?php get_header(); ?>

<main role="main">
    <!-- section -->
    <section class="no-p-top">
        <?php
        $article_type = get_field('article_type');
        $banner_layout = get_field('article_banner_layout');
        if ($article_type == 'whitepaper' && $banner_layout == 'full') {
            get_template_part('whitepaper');
        } else if ($article_type == 'whitepaper' && $banner_layout == 'right') {
            get_template_part('whitepaper-right-image');
        } else if ($article_type == 'blog' && $banner_layout == 'full') {
            get_template_part('blog_full_banner');
        } else {
            get_template_part('blog-right-image');
        }
        ?>
        <div class="container">
            <div class="back">
                <a href="/blog/">Back</a>
            </div>
        </div>
    </section>


    <!-- /section -->
</main>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>

    function robly_recaptcha_callback(token) {

        var email = $("#DATA0").val();
        if (!is_valid_email_address(email)) {
            alert("Please enter a valid email address.");
            return false;
        }
        if (!$("#DATA0").val()) {
            alert("Please fill in all required fields!");
            return false
        }


        if (!$('#accept_robly_gdpr').is(':checked')) {
            alert('Please accept terms of use.');
            return false;
        }

        var f = $("#robly_embedded_subscribe_form");
        f.submit();
    }


    function is_valid_email_address(emailAddress) {
        var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);
        return pattern.test(emailAddress);
    }

//        jQuery(document).ready(function () {
//            jQuery('input.required').blur(function () {
//                jQuery(this).each(function () {
//                    var curr_val = jQuery(this).val();
//                    if (curr_val != '') {
//                        jQuery('#Submit').removeAttr('disabled');
//                    }
//                });
//            });
//        });

    jQuery(document).ready(function () {
        var checkbox = jQuery('#accept_robly_gdpr:checked').length;

        jQuery('#DATA0, #DATA1, #DATA2').blur(function () {
            if (allFilled())
                jQuery('#Submit').removeAttr('disabled');

        });
        
        

    });
    function allFilled() {
        var filled = true;
        jQuery('.required').each(function () {
            if (jQuery(this).val() === '')
                filled = false;
        });
        return filled;
    }

</script>
<?php get_footer(); ?>
