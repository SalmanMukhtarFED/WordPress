<?php /* Template Name: Landing Page Template */ get_header(); ?>

<main role="main" class="landing-page-template">
    <?php $featured_img_url = get_the_post_thumbnail_url($post->ID, 'full'); ?> 
    <section class="banner" style="background-image: url(<?php echo $featured_img_url ?>)">
        <div class="container">
            <div class="banner-text">
                <h1><?php the_field('header_main_heading') ?></h1>
                <h3><?php the_field('header_sub_heading') ?></h3> 
                <a href="javascript:void(0);" class="down-arrow down-scroll">
                    <span>
                        <img src="<?php echo get_template_directory_uri(); ?>/img/DoubleDownArrow.png">
                    </span>
                </a>
            </div>
        </div>
    </section>
    <section class="scroll-section landing-content">
        <div class="container">
            <div class="text">
                <h3><?php the_field('landing_title'); ?></h3>
                <?php the_field('landing_content'); ?>
            </div>
        </div>
    </section>
    <section class="tabs">
        <div class="container">
            <h3 class="text-orange text-center m-bottom"><?php the_field('carousel_section_header') ?></h3>
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <?php
                if (have_rows('carousel_content')):
                    $count = 1;
                    while (have_rows('carousel_content')) : the_row();
                        if ($count == 1) {
                            $class = "active";
                            $selected = "true";
                        } else {
                            $class = "";
                            $selected = "false";
                        }
                        ?>
                        <li class="nav-item"><a class="nav-link <?php echo $class; ?>"  aria-selected="<?php echo $selected; ?>" id="tab-<?php echo $count; ?>" data-toggle="tab" href="#tab<?php echo $count; ?>"><?php the_sub_field('item_name'); ?></a></li>
                        <?php
                        $count++;
                    endwhile;
                else :
                endif;
                ?>
            </ul>

            <div class="tab-content">
                <?php
                if (have_rows('carousel_content')):
                    $count = 1;
                    while (have_rows('carousel_content')) : the_row();
                        if ($count == 1) {
                            $class = "show active";
                        } else {
                            $class = "";
                        }
                        ?>
                        <div id="tab<?php echo $count; ?>" role="tabpanel" class="tab-pane fade <?php echo $class; ?>">
                            <div class="row">
                                <?php if (get_sub_field('item_image') != '') { ?>
                                    <div class="col-lg-4 col-xl-4">
                                        <img src="<?php the_sub_field('item_image'); ?>" alt="<?php the_sub_field('item_heading'); ?>"/>
                                    </div>  
                                <?php }
                                ?>
                                <?php
                                if (get_sub_field('item_image') != '') {
                                    $class = "col-lg-8 col-xl-8";
                                } else {
                                    $class = "col-lg-12 col-xl-12";
                                }
                                ?>
                                <div class="<?php echo $class; ?>">
                                    <h4><?php the_sub_field('item_heading'); ?></h4>
                                    <div class="text">
                                        <?php the_sub_field('item_content'); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                        $count++;
                    endwhile;
                else :
                endif;
                ?>
            </div>
        </div>
    </section>
    <section class="newsletter-subscription">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                <h3>Sign up for Groq's newsletters to stay in the know:</h3>
                <a href="/contact/">Subscribe</a>
            </div>
        </div>
    </section>
    <section class="text-with-image">
        <?php
        if (have_rows('image_with_text')):
            while (have_rows('image_with_text')) : the_row();
                $image_alignment = get_sub_field('image_alignment');
                if ($image_alignment == 'left') {
                    $sectionclass = '';
                    $flexclass = '';
                } else {
                    $sectionclass = 'reverse';
                    $flexclass = 'flex-row-reverse';
                }
                ?>
                <section class="<?php echo $sectionclass; ?>">
                    <div class="container">
                        <div class="d-flex align-items-center <?php echo $flexclass; ?>">
                            <div class="image">
                                <img src="<?php the_sub_field('image'); ?>"/>
                            </div>
                            <div class="text">
                                <h3><?php the_sub_field('heading'); ?></h3>
                                <?php the_sub_field('content'); ?>
                            </div>
                        </div>
                    </div>
                </section>
                <?php
            endwhile;
        else :
        endif;
        ?>
    </section>
    <section class="related-articles">
        <div class="container">
            <h3>Related Articles</h3>

            <?php
            $post_objects = get_field('select_related_articles');

            if ($post_objects):
                ?>
                <div id="related_articles" class="owl-carousel owl-theme">
                    <?php foreach ($post_objects as $post): setup_postdata($post); ?>
                        <div class="item card">
                            <?php
                            if (has_post_thumbnail()) {
                                ?>
                                <div class="image">
                                    <?php
                                        the_post_thumbnail('thumbnail');
                                        ?>
                                   <?php if(has_tag()) {?> 
                                    <div class="post-tags">
                                        <?php the_tags(); ?>
                                    </div>
                                   <?php } ?>
                                </div>
                            <?php } else { ?>
                                <div class="no_image">
                                    <img src="<?php echo get_template_directory_uri() ?>/img/groq_logo.svg "/>
                                    <?php if(has_tag()) {?> 
                                    <div class="post-tags">
                                        <?php the_tags(); ?>
                                    </div>
                                   <?php } ?>
                                </div>
                            <?php } ?>
                            <div class="card-body">
                                <div class="published-date pt-2 pb-2"><span class="date"><?php the_time('F j, Y'); ?></span></div>
                                <h5 class="card-title"><?php echo get_the_title($post->ID); ?></h5>
                                <a class="text-orange read-more" href="<?php the_permalink($post->ID); ?>">Read More</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php wp_reset_postdata(); // IMPORTANT - reset the $post object so the rest of the page works correctly ?>

            <?php endif;
            ?>
        </div>
    </section>
</main>


<script>
    jQuery(document).ready(function () {
        jQuery('#related_articles').owlCarousel({
            margin: 10,
            nav: false,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 2
                },
                1000: {
                    items: 3
                }
            }
        });
    });
</script>
<?php get_footer(); ?>
