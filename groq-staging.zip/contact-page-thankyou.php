<?php /* Template Name: Contact Page Thankyou Template */ get_header(); ?>

<main role="main" class="contact-page">
    <section class="contact">
        <div class="row no-margin">
            <div class="col-md-12 col-lg-3">
                <div class="contact-text">
                    
                    <p><?php the_field('header_main_heading'); ?></p>
                    <p><?php the_field('header_sub_heading'); ?></p>
                </div>
            </div>
            <div class="col-md-10 col-lg-7 col-xl-6 offset-md-1 offset-lg-2">
                <h3><?php the_title(); ?> <?php the_content(); ?></h3>
            </div>
        </div>
    </section>
</main>
<?php get_footer(); ?>
