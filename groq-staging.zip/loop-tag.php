<?php $current_tag = single_tag_title( "", false ); ?>
<div class="row">
    <div class="container">
        <?php echo do_shortcode('[ajax_load_more container_type="div" tag="'.$current_tag.'" posts_per_page="6" transition_container_classes="row" post_type="post"  button_label="See More"]'); ?>
    </div>
</div>

<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

