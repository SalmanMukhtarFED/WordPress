(function ($, root, undefined) {

    $(function () {

        'use strict';

        var header_height = $('.header').height();




        $(window).scroll(function (event) {
            var scroll = $(window).scrollTop();

            if (scroll > header_height) {
                $('.navbar').addClass('sticky');
                $('main').addClass('addpadding');
            }
            else {
                $('.navbar').removeClass('sticky');
                $('main').removeClass('addpadding');
            }

        });

        jQuery(document).ready(function () {
            AOS.init({
                once: true,
                duration: 1200,
            })


            $('.coworker-slider').owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                items: 1,
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 1
                    },
                    1000: {
                        items: 1
                    }
                }
            })
            jQuery(".down-scroll").click(function () {
                //$(this).animate(function(){
                var top_position = jQuery(".scroll-section").offset().top;
                var top_position = top_position - 50;
                jQuery('html, body').animate({
                    scrollTop: top_position
                }, 1000);
            });

            $('.wpcf7-submit').click(function () {
                if ($("input[type='checkbox']:checked").length == 1) {
                    console.log("in if")
                    var email = jQuery("#email_address").val();
                    robly_recaptcha_callback('6Ld9XlUUAAAAABcR5houwBXwlA_3STKsG2SzYCVw', email);
                }


            });
            document.addEventListener('wpcf7mailsent', function (event) {
                $('#contant_form').hide();
            }, false);



        });

    });

})(jQuery, this);

function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ')
            c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0)
            return c.substring(nameEQ.length, c.length);
    }
    return null;
}




