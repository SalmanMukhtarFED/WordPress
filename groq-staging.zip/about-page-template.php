<?php /* Template Name: About Page Template */ get_header(); ?>

<main role="main" class="about-page">
    <!-- section -->
    <section class="scroll-section section-about">
        <div class="container">
            <div class="row align-center">
                <div class="col-md-6" data-aos="fade-left">
                    <img class="" src="<?php the_field('about_content_image'); ?>" alt=""/>
                </div>
                <div class="col-md-6">
                    <div class="padder-left">
                        <h3><?php the_field('about_content_title'); ?></h3>
                        <div class="">
                            <?php the_field('about_content'); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="leadership-section">
        <div class="container">
            <h1 class="text-orange"><?php the_field('leadership_section_title') ?></h1>
            <?php
            $args = array(
                'post_type' => 'leadership',
                'post_status' => 'publish',
                'order' => 'ASC',
            );

            $leadership = new WP_Query($args);
            if ($leadership->have_posts()) :
                ?>
                <?php
                $count = 1;
                while ($leadership->have_posts()) :
                    $leadership->the_post();
                    if ($count % 2 == 0) {
                        $class = 'row-reverse';
                        $animation = 'fade-left';
                    } else {
                        $class = "";
                        $animation = 'fade-right';
                    }
                    ?>
                    <div class="row <?php echo $class ?>">
                        <div class="col-md-4">
                            <div class="leadership-image">
                                <?php
                                $thumbnail = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), "large");
                                ?>
                               <img class="" data-aos="<?php echo $animation; ?>" src="<?php echo $thumbnail[0]; ?>"/>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="padder-left">
                                <h3><?php the_title(); ?> :: <span class="designation"><?php the_field('designation') ?></span></h3>
                                <div class="leadership-content">
                                    <?php the_content(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                    $count = $count + 1;
                endwhile;
                wp_reset_postdata();
                ?>
                <?php
            endif;
            ?>
        </div>
    </section>
    <section class="cta">
        <div class="container">
            <h3 class="text-center">Want to meet some of your future coworkers?</h3>
            <div class="text-center">
                <h3><a href="/careers/" class="text-orange">Click Here</a></h3>
            </div>
        </div>
    </section>

</main>


<?php get_footer(); ?>
