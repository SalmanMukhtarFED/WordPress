<?php get_header(); ?>

<main role="main">
    <section class="posts-wrapper no-p-top">
        <h1 class="page-header">
            <div class="container">
                <?php
                echo sprintf(__('Search Results for ', 'html5blank'), $wp_query->found_posts);
                echo get_search_query();
                ?>
            </div>
        </h1>
        <div class="container">
            <div class="back"><a href="/blog/">Back</a>
            </div>
            <?php get_template_part('loop-search'); ?>


            <?php get_template_part('pagination'); ?>
            <div class="back"><a href="/blog/">Back</a>
            </div>
        </div>

    </section>
    <!-- /section -->
</main>
<?php get_footer(); ?>