<!doctype html>
<html <?php language_attributes(); ?> class="no-js">
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <title><?php wp_title(''); ?><?php
            if (wp_title('', false)) {
                echo ' :';
            }
            ?> <?php bloginfo('name'); ?></title>

        <link href="//www.google-analytics.com" rel="dns-prefetch">
        <link href="<?php echo get_template_directory_uri(); ?>/favicon.ico" rel="shortcut icon">
        <link href="<?php echo get_template_directory_uri(); ?>/favicon.ico" rel="apple-touch-icon-precomposed">

        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="<?php bloginfo('description'); ?>">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
        <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/aos.css">
        <link rel="stylesheet" media="all" type="text/css" href="//stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"/>
        <link rel="stylesheet" media="all" type="text/css" href="//stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
        <link rel="stylesheet" media="all" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"/>
        <link rel="stylesheet" media="all" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css"/>

        <?php
        $cookie_consent = $_COOKIE['viewed_cookie_policy'];
        if ($cookie_consent == 'yes') {
            ?>
            <!-- Global site tag (gtag.js) - Google Analytics -->
            <script async src="https://www.googletagmanager.com/gtag/js?id=UA-138141038-1"></script>
            <script>
                window.dataLayer = window.dataLayer || [];
                function gtag() {
                    dataLayer.push(arguments);
                }
                gtag('js', new Date());

                gtag('config', 'UA-138141038-1');
            </script>
        <?php } else { ?> 

        <?php } ?>






        <?php wp_head(); ?>

        <script>
            // conditionizr.com
            // configure environment tests
            conditionizr.config({
                assets: '<?php echo get_template_directory_uri(); ?>',
                tests: {}
            });
        </script>
        <script src="//stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        <script src="<?php echo get_template_directory_uri(); ?>/js/aos.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    </head>
    <body <?php body_class(); ?>>
        <!-- wrapper -->
        <div class="wrapper">
            <?php
            $page_title = get_the_title();
            $current_page = sanitize_post($GLOBALS['wp_the_query']->get_queried_object());
            $slug = $current_page->post_name;
            ?>
            <?php
            if (is_front_page()) {
                ?>
                <!-- header -->
                <header class="header homepage_header">
                    <!-- logo -->
                    <div class="header-content">
                        <div class="logo">
                            <a href="<?php echo home_url(); ?>">
                                <!-- svg logo - toddmotto.com/mastering-svg-use-for-a-retina-web-fallbacks-with-png-script -->
                                <img src="<?php echo get_template_directory_uri(); ?>/img/groq_logo_textured_white-1.svg" alt="Logo" class="logo-img">
                            </a>
                        </div>
                        <h1 class="text-orange"><?php the_field('header_sub_heading', $page->ID); ?></h1> 
                    </div>
                    <a href="javascript:void(0);" class="down-arrow down-scroll">
                        <span>Discover More</span>
                        <span>
                            <img src="<?php echo get_template_directory_uri(); ?>/img/DoubleDownArrow.png"/>
                        </span>
                    </a>
                    <!-- /logo -->

                </header>
            <?php } elseif ($page_title == "About") { ?>
                <!-- header -->
                <header class="header about_header">
                    <div class="container">
                        <div class="logo-small">
                            <a href="<?php echo home_url(); ?>"><img src="<?php echo get_template_directory_uri(); ?>/img/groq_logo_medium-white.png" alt="Groq"/></a>
                        </div>
                    </div>
                    <!-- logo -->
                    <div class="header-content">
                        <h2><?php the_field('header_main_heading', $page->ID); ?></h2>
                        <h1 class=""><?php the_field('header_sub_heading', $page->ID); ?></h1> 
                        <a href="javascript:void(0);" class="down-arrow down-scroll">
                            <span>
                                <img src="<?php echo get_template_directory_uri(); ?>/img/DoubleDownArrow.png"/>
                            </span>
                        </a>
                    </div>

                    <!-- /logo -->

                </header>
            <?php } elseif ($page_title == "Careers") { ?>
                <!-- header -->
                <header class="header careers_header">
                    <div class="container">
                        <div class="logo-small">
                            <a href="<?php echo home_url(); ?>"><img src="<?php echo get_template_directory_uri(); ?>/img/groq_logo_medium-white.png" alt="Groq"/></a>
                        </div>
                    </div>
                    <!-- logo -->
                    <div class="header-content">
                        <h2><?php the_field('header_main_heading', $page->ID); ?></h2>
                        <h1 class=""><?php the_field('header_sub_heading', $page->ID); ?></h1> 
                        <a href="javascript:void(0);" class="down-arrow down-scroll">
                            <span>
                                <img src="<?php echo get_template_directory_uri(); ?>/img/DoubleDownArrow.png"/>
                            </span>
                        </a>
                    </div>

                    <!-- /logo -->

                </header>
            <?php } elseif ($slug == "blog") { ?>
                <header class="header blog-header careers_header">
                    <div class="container">
                        <div class="logo-small">
                            <a href="<?php echo home_url(); ?>"><img src="<?php echo get_template_directory_uri(); ?>/img/groq_logo_medium-white.png" alt="Groq"/></a>
                        </div>
                    </div>
                    <div class="header-content">
                        <h2><?php the_field('header_main_heading', get_option('page_for_posts')) ?></h1>
                        <h1><?php the_field('header_sub_heading', get_option('page_for_posts')) ?></h3> 
                        <a href="javascript:void(0);" class="down-arrow down-scroll">
                            <span>
                                <img src="<?php echo get_template_directory_uri(); ?>/img/DoubleDownArrow.png">
                            </span>
                        </a>
                    </div>
                </header>

            <?php } ?>



            <!-- /header -->
            <!-- nav -->
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container">
                    <a class="navbar-brand" href="<?php echo home_url(); ?>">
                        <img src="<?php echo get_template_directory_uri(); ?>/img/groq_logo.svg"/>
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <?php html5blank_nav(); ?>
                        <div class="social-menu-header">
                            <?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('widget-area-2'))  ?>
                        </div>
                    </div>

                </div>
            </nav>
