<?php  get_header(); ?>

<main role="main" class="contact-page">
    <section class="contact">

        <div class="row no-margin">
            <div class="col-md-12 col-lg-3">
                <div class="contact-text">
                    <h1><?php the_title(); ?></h1>
                    <p><?php the_field('header_main_heading'); ?></p>
                    <p><?php the_field('header_sub_heading'); ?></p>
                </div>
            </div>
            <div class="col-md-10 col-lg-7 col-xl-6 offset-md-1 offset-lg-2">
               
                <?php
                echo do_shortcode('[contact-form-7 id="154" title="Contact form 1"]');
                ?>
            </div>
        </div>
    </section>
    <!-- Begin Robly Signup Form -->
    <div id="robly_embed_signup" style="visibility: hidden;">
        <form action="https://list.robly.com/subscribe/post" method="post" id="robly_embedded_subscribe_form" name="robly_embedded_subscribe_form" class="validate" target="_blank"  novalidate="">
            <input type="hidden" name="a" value="b97a67356601ad273ad2c52842db76b0" />

            <h2>Subscribe to our mailing list</h2>
            <div class="robly_field_group"><label>Email Address:<span class="asterisk">*</span></label><input type="text" name="EMAIL" id="DATA0" class="required" autocapitalize="off" autocorrect="off" value=""></div>
            <div class="clearfix"></div>

            <div class="clearfix"></div>
            <div class="clear">
                <input type="submit" value="Subscribe" name="subscribe" class="button g-recaptcha" data-sitekey="6Ld9XlUUAAAAABcR5houwBXwlA_3STKsG2SzYCVw" data-callback="robly_recaptcha_callback"/>
            </div>
        </form>
    </div>
</main>
<script>

    function robly_recaptcha_callback(token, email) {
        var newsletter_email = jQuery("#DATA0").val(email);
        //console.log('function called');
        console.log('Newsletter Email', email);
//        if (!is_valid_email_address(newsletter_email)) {
//            alert("Please enter a valid email address.");
//            return false;
//        }
//        if (!jQuery("#DATA0").val()) {
//            alert("Please fill in all required fields!");
//            return false
//        }



        var f = jQuery("#robly_embedded_subscribe_form");
        f.submit();
    }
//    function is_valid_email_address(emailAddress) {
//        var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);
//        return pattern.test(emailAddress);
//    }

</script>




<?php get_footer(); ?>
