<?php /* Template Name: Front Page Template */ get_header(); ?>

<main role="main" class="home-page">
    <!-- section -->
    <section class="scroll-section section-about">
        <div class="container">
            <div class="row">
                <div class="col-md-6" data-aos="fade-right">
                    <img class="" src="<?php the_field('about_section_image'); ?>" alt=""/>
                </div>
                <div class="col-md-6">
                    <div class="padder-left equal-space-vertical">
                        <h2 class="main-title-small"><?php the_field('about_section_heading'); ?></h2>
                        <h3><?php the_field('about_section_sub_heading'); ?></h3>
                        <div class="">
                            <?php the_field('about_section_content'); ?>
                        </div>
                        <div class="learn-more">
                            <a class="btn-border" href="<?php the_field('about_section_link') ?>"><?php echo $link_text ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php
    $args = array(
        'post_type' => 'html5-blank',
        'post_status' => 'publish',
        'order' => 'ASC',
    );

    $performace = new WP_Query($args);
    if ($performace->have_posts()) :
        ?>
        <?php
        $count = 1;
        while ($performace->have_posts()) :
            $performace->the_post();
            ?>
            <section class="performance performance-<?php echo $count ?>">
                <div class="container">
                    <div class="column text">
                        <h2 class="main-title-small">Performance</h2>
                        <h3><?php the_title(); ?></h3>
                        <div class="performance-content">
                            <?php the_content(); ?>
                        </div>
                        <?php
                        $is_download = get_field('show_download_button');
                        if ($is_download == "yes") {
                            ?>
                            <div class="download-performance">
                                <a href="<?php the_field('performance_document'); ?>" class="btn-border">Download</a>
                            </div>
        <?php } ?>
                    </div>
                    <div class="column image">
                        <div class="performance-image">
                            <?php
                            $thumbnail = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), "large");
                            //echo $thumbnail[0]; 

                            if ($count % 2 == 0) {
                                $animation = 'fade-left';
                            } else {
                                $animation = "fade-right";
                            }
                            ?>

                            <img class="" data-aos="<?php echo $animation ?>" src="<?php echo $thumbnail[0]; ?>"/>

                            <?php
                            if ($count == 2 || $count == 3) {
                                ?>   
                                <div class="competition-bar">
                                    <div class="competition-fill"></div>
                                </div>
                                <div class="groq-bar">
                                    <div class="groq-fill"></div>
                                </div>
        <?php } ?>
                        </div>
                    </div>
                </div>
            </section>
            <?php
            $count++;
        endwhile;
        wp_reset_postdata();
        ?>
        <?php
    endif;
    ?>

    <section class="careers">
        <div class="column career-image" data-aos="fade-top" style="background-image: url(<?php the_field('career_section_image'); ?>)"></div>
        <div class="column">
            <div class="padder-left">
                <h2 class="main-title-small"><?php the_field('career_section_heading'); ?></h2>
                <h3><?php the_field('career_section_sub_heading'); ?></h3>

                <div class="learn-more">
                    <a class="btn-border" href="<?php the_field('career_section_link') ?>"><?php the_field('career_button_text'); ?></a>
                </div>
            </div>
        </div>
    </section>

</main>
<script>
    jQuery(document).ready(function () {
        var performance2_offset = jQuery('.performance-2').offset().top;
        var performance3_offset = jQuery('.performance-3').offset().top;

        jQuery(window).scroll(function (event) {
            var scroll2 = jQuery(window).scrollTop();
            var scroll2 = scroll2 + 100;
            //console.log(scroll2)
            if (scroll2 >= performance2_offset) {
                jQuery('.performance-2 .competition-bar').animate({
                    height: '60px'
                }, 1000, function () {
                    // Animation complete.
                });
                jQuery('.performance-2 .groq-bar').animate({
                    height: '280px'
                }, 1000, function () {
                    // Animation complete.
                });
            }
            if (scroll2 >= performance3_offset) {
                jQuery('.performance-3 .competition-bar').animate({
                    height: '75px'
                }, 1000, function () {
                    // Animation complete.
                });
                jQuery('.performance-3 .groq-bar').animate({
                    height: '280px'
                }, 1000, function () {
                    // Animation complete.
                });
            }
        });
    });
</script>


<?php get_footer(); ?>
