			<!-- footer -->
			<footer class="footer" role="contentinfo">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-8">
                                        
                                        <?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('widget-area-1')) ?>
                                    </div>
                                    <div class="col-md-4">
                                        <?php if(!function_exists('dynamic_sidebar') || !dynamic_sidebar('widget-area-2')) ?>
                                    </div>
                                </div>
                            </div>

			</footer>
			<!-- /footer -->

		</div>
		<!-- /wrapper -->

		<?php wp_footer(); ?>

		

	</body>
</html>
