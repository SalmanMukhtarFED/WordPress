<?php /* Template Name: Contact Page Template */ get_header(); ?>

<main role="main" class="contact-page">
    <section class="contact">

        <div class="row no-margin">
            <div class="col-md-12 col-lg-4">
                <div class="contact-text">

                    <h1><?php the_title(); ?></h1>
                    <p><?php the_field('header_main_heading'); ?></p>
                    <p><?php the_field('header_sub_heading'); ?></p>
                </div>
            </div>
            <div class="col-md-10 col-lg-7 col-xl-6 offset-md-1 offset-lg-1">
                <div id="robly_embed_signup">
                    <form action="https://list.robly.com/subscribe/post" method="post" id="robly_embedded_subscribe_form" name="robly_embedded_subscribe_form" class="validate" novalidate="">
                        <input type="hidden" name="a" value="714d4a1cfbf082baa4b9f980ec609362" />
                        <input type="hidden" name="sub_lists[]" value="355149" />
                        <input type="hidden" name="c_url" value="<?php echo home_url(); ?>/contact?success" />
                        <h3 class="m-bottom">Interested in the latest from Groq? Sign-up and be the first to know!</h3>
                        <div id="contant_form">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="text" data-validation="required" name="FNAME" id="DATA1" placeholder="First Name" class="required form-control" value="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="text" data-validation="required" name="LNAME" id="DATA2" placeholder="Last Name" class="required form-control" value="">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <input type="email" data-validation-error-msg="Invalid email address." data-validation="email" name="EMAIL" id="DATA0" placeholder="Email" class="required form-control" autocapitalize="off" autocorrect="off" value="">
                            </div>
                            <div class="form-group">
                                <input type="text" name="DATA3" id="DATA3" class="form-control" value="" placeholder="Company">
                            </div>
                            <div class="form-group">
                                <input type="text" name="DATA4" id="DATA4" placeholder="Title/Role" class="form-control" value="">
                            </div>
                            <div class="form-group">
                                <textarea name="DATA5" id="DATA5" rows="5" placeholder="Describe Your interest in Groq (Optional)" class="form-control" value=""></textarea>
                            </div>
                            <div class="form-group">
                                <input type="checkbox" data-validation="required" data-validation-error-msg="Please check the box to opt-in."  class="required" name="accept_gdpr" id="accept_robly_gdpr"/> <span class="check-text">I would like to receive product updates and newsletters from Groq.</span>
                            </div>
                            <input type="submit" id="Submit" disabled value="Submit" name="subscribe" class="button  g-recaptcha" data-sitekey="6Ld9XlUUAAAAABcR5houwBXwlA_3STKsG2SzYCVw" data-callback="robly_recaptcha_callback"/>
                        </div>
                    </form>
                </div>
                <h3 class="d-none thankyou-message"><?php the_field('form_thank_you_message'); ?></h3>
            </div>
        </div>
    </section>

    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
    <script>
        $.validate({
            form: '#robly_embedded_subscribe_form',
            modules: 'toggleDisabled',
            disabledFormFilter: 'form.toggle-disabled'
        });
    </script>
    <script>

        function robly_recaptcha_callback(token) {

            var email = $("#DATA0").val();
            if (!is_valid_email_address(email)) {
                alert("Please enter a valid email address.");
                return false;
            }
            if (!$("#DATA0").val()) {
                alert("Please fill in all required fields!");
                return false
            }


            if (!$('#accept_robly_gdpr').is(':checked')) {
                alert('Please accept terms of use.');
                return false;
            }

            var f = $("#robly_embedded_subscribe_form");
            f.submit();
        }


        function is_valid_email_address(emailAddress) {
            var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);
            return pattern.test(emailAddress);
        }

//        jQuery(document).ready(function () {
//            jQuery('input.required').blur(function () {
//                jQuery(this).each(function () {
//                    var curr_val = jQuery(this).val();
//                    if (curr_val != '') {
//                        jQuery('#Submit').removeAttr('disabled');
//                    }
//                });
//            });
//        });

        jQuery(document).ready(function () {
            var checkbox = jQuery('#accept_robly_gdpr:checked').length;

            jQuery('#DATA0, #DATA1, #DATA2').blur(function () {
                if (allFilled())
                    jQuery('#Submit').removeAttr('disabled');

            });

        });
        function allFilled() {
            var filled = true;
            jQuery('.required').each(function () {
                if (jQuery(this).val() == '')
                    filled = false;
            });
            return filled;
        }

        if (window.location.href.indexOf('?success') > 0) {
            jQuery('#robly_embed_signup').addClass('d-none');
            jQuery('h3.d-none').removeClass('d-none');
        }

    </script>


</main>




<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<?php get_footer(); ?>
