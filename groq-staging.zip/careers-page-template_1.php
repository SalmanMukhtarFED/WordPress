<?php /* Template Name: Careers Page Template */ get_header(); ?>

<main role="main" class="careers-page">
    <!-- section -->
    <section class="scroll-section future-coworkers">
        <div class="container">
            <div class="column">
                <div class="content">
                    <h3><?php the_field('co_workers_heading'); ?></h3>
                    <p><?php the_field('co_workers_content'); ?></p>
                </div>
                <div class="coworker-details d-none-mobile">
                    <div class="tab-content" id="myTabContent">
                        <?php
                        $args = array(
                            'post_type' => 'future_coworkers',
                            'post_status' => 'publish',
                            'order' => 'ASC',
                            'posts_per_page' => 3
                        );
                        $future_coworkers = new WP_Query($args);
                        $count_posts = $future_coworkers->found_posts;
                        if ($future_coworkers->have_posts()) :
                            ?>
                            <?php
                            $count = 1;
                            while ($future_coworkers->have_posts()) :
                                if ($count == 1) {
                                    $class = 'active show';
                                } else {
                                    $class = "";
                                }
                                $future_coworkers->the_post();
                                ?>
                                <div class="tab-pane fade <?php echo $class; ?>" id="tab-<?php echo $count; ?>" role="tabpanel" aria-labelledby="home-tab-<?php echo $count; ?>">
                                    <h3><?php the_title(); ?> :: <span class="designation"><?php the_field('co_designation') ?></span></h3>
                                    <?php the_content(); ?>
                                </div>
                                <?php
                                $count = $count + 1;
                            endwhile;
                            wp_reset_postdata();
                            ?>
                            <?php
                        endif;
                        ?>
                    </div>
                </div>
            </div>
            <div class="column d-none-mobile">
                <div class="nav nav-tabs coworker-tabs">
                    <?php
                    $args = array(
                        'post_type' => 'future_coworkers',
                        'post_status' => 'publish',
                        'order' => 'ASC',
                        'posts_per_page' => 3
                    );
                    $future_coworkers = new WP_Query($args);
                    if ($future_coworkers->have_posts()) :
                        ?>
                        <?php
                        $count = 1;
                        while ($future_coworkers->have_posts()) :
                            if ($count == 1) {
                                $class = 'active';
                            } else {
                                $class = "";
                            }
                            $is_on_careers_page = get_field('display_on_careers_page');
                            $future_coworkers->the_post();
                            $thumbnail = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), "large");
                            ?>
                            <a style="background-image: url(<?php echo $thumbnail[0]; ?>)" class="nav-link <?php echo $class ?>" id="home-tab-<?php echo $count; ?>" data-toggle="tab" href="#tab-<?php echo $count; ?>" role="tab" aria-controls="home-<?php echo $count; ?>" aria-selected="true"></a>

                            <?php
                            $count = $count + 1;
                        endwhile;
                        wp_reset_postdata();
                        ?>
                        <?php
                    endif;
                    ?>
                </div>
            </div>
        </div>
    </section>

    <section class="d-block-mobile coworkers-slider-mobile">
        <div class="container">
            <div class="row">
                <div class="coworker-slider owl-carousel owl-theme">
                    <?php
                    $args = array(
                        'post_type' => 'future_coworkers',
                        'post_status' => 'publish',
                        'order' => 'ASC',
                    );
                    if ($future_coworkers->have_posts()) :
                        ?>
                        <?php
                        $count = 1;
                        while ($future_coworkers->have_posts()) :
                            if ($count == 1) {
                                $class = 'active';
                            } else {
                                $class = "";
                            }
                            $is_on_careers_page = get_field('display_on_careers_page');
                            $future_coworkers->the_post();
                            $thumbnail = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), "large");
                            ?> 
                            <div class="item">
                                <div class="image" style="background-image: url(<?php echo $thumbnail[0]; ?>)"></div>
                                <div class="coworker-detail">
                                    <h3><?php the_title(); ?> :: <span class="designation"><?php the_field('co_designation') ?></span></h3>
                                    <?php the_content(); ?>
                                </div>
                            </div>

                            <?php
                            $count = $count + 1;
                        endwhile;
                        wp_reset_postdata();
                        ?>
                        <?php
                    endif;
                    ?>
                </div>
            </div>
        </div>
    </section>

    <section class="latest-jobs">
        <div class="container">
            <div id="BambooHR">
                <script src="https://groq.bamboohr.com/js/jobs2.php" type="text/javascript"></script>
                <div id="BambooHR-Footer">Powered by<a href="http://www.bamboohr.com" target="_blank" rel="noopener external nofollow noreferrer"><img src="https://resources.bamboohr.com/images/footer-logo.png" alt="BambooHR - HR software"/></a>
                </div>
            </div>
        </div>
    </section>

</main>
<?php get_footer(); ?>
