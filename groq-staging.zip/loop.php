
<?php
// args to display highlighted posted
$args = array(
    'numberposts' => 1,
    'post_type' => 'post',
    'meta_key' => 'highlight_post',
    'meta_value' => true
);

$the_query = new WP_Query($args);
?>
<?php if ($the_query->have_posts()): ?>
    <div class="higlighted-post scroll-section" >
        <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>

            <div class="row">
                <div class="col-xl-5 col-lg-5 col-12">
                    <div class="text">
                        <h2 class="main-title-small">Highlighted</h2>
                        <div class="published-date pt-2 pb-3"><span class="date"><?php the_time('F j, Y'); ?></span></div>
                        <h3 class="title">
                            <?php the_title(); ?>
                        </h3>
                        <div class="pt-3 pb-5">
                            <?php the_excerpt(); ?>
                        </div>
                        <a class="btn-border" href="<?php the_permalink(); ?>">Read More</a>
                    </div>
                </div>
                <div class="col-xl-7 col-lg-7 col-12">
                    <?php the_post_thumbnail(); ?>
                </div>
            </div>

        <?php endwhile; ?>
    </div>
<?php endif; ?>

<?php wp_reset_query();  // Restore global post data stomped by the_post(). ?>

<div class="container">
    <div class="d-flex search-bar align-items-right">
        <div class="tag-dropdown">
            <label>Filter by tag</label>
            <?php echo taxonomy_dropdown_widget(); ?>
        </div>
        <div class="search_form">
            <?php echo get_search_form(); ?>
        </div>
    </div>
</div>


<div class="row">
    <div class="container">
        <?php echo do_shortcode('[ajax_load_more container_type="div"  posts_per_page="6" transition_container_classes="row" post_type="post"  button_label="See More"]'); ?>
    </div>
</div>

